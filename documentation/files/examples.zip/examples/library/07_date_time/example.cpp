#include <omnilib>

static void o(const omni::chrono::date_time& dt, const char* fmt)
{
    try {
        std::cout << fmt << " = " << dt.to_string(fmt) << std::endl;
    } catch (...) {
        std::cout << "Invalid format: '" << fmt << "'" << std::endl;
    }
}

static void date_format(const omni::chrono::date_time& dt)
{
    std::cout << "--formatted strings--" << std::endl;
    o(dt, "yyyyMMdd hh:mm:ss tt z");

    o(dt, "d"); // The day of the month, from 1 to 31.
    o(dt, "dd"); // The day of the month, from 01 to 31.
    o(dt, "ddd"); // The abbreviated name of the day of the week.
    o(dt, "dddd"); // The full name of the day of the week.
    o(dt, "f"); // The tenths of a second in a date and time value.
    o(dt, "ff"); // The hundredths of a second in a date and time value.
    o(dt, "fff"); // The milliseconds in a date and time value.
    o(dt, "ffff"); // The ten thousandths of a second in a date and time value.
    o(dt, "fffff"); // The hundred thousandths of a second in a date and time value.
    o(dt, "ffffff"); // The millionths of a second in a date and time value.
    o(dt, "fffffff"); // The ten millionths of a second in a date and time value.
    o(dt, "F"); // If non-zero, the tenths of a second in a date and time value.
    o(dt, "FF"); // If non-zero, the hundredths of a second in a date and time value.
    o(dt, "FFF"); // If non-zero, the milliseconds in a date and time value.
    o(dt, "FFFF"); // If non-zero, the ten thousandths of a second in a date and time value.
    o(dt, "FFFFF"); // If non-zero, the hundred thousandths of a second in a date and time value.
    o(dt, "FFFFFF"); // If non-zero, the millionths of a second in a date and time value.
    o(dt, "FFFFFFF"); // If non-zero, the ten millionths of a second in a date and time value.
    o(dt, "g"); // short-hand
    o(dt, "gg"); // The period or era (e.g. A.D.).
    o(dt, "h"); // The hour, using a 12-hour clock from 1 to 12.
    o(dt, "hh"); // The hour, using a 12-hour clock from 01 to 12.
    o(dt, "H"); // The hour, using a 24-hour clock from 0 to 23.
    o(dt, "HH"); // The hour, using a 24-hour clock from 00 to 23.
    o(dt, "K"); // Time zone information.
    o(dt, "m"); // The minute, from 0 to 59.
    o(dt, "mm"); // The minute, from 00 to 59.
    o(dt, "M"); // The month, from 1 to 12.
    o(dt, "MM"); // The month, from 01 to 12.
    o(dt, "MMM"); // The abbreviated name of the month.
    o(dt, "MMMM"); // The full name of the month.
    o(dt, "s"); // The second, from 0 to 59.
    o(dt, "ss"); // The second, from 00 to 59.
    o(dt, "t"); // The first character of the AM/PM designator.
    o(dt, "tt"); // The AM/PM designator.
    o(dt, "y"); // The year, from 0 to 99.
    o(dt, "yy"); // The year, from 00 to 99.
    o(dt, "yyy"); // The year, with a minimum of three digits.
    o(dt, "yyyy"); // The year as a four-digit number.
    o(dt, "yyyyy"); // The year as a five-digit number.
    o(dt, "z"); // Hours offset from UTC, with no leading zeros.
    o(dt, "zz"); // Hours offset from UTC, with a leading zero for a single-digit value.
    o(dt, "zzz"); // Hours and minutes offset from UTC.
    o(dt, ":"); // The time separator.
    o(dt, "/"); // The date separator.
    o(dt, "\"string\"");
    o(dt, "'string'"); // Literal string delimiter.
    o(dt, "%s"); // Defines the following character as a custom format specifier.
    o(dt, "\t"); // The escape character.
    o(dt, "123-"); // Any other character - The character is copied to the result string unchanged.

    std::cout << "----------------------" << std::endl << std::endl;
}

static void date_info_print(const omni::chrono::date_time& dt)
{
    std::cout << ".is_dst = " << (dt.is_dst() ? "yes" : "no") << std::endl
              << ".to_binary = " << dt.to_binary() << std::endl
              << ".hash_code = " << dt.hash_code() << std::endl
              << ".kind = " << dt.kind() << std::endl
              << ".year = " << dt.year() << std::endl
              << ".month = " << static_cast<uint32_t>(dt.month()) << std::endl
              << ".day = " << static_cast<uint32_t>(dt.day()) << std::endl
              << ".day_of_week = " << dt.day_of_week() << std::endl
              << ".day_of_year = " << dt.day_of_year() << std::endl
              << ".hour = " << static_cast<uint32_t>(dt.hour()) << std::endl
              << ".minute = " << static_cast<uint32_t>(dt.minute()) << std::endl
              << ".second = " << static_cast<uint32_t>(dt.second()) << std::endl
              << ".millisecond = " << dt.millisecond() << std::endl
              << ".ticks = " << dt.ticks() << std::endl
              << ".time_of_day = " << dt.time_of_day() << std::endl
              << ".to_oa_date = " << dt.to_oa_date() << std::endl
              << ".to_file_time = " << dt.to_file_time() << std::endl
              << ".to_file_time_utc = " << dt.to_file_time_utc() << std::endl
              << ".to_string = '" << dt.to_string() << "'" << std::endl;
    std::cout << std::endl;
}

int main(int argc, char* argv[])
{
    omni::chrono::date_time n = omni::chrono::date_time::now();
    // omni::chrono::date_time u = omni::chrono::date_time::utc_now();
    date_info_print(n);
    date_format(n);

    std::cout << "------ TRYING PARSING!!!! -----" << std::endl;

    if (omni::chrono::date_time::try_parse("10/31/2024 12:34 PM", n)) {
        std::cout << "PARSED IT!!!!" << std::endl;
        date_info_print(n);
    } else {
        std::cout << "It did NOT work :(" << std::endl;
    }

    //date_info_print(u);
    //date_format(u);
    return 0;
}
