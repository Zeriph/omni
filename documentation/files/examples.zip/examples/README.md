build     - This folder contains build templates/examples
classes   - This folder contains individual function/namespace help, named according to scope
            with the namespace scope opertor ('::') replaced with a dash ('-') for a valid filename
            ex: omni::application::last_signal() would be omni-system-last_signal.cpp
library   - This folder contains full examples of the library (like threading or delegates)

