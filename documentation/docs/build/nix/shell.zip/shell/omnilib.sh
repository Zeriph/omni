#!/bin/sh
omni_src_dir=/source/omni
pdir=`pwd`
objdir=${pdir}/obj
outdir=${pdir}/output
libname=${outdir}/omni.a
src=

# set source, only setting it this way so it's easier to
# read on screen (and it's easy to # out a source we don't want)
rc="${src} ${omni_src_dir}/application.cpp"
rc="${src} ${omni_src_dir}/argparser.cpp"
rc="${src} ${omni_src_dir}/async_timer.cpp"
rc="${src} ${omni_src_dir}/basic_thread.cpp"
rc="${src} ${omni_src_dir}/binary_semaphore.cpp"
rc="${src} ${omni_src_dir}/conditional.cpp"
rc="${src} ${omni_src_dir}/drop_timer.cpp"
rc="${src} ${omni_src_dir}/endpoint_descriptor.cpp"
rc="${src} ${omni_src_dir}/environment.cpp"
rc="${src} ${omni_src_dir}/externs.cpp"
rc="${src} ${omni_src_dir}/io.cpp"
rc="${src} ${omni_src_dir}/library.cpp"
rc="${src} ${omni_src_dir}/mutex.cpp"
rc="${src} ${omni_src_dir}/omnilib"
rc="${src} ${omni_src_dir}/queue_timer.cpp"
rc="${src} ${omni_src_dir}/runnable.cpp"
rc="${src} ${omni_src_dir}/semaphore.cpp"
rc="${src} ${omni_src_dir}/socket.cpp"
rc="${src} ${omni_src_dir}/stopwatch.cpp"
rc="${src} ${omni_src_dir}/sync_timer.cpp"
rc="${src} ${omni_src_dir}/system.cpp"
rc="${src} ${omni_src_dir}/thread.cpp"
rc="${src} ${omni_src_dir}/threadpool.cpp"

if [ ! -d ${objdir} ]; then
    echo "mkdir ${objdir}"
    mkdir ${objdir}
fi
if [ ! -d ${outdir} ]; then
    echo "mkdir ${outdir}"
    mkdir ${outdir}
fi

# loop through and compile source to object files for linking
src_files=$(echo $src | tr " " "\n")
ofiles=
for srcfile in $src_files; do
    ofile="${objdir}${srcfile#*${omni_src_dir}}.o"
	ofiles="${ofiles} ${ofile}"
    echo "g++ $srcfile -o$ofile -I$omni_src_dir -c -pthread -rt -03 -DNDEBUG -D_CONSOLE -fexecptions -D_UNICODE -DUNICODE"
    g++ $srcfile -o$ofile -I$omni_src_dir -c -pthread -rt -03 -DNDEBUG -D_CONSOLE -fexecptions -D_UNICODE -DUNICODE
done

# create static lib
echo "ar rvs $libname $ofiles"
ar rvs $libname $ofiles

