/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <omni/sync/thread.hpp>
#if !defined(OMNI_OS_WIN)
    // need the following for POSIX thread set prio/join
    #include <unistd.h>
    #include <sched.h>
    #include <ctime>
    #include <cstring>
#endif
#include <omni/chrono/tick.hpp>
#include <omni/sync/scoped_lock.hpp>
#include <omni/consts/cconsts.hpp>
#include <omni/exception.hpp>

#if defined(OMNI_NON_PORTABLE)
    #define OMNI_PRIO_FW  m_priority(omni::sync::thread_priority::NORMAL),
    #define OMNI_PRIO_CP_FW m_priority(cp.m_priority),
#else
    #define OMNI_PRIO_FW
    #define OMNI_PRIO_CP_FW 
#endif
#if defined(OMNI_SAFE_THREAD)
    #define OMNI_SAFE_THREAD_MILST_FW  m_mtx(),
    #define OMNI_SAFE_THREAD_LOCK_FW   this->m_mtx.lock();
    #define OMNI_SAFE_THREAD_UNLOCK_FW this->m_mtx.unlock();
    #define OMNI_SAFE_THREAD_ALOCK_FW  omni::sync::scoped_lock<omni::sync::basic_lock> smal(&this->m_mtx);
#else
    #define OMNI_SAFE_THREAD_MILST_FW
    #define OMNI_SAFE_THREAD_LOCK_FW
    #define OMNI_SAFE_THREAD_UNLOCK_FW
    #define OMNI_SAFE_THREAD_ALOCK_FW
#endif

//// start static thread management methods ////

/* DEV_NOTE: m_mgrlock, m_aborts, and m_mgrthreads use the static init on first use idiom to avoid
the static init order fiasco. For now they will claim heap memory via the `new` keyword, and since
they are static functions, will exist until program termination. This doesn't cause a leak in the
traditional sense, but it could lead to possible issues on some systems (though none have been found
yet that exhibit any issue). Other idioms are being examined, but for now this is what is to be used.*/

omni::sync::thread::static_order_wrapper& omni::sync::thread::m_sow()
{
    // to avoid static init order fiasco
    static omni::sync::thread::static_order_wrapper* ret = new omni::sync::thread::static_order_wrapper();
    return *ret;
}

void omni::sync::thread::_set_context(omni::sync::thread& t1, const omni::sync::thread& t2)
{
    #if defined(OMNI_SAFE_THREAD)
        t1.m_mtx.lock();
        t2.m_mtx.lock();
    #endif
    t1.aborted = t2.aborted;
    t1.completed = t2.completed;
    t1.m_args = t2.m_args;
    t1.m_ops = t2.m_ops;
    t1.m_state = t2.m_state;
    t1.m_tid = t2.m_tid;
    t1.m_thread = t2.m_thread;
    t1.m_switch = t2.m_switch;
    #if defined(OMNI_NON_PORTABLE)
        t1.m_priority = t2.m_priority;
    #endif
    t1._chkmthd();
    if (t2.m_mthd != 0) {
        t1.m_mthd = new omni::sync::thread_start(*t2.m_mthd);
    } else if (t2.m_pmthd != 0) {
        t1.m_pmthd = new omni::sync::parameterized_thread_start(*t2.m_pmthd);
    }
    #if defined(OMNI_SAFE_THREAD)
        t2.m_mtx.unlock();
        t1.m_mtx.unlock();
    #endif
}

OMNI_THREAD_FNPTR_T OMNI_THREAD_CALL_T omni::sync::thread::_start(void* param)
{
    /* note: we don't call t->any_function() since that could potentially introduce a deadlock.
    If the thread gets this far, then the thread::start() function has already called scoped_lock
    and it's safe to use t->m_ values (since no other threads can operate on the values) */
    omni::sync::thread *t = static_cast<omni::sync::thread*>(param);
    if (t->m_mthd) {
        omni::sync::thread_t tid = omni::sync::thread_id();
        void* args = t->m_args;
        omni::sync::parameterized_thread_start* pstartfn = OMNI_NULL;
        omni::sync::thread_start* startfn = OMNI_NULL;
        omni::sync::thread::m_sow().push_back(tid, *t);
        if (t->m_pmthd != OMNI_NULL) {
            pstartfn = new omni::sync::parameterized_thread_start(*(t->m_pmthd));
        } else if (t->m_mthd != OMNI_NULL) {
            startfn = new omni::sync::thread_start(*(t->m_mthd));
        }
        #if !defined(OMNI_OS_WIN)
            /*
                we don't check for any errors here as it's not a good idea to ever 'kill' a thread.
                setting to async cancel type sets the cross platform compatibility as TerminateThread
                is 'async' in nature.
                
                !!!! NOTE !!!!
                
                remember, it's a better idea to use 'abort' and the 'state_changed' handler to end
                your threads nicely (avoid resource leaks)
            */
            ::pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
        #endif
        #if defined(OMNI_NON_PORTABLE)
            if (t->m_priority != omni::sync::thread_priority::NORMAL) {
                OMNI_D4_FW("setting thread priority");
                t->_set_prio();
            }
        #endif
        t->m_state = omni::sync::thread_state::RUNNING;
        // wrap the delegate in a try..catch in case the user code errors, we can handle it here
        if (pstartfn != OMNI_NULL) {
            OMNI_TRY_FW
            t->m_switch->signal();
            pstartfn->invoke(args);
            OMNI_CATCHEX_FW(delete pstartfn;)
        } else if (startfn != OMNI_NULL) {
            OMNI_TRY_FW
            t->m_switch->signal();
            startfn->invoke();
            OMNI_CATCHEX_FW(delete startfn;)
        }
        args = OMNI_NULL; pstartfn = OMNI_NULL; startfn = OMNI_NULL;
        omni::sync::thread::m_sow().pop_back(tid);
    } else {
        // shouldn't happen since this should be caught in the calling thread::start
        OMNI_DBGE(omni::consts::err::INVALID_DELEGATE_FUNC_PTR)
        OMNI_THROW_FW(omni::invalid_delegate())        
        // if nothrow then act as 'killed'
        t->m_state = omni::sync::thread_state::STOPPED;
        t->m_switch->signal();
    }
    t = OMNI_NULL;
    return 0;
}

//// start thread constructors ////

omni::sync::thread::thread() : 
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created");
}

omni::sync::thread::thread(const omni::sync::thread &cp) : 
    aborted(cp.aborted),
    completed(cp.completed),
    OMNI_CPCTOR_FW(cp)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(cp.m_args),
    m_pmthd(0),
    m_mthd(0),
    m_switch(cp.m_switch),
    m_tid(cp.m_tid),
    m_thread(cp.m_thread),
    m_ops(cp.m_ops),
    m_state(cp.m_state),
    OMNI_PRIO_CP_FW
    m_isjoined(cp.m_isjoined)
{
    if (cp.m_mthd != 0) {
        this->m_mthd = new omni::sync::thread_start(*cp.m_mthd);
    } else if (cp.m_pmthd != 0) {
        this->m_pmthd = new omni::sync::parameterized_thread_start(*cp.m_pmthd);
    }
    OMNI_D5_FW("thread copied");
}

omni::sync::thread::thread(const omni::sync::thread_options &ops) : 
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(ops),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread const copied");
}

omni::sync::thread::thread(std::size_t max_stack_sz) : 
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
}

omni::sync::thread::thread(const omni::sync::thread_start &mthd) : 
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
}

omni::sync::thread::thread(const omni::sync::thread_start &mthd, const omni::sync::thread::delegate& abort_req) : 
    aborted(abort_req),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
}

omni::sync::thread::thread(const omni::sync::thread_start &mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp) : 
    aborted(abort_req),
    completed(comp),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
}

omni::sync::thread::thread(const omni::sync::thread_start& mthd, omni::sync::thread_start_type_t st) :
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
    if (st == omni::sync::thread_start_type::NOW) {
        this->start();
    }
}

omni::sync::thread::thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req, omni::sync::thread_start_type_t st) :
    aborted(abort_req),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
    if (st == omni::sync::thread_start_type::NOW) {
        this->start();
    }
}

omni::sync::thread::thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, omni::sync::thread_start_type_t st) :
    aborted(abort_req),
    completed(comp),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
    if (st == omni::sync::thread_start_type::NOW) {
        this->start();
    }
}

omni::sync::thread::thread(const omni::sync::thread_start &mthd, std::size_t max_stack_sz) :
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
}

omni::sync::thread::thread(const omni::sync::thread_start &mthd, const omni::sync::thread::delegate& abort_req, std::size_t max_stack_sz) :
    aborted(abort_req),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
}

omni::sync::thread::thread(const omni::sync::thread_start &mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, std::size_t max_stack_sz) :
    aborted(abort_req),
    completed(comp),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
}

omni::sync::thread::thread(const omni::sync::thread_start &mthd, std::size_t max_stack_sz, omni::sync::thread_start_type_t st) :
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
    if (st == omni::sync::thread_start_type::NOW) {
        this->start();
    }
}

omni::sync::thread::thread(const omni::sync::thread_start &mthd, const omni::sync::thread::delegate& abort_req, std::size_t max_stack_sz, omni::sync::thread_start_type_t st) :
    aborted(abort_req),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
    if (st == omni::sync::thread_start_type::NOW) {
        this->start();
    }
}

omni::sync::thread::thread(const omni::sync::thread_start &mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, std::size_t max_stack_sz, omni::sync::thread_start_type_t st) :
    aborted(abort_req),
    completed(comp),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
    if (st == omni::sync::thread_start_type::NOW) {
        this->start();
    }
}

omni::sync::thread::thread(const omni::sync::thread_start& mthd, omni::sync::thread_option_t op, omni::sync::thread_union_t val) : 
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(0),
    m_mthd(new omni::sync::thread_start(mthd)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with specific options");
    this->set_option(op, val);
}

// parameterized thread start constructors

omni::sync::thread::thread(const omni::sync::parameterized_thread_start &mthd) : 
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start &mthd, const omni::sync::thread::delegate& abort_req) : 
    aborted(abort_req),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start &mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp) : 
    aborted(abort_req),
    completed(comp),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start& mthd, omni::sync::thread_start_type_t st, void* args) :
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(args),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
    if (st == omni::sync::thread_start_type::NOW) {
        this->start(this->m_args);
    } else {
        OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_START_TYPE, omni::invalid_thread_start_type())
    }
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req, omni::sync::thread_start_type_t st, void* args) :
    aborted(abort_req),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(args),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
    if (st == omni::sync::thread_start_type::NOW) {
        this->start(this->m_args);
    } else {
        OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_START_TYPE, omni::invalid_thread_start_type())
    }
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, omni::sync::thread_start_type_t st, void* args) :
    aborted(abort_req),
    completed(comp),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(args),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with delegate method");
    if (st == omni::sync::thread_start_type::NOW) {
        this->start(this->m_args);
    } else {
        OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_START_TYPE, omni::invalid_thread_start_type())
    }
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start &mthd, std::size_t max_stack_sz) :
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start &mthd, const omni::sync::thread::delegate& abort_req, std::size_t max_stack_sz) :
    aborted(abort_req),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start &mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, std::size_t max_stack_sz) :
    aborted(abort_req),
    completed(comp),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start &mthd, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args) :
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(args),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
    if (st == omni::sync::thread_start_type::NOW) {
        this->start(this->m_args);
    } else {
        OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_START_TYPE, omni::invalid_thread_start_type())
    }
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start &mthd, const omni::sync::thread::delegate& abort_req, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args) :
    aborted(abort_req),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(args),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
    if (st == omni::sync::thread_start_type::NOW) {
        this->start(this->m_args);
    } else {
        OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_START_TYPE, omni::invalid_thread_start_type())
    }
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start &mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args) :
    aborted(abort_req),
    completed(comp),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(args),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
    if (st == omni::sync::thread_start_type::NOW) {
        this->start(this->m_args);
    } else {
        OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_START_TYPE, omni::invalid_thread_start_type())
    }
}

omni::sync::thread::thread(const omni::sync::parameterized_thread_start& mthd, omni::sync::thread_option_t op, omni::sync::thread_union_t val) :
    aborted(),
    completed(),
    OMNI_CTOR_FW(omni::sync::thread)
    OMNI_SAFE_THREAD_MILST_FW
    m_args(NULL),
    m_pmthd(new omni::sync::parameterized_thread_start(mthd)),
    m_mthd(0),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    OMNI_PRIO_FW
    m_isjoined(false)
{
    OMNI_D5_FW("thread created with specific options");
    this->set_option(op, val);
}

//// end thread constructors ////

omni::sync::thread::~thread()
{
    OMNI_DTOR_FW
    OMNI_SAFE_THREAD_LOCK_FW
    bool koe = this->m_ops.kill_on_eop;
    bool aj = this->m_ops.auto_join;
    OMNI_SAFE_THREAD_UNLOCK_FW
    // join on 'auto_join' unless the user wants to 'kill on external operation'
    if (!koe && aj && !this->is_detached()) { this->join(); }
    this->_kill_on_eop(); // won't happen of koe==true
    this->detach();
    OMNI_SAFE_THREAD_LOCK_FW
    this->_chkmthd();
    OMNI_SAFE_THREAD_UNLOCK_FW
    OMNI_D5_FW("destroyed");
}

void omni::sync::thread::abort()
{
    OMNI_SAFE_THREAD_LOCK_FW
    bool valid = this->_hvalid();
    bool running = this->_state_running();
    OMNI_SAFE_THREAD_UNLOCK_FW
    if (valid && running) {
        if (valid) {
            this->_state_changed(omni::sync::thread_state::ABORT_REQUESTED);
        } else {
            OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle())
        }
    }
    #if defined(OMNI_DBG_L3)
    else { OMNI_D3_FW("thread is not running"); }
    #endif
}

bool omni::sync::thread::bind(const omni::sync::parameterized_thread_start& mthd)
{
    if (!this->unbind()) { return false; }
    OMNI_SAFE_THREAD_LOCK_FW
    this->m_pmthd = new omni::sync::parameterized_thread_start(mthd);
    OMNI_SAFE_THREAD_UNLOCK_FW
    return true;
}

bool omni::sync::thread::bind(const omni::sync::thread_start& mthd)
{
    if (!this->unbind()) { return false; }
    OMNI_SAFE_THREAD_LOCK_FW
    this->m_mthd = new omni::sync::thread_start(mthd);
    OMNI_SAFE_THREAD_UNLOCK_FW
    return true;
}

void omni::sync::thread::detach()
{
    this->detach(false);
}

void omni::sync::thread::detach(bool allow_rejoin)
{
    OMNI_SAFE_THREAD_ALOCK_FW
    this->_hreset(true, allow_rejoin);
}

const omni::sync::thread_union_t omni::sync::thread::get_option(omni::sync::thread_option_t op) const
{
    OMNI_SAFE_THREAD_ALOCK_FW
    switch (op) {
        case omni::sync::thread_options::ALLOW_THREAD_REUSE:
            return this->m_ops.allow_reuse;
        case omni::sync::thread_options::AUTO_JOIN:
            return this->m_ops.auto_join;
        case omni::sync::thread_options::KILL_ON_EO:
            return this->m_ops.kill_on_eop;
        case omni::sync::thread_options::STACK_SIZE:
            return this->m_ops.stack_size;
        case omni::sync::thread_options::TIMEOUT_ON_EO:
            return this->m_ops.timeout_on_eop;
        default: // invalid_option
            OMNI_ERRV_FW("invalid option: ", op, omni::invalid_thread_option(static_cast<std::size_t>(op)))
            break;
    }
    return false;
}

omni::sync::thread_options omni::sync::thread::options() const
{
    OMNI_SAFE_THREAD_ALOCK_FW
    return this->m_ops;
}

const omni::sync::thread_handle_t omni::sync::thread::handle() const
{
    OMNI_SAFE_THREAD_ALOCK_FW
    return this->m_thread;
}

const omni::sync::thread_t omni::sync::thread::id() const
{
    OMNI_SAFE_THREAD_ALOCK_FW
    return this->m_tid;
}

bool omni::sync::thread::is_alive() const
{
    OMNI_SAFE_THREAD_ALOCK_FW
    /*
    DEV_NOTE: we don't use pthread_kill or GetExitCodeThread
    since those might give 'erroneous' results for these purposes.
    That is to say, using JUST those API's will not guarantee
    that our underlying thread is 'actually' running.
    
    omni::sync::thread_state::UNSTARTED = 0,
    // Defines a thread has completed its function (method complete)
    omni::sync::thread_state::COMPLETED = 4,
    // Defines a thread is stopped (killed)
    omni::sync::thread_state::STOPPED = 16,
    // Defines a thread has been aborted
    omni::sync::thread_state::ABORTED = 64,
    // Defines a thread is attempting to spawn
    omni::sync::thread_state::START_REQUESTED = 1,
    
    // Defines a thread is running (method has been called)
    omni::sync::thread_state::RUNNING = 2,
    // Defines a thread has a stop request (kill request)
    omni::sync::thread_state::STOP_REQUESTED = 8,
    // Defines a thread has an abort request
    omni::sync::thread_state::ABORT_REQUESTED = 32,
    // Defines a thread has a state that can not be determined (when creating threads from handles for instance)
    omni::sync::thread_state::UNKNOWN = 255
    */
    return this->_hvalid() && this->_state_running();
}

bool omni::sync::thread::is_bound() const
{
    OMNI_SAFE_THREAD_ALOCK_FW
    if (this->m_mthd != 0) {
        return this->m_mthd->valid();
    } else if (this->m_pmthd != 0) {
        return this->m_pmthd->valid();
    }
    return false;
}

bool omni::sync::thread::is_detached() const
{
    OMNI_SAFE_THREAD_ALOCK_FW
    return (this->m_state == omni::sync::thread_state::UNSTARTED &&
            this->m_tid == 0 &&
            this->m_thread == 0);
}

bool omni::sync::thread::join()
{
    // Unknown states can still be joined
    if (!this->is_alive()) {
        OMNI_D2_FW("thread is not running");
        return true;
    }
    OMNI_SAFE_THREAD_LOCK_FW
    if (!this->_hvalid()) { 
        OMNI_SAFE_THREAD_UNLOCK_FW
        OMNI_ERR_RETV_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle(), false)
    }
    omni::sync::thread_handle_t hndl = this->m_thread;
    #if defined(OMNI_OS_WIN)
        this->m_isjoined = true;
        OMNI_SAFE_THREAD_UNLOCK_FW
        int ret = ::WaitForSingleObject(OMNI_WIN_TOHNDL(hndl), INFINITE);
        #if defined(OMNI_DBG_L1)
            if (ret != 0) { OMNI_DBGEV("error while waiting for thread handle: ", OMNI_GLE_PRNT) }
        #endif
        return (ret == 0); // Returns 0 on success
    #else
        this->m_isjoined = true;
        OMNI_SAFE_THREAD_UNLOCK_FW
        int ret = ::pthread_join(hndl, NULL);
        #if defined(OMNI_DBG_L1)
            if (ret != 0) { OMNI_DBGEV("error while waiting for thread handle: ", OMNI_GLE_PRNT) }
        #endif
        return (ret == 0); // Returns 0 on success
    #endif
}

bool omni::sync::thread::join(unsigned long timeout)
{
    if (timeout == omni::sync::INFINITE_TIMEOUT) { return this->join(); }
    // Unknown states can still be joined
    if (!this->is_alive()) {
        OMNI_D2_FW("thread is not running");
        return true;
    }
    OMNI_SAFE_THREAD_LOCK_FW
    if (!this->_hvalid()) { 
        OMNI_SAFE_THREAD_UNLOCK_FW
        OMNI_ERR_RETV_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle(), false)
    }
    omni::sync::thread_handle_t hndl = this->m_thread;
    #if defined(OMNI_OS_WIN)
        this->m_isjoined = true;
        OMNI_SAFE_THREAD_UNLOCK_FW
        int ret = ::WaitForSingleObject(OMNI_WIN_TOHNDL(hndl), timeout);
        #if defined(OMNI_DBG_L1)
            if (ret != 0) { OMNI_DBGEV("error while waiting for thread handle: ", OMNI_GLE_PRNT) }
        #endif
        return (ret == 0); // Returns 0 on success
    #else
        /* There is not a portable mechanism with pthreads to wait on a specific thread without
        implementing a timed_wait condition variable. We don't want the user to have to implement
        a seperate variable based on system, so we implement a 'timeout' loop*/
        this->m_isjoined = true;
        OMNI_SAFE_THREAD_UNLOCK_FW
        omni::chrono::tick_t ts = omni::chrono::monotonic_tick();
        OMNI_SLEEP_INIT();
        volatile bool iav = true;
        // iav = (::pthread_kill(this->m_thread, 0) != ESRCH); // == "alive"
        while ((iav = (::pthread_kill(hndl, 0) != ESRCH)) && (omni::chrono::elapsed_ms(ts) < timeout)) {
            OMNI_SLEEP1();
        }
        return (::pthread_kill(hndl, 0) == ESRCH); // == "dead"
    #endif
}

bool omni::sync::thread::kill()
{
    if (!this->is_alive()) {
        // thread's already 'dead', no need to 'kill'
        OMNI_D2_FW("thread is not running");
        return true;
    }
    OMNI_SAFE_THREAD_LOCK_FW
    if (!this->_hvalid()) {
        OMNI_SAFE_THREAD_UNLOCK_FW
        OMNI_ERR_RETV_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle(), false)
    }
    int perr = 0;
    omni::sync::thread_handle_t hndl = this->m_thread;
    this->m_state = omni::sync::thread_state::STOP_REQUESTED;
    OMNI_SAFE_THREAD_UNLOCK_FW
    // attempt to kill it
    #if defined(OMNI_OS_WIN)
        if (::TerminateThread(OMNI_WIN_TOHNDL(hndl), 0) == 0) {
            perr = OMNI_GLE;
        }
    #else
        perr = ::pthread_cancel(hndl);
    #endif
    if (perr == 0) {
        this->_state_changed(omni::sync::thread_state::STOPPED);
        return true;
    }
    OMNI_DV1_FW("thread termination error code: ", perr);
    // Something unknown happened...
    OMNI_SAFE_THREAD_LOCK_FW
    this->m_state = omni::sync::thread_state::UNKNOWN;
    OMNI_SAFE_THREAD_UNLOCK_FW
    return false;
}

bool omni::sync::thread::reset()
{
    if (this->is_alive()) {        
        OMNI_ERR_RETV_FW("cannot reset thread while running", omni::thread_running_exception(), false)
    } else {
        this->detach();
    }
    return true;
}

bool omni::sync::thread::restart()
{
    if (!this->reset()) { return false; }
    this->start();
    return true;
}

bool omni::sync::thread::restart(void* args)
{
    if (!this->reset()) { return false; }
    this->start(args);
    return true;
}

bool omni::sync::thread::restart(const omni::sync::parameterized_thread_start& mthd)
{
    this->bind(mthd);
    return this->restart();
}

bool omni::sync::thread::restart(const omni::sync::thread_start& mthd)
{
    this->bind(mthd);
    return this->restart();
}

bool omni::sync::thread::restart(const omni::sync::parameterized_thread_start& mthd, void* args)
{
    this->bind(mthd);
    return this->restart(args);
}

omni::sync::thread_state_t omni::sync::thread::status() const
{
    OMNI_SAFE_THREAD_ALOCK_FW
    return this->m_state;
}

void omni::sync::thread::set_option(omni::sync::thread_option_t op, omni::sync::thread_union_t val)
{
    OMNI_SAFE_THREAD_ALOCK_FW
    switch (op) {
        case omni::sync::thread_options::ALLOW_THREAD_REUSE:
            this->m_ops.allow_reuse = val.b_val;
            break;
        case omni::sync::thread_options::AUTO_JOIN:
            this->m_ops.auto_join = val.b_val;
            break;
        case omni::sync::thread_options::KILL_ON_EO:
            this->m_ops.kill_on_eop = val.b_val;
            break;
        case omni::sync::thread_options::STACK_SIZE:
            this->m_ops.stack_size = val.s_val;
            break;
        case omni::sync::thread_options::TIMEOUT_ON_EO:
            this->m_ops.timeout_on_eop = val.s_val;
            break;
        default: // invalid_option
            OMNI_ERRV_FW("invalid option: ", op, omni::invalid_thread_option(static_cast<std::size_t>(op)))
            break;
    }
}

void omni::sync::thread::set_options(const omni::sync::thread_options &ops)
{
    OMNI_SAFE_THREAD_ALOCK_FW
    this->m_ops.allow_reuse = ops.allow_reuse;
    this->m_ops.auto_join = ops.auto_join;
    this->m_ops.kill_on_eop = ops.kill_on_eop;
    this->m_ops.stack_size = ops.stack_size;
    this->m_ops.timeout_on_eop = ops.timeout_on_eop;
}

void omni::sync::thread::start()
{
    this->start(NULL);
}

void omni::sync::thread::start(void *args)
{
    OMNI_SAFE_THREAD_ALOCK_FW
    if (this->m_state != omni::sync::thread_state::UNSTARTED) {
        if (this->m_ops.allow_reuse) {
            // thread reuse is enabled, so reset the handles
            this->_hreset(true, false);
        } else {
            OMNI_ERR_RET_FW("Can not start a thread once it has been started or if it is in an unknown state", omni::thread_running_exception());
        }
    }
    if (this->m_mthd == 0 && this->m_pmthd == 0) {
        // no delegate attached to this thread so we can't actually start anything
        OMNI_ERR_RET_FW(omni::consts::err::INVALID_DELEGATE_FUNC_PTR, omni::invalid_delegate())
    }
    int perr = 0;
    this->m_args = ((this->m_pmthd != 0) ? args : NULL);
    this->m_state = omni::sync::thread_state::START_REQUESTED;
    this->m_switch = new omni::sync::safe_spin_wait(); // signaled set in _start
    this->m_thread = 0;
    #if defined(OMNI_OS_WIN)
        OMNI_TMPIDT_FW tmptid = 0;
        this->m_thread = OMNI_CREATE_THREAD_FW(NULL,                            // default security attr
                                              this->m_ops.stack_size,            // stack size
                                              &omni::sync::thread::_start, // _start(void*)
                                              static_cast<void*>(this),         // *see above dev note
                                              0,                                // start now
                                              &tmptid);                         // thread id
        // Win32 returns !0 for a valid thread, 0 means error
        if (this->m_thread == 0) { perr = OMNI_GLE; } // error, set perr
        else { this->m_tid = static_cast<omni::sync::thread_t>(tmptid); } // success, set tid
    #else
        // if any of these fails, then thread creation should fail
        if (this->m_ops.stack_size == 0) {
            perr = ::pthread_create(&this->m_tid,                 // the thread id
                                    NULL,                         // stack size == 0, so null attributes
                                    &omni::sync::thread::_start,        // _start(void*)
                                    static_cast<void*>(this));    // *see above dev note
            if (perr == 0) {
                this->m_thread = this->m_tid; // copy TID to m_thread handle
            } else {
                OMNI_ERRV_FW("system create thread failed: ", perr, omni::thread_exception("Create system thread failed: ", perr));
            }
        } else {
            pthread_attr_t attr;
            perr = ::pthread_attr_init(&attr);
            if (perr == 0) {
                perr = ::pthread_attr_setstacksize(&attr, this->m_ops.stack_size);
                if (perr == 0) {
                    perr = ::pthread_create(&this->m_tid,                 // the thread id
                                            &attr,                        // stack size
                                            &omni::sync::thread::_start,        // _start(void*)
                                            static_cast<void*>(this));    // *see above dev note
                    if (perr == 0) {
                        this->m_thread = this->m_tid; // copy TID to m_thread handle
                    } else {
                        OMNI_ERRV_FW("system create thread failed: ", perr, omni::thread_exception("Create system thread failed: ", perr));
                    }
                } else {
                    OMNI_ERR_FW("could not set stack size of " << this->m_ops.stack_size << ": " << perr, omni::thread_exception("System error setting stack size: ", perr))
                }
                if (perr == 0) {
                    // Destroy the attributes handle
                    perr = ::pthread_attr_destroy(&attr);
                    if (perr != 0) {
                        /* this should only ever happen if 'attr' is not valid
                        but to be safe we want to alert the user since this could signal
                        other issues (we also don't want any rouge handles not being
                        destroyed, ie a memory leak) */
                        OMNI_ERRV_FW("could not destroy attributes: ", perr, omni::thread_exception("Could not destroy attributes: ", perr));
                    }
                } else {
                    /* if we got here then there were other errors in thread creation, so
                    don't reset the perr value, just call the function */
                    ::pthread_attr_destroy(&attr);
                }
            } else {
                OMNI_ERR_FW("could not initialize thread attributes @" << &attr << ": " << perr, omni::thread_exception("Could not initialize thread attributes: ", perr));
            }
        }
    #endif
    if (perr == 0) {
        OMNI_D4_FW("thread handle valid, waiting for thread switch");
        // valid handle so wait until the thread is actually reported as started
        this->m_switch->sleep_wait();
        delete this->m_switch; // done with thread_switch, free mem
        this->m_switch = 0;
    } else {
        delete this->m_switch; // done with thread_switch, free mem
        this->m_switch = 0;
        this->m_thread = 0;
        OMNI_ERRV_FW("could not create system thread: ", perr, omni::thread_exception(perr))
    }
    OMNI_D3_FW(((this->m_tid == 0) ? "invalid" : "created") << " thread:" << this->m_tid);
}

void omni::sync::thread::swap(omni::sync::thread &o)
{
    if (this != &o) {
        // if the address' of the two are not ==, then swap
        omni::sync::thread *tmp = new omni::sync::thread(o); // get a copy
        omni::sync::thread::_set_context(o, *this);
        omni::sync::thread::_set_context(*this, *tmp);
        delete tmp;
    }
}

bool omni::sync::thread::unbind()
{
    OMNI_SAFE_THREAD_ALOCK_FW
    if ((this->_hvalid() && this->_state_running()))
    {
        /* don't check thread re-use here since it doesn't make sense here;
        the logic is that the user must explicitly detach or reset the thread before they can unbind */
        OMNI_ERR_RETV_FW("cannot detach method while thread is running", omni::thread_running_exception(), false)
    }
    this->_chkmthd();
    return true;
}

omni::sync::thread &omni::sync::thread::operator=(const omni::sync::thread &o)
{
    if (this != &o) {
        this->_kill_on_eop();
        OMNI_ASSIGN_FW(o)
        omni::sync::thread::_set_context(*this, o);
    }
    return *this;
}

bool omni::sync::thread::operator==(const omni::sync::thread &o) const
{
    if (this == &o) { return true; }
    #if defined(OMNI_SAFE_THREAD)
        omni::sync::scoped_lock<omni::sync::basic_lock> am(&this->m_mtx);
        omni::sync::scoped_lock<omni::sync::basic_lock> am2(&o.m_mtx);
    #endif
    return (this->aborted == o.aborted &&
        this->completed == o.completed &&
        this->m_args == o.m_args &&
        this->m_ops == o.m_ops &&
        this->m_state == o.m_state &&
        this->m_tid == o.m_tid &&
        this->m_thread == o.m_thread &&
        this->m_switch == o.m_switch &&
        (((this->m_mthd != 0) && (o.m_mthd != 0)) ? (*this->m_mthd == *o.m_mthd) :
        (((this->m_pmthd != 0) && (o.m_pmthd != 0)) ? (*this->m_pmthd == *o.m_pmthd) : false))
        #if defined(OMNI_NON_PORTABLE)
            && this->m_priority == o.m_priority
        #endif
        OMNI_EQUAL_FW(o)
        );
}

bool omni::sync::thread::operator!=(const omni::sync::thread &o) const
{
    return !(*this == o);
}

///////// private methods /////////

void omni::sync::thread::_chkmthd()
{
    if (this->m_mthd != 0) {
        delete this->m_mthd;
    } else if (this->m_pmthd != 0) {
        delete this->m_pmthd;
    }
    this->m_mthd = 0;
    this->m_pmthd = 0;
}

void omni::sync::thread::_close_handle(bool allow_rejoin)
{
    if (this->m_tid != 0) { omni::sync::thread::m_sow().remove(this->m_tid); }
    this->m_state = omni::sync::thread_state::UNSTARTED;
    if (this->m_thread != 0 && !allow_rejoin) {
        // detach the handle so the OS can cleanup when it's done
        if (!this->m_isjoined) {
            #if defined(OMNI_OS_WIN)
                ::CloseHandle(OMNI_WIN_TOHNDL(this->m_thread));
            #else
                /* if we've called pthread_join on this thread then don't detach
                it as that releases it's resources and makes it 'unjoinable' */
                ::pthread_detach(this->m_thread);
            #endif
        }
    }
    this->m_isjoined = false;
    this->m_thread = 0;
    this->m_tid = 0;
}

void omni::sync::thread::_hreset(bool force, bool allow_rejoin)
{
    #if defined(OMNI_NON_PORTABLE)
        this->m_priority = omni::sync::thread_priority::NORMAL;
    #endif
    if (this->m_ops.allow_reuse || force) { this->_close_handle(allow_rejoin); }
}

bool omni::sync::thread::_hvalid() const
{
    return (this->m_thread != 0);
}

void omni::sync::thread::_kill_on_eop()
{
    OMNI_SAFE_THREAD_LOCK_FW
    bool koe = this->m_ops.kill_on_eop;
    std::size_t to = this->m_ops.timeout_on_eop;
    OMNI_SAFE_THREAD_UNLOCK_FW
    // Check if the user wants the thread to hang around but destroy the thread object
    if (koe) {
        // First call abort
        this->abort();
        // wait the specified timeout (if set)
        if (to > 0) { this->join(to); }
        if (this->is_alive()) {
            OMNI_D5_FW("thread still alive after abort and wait, killing");
            // The thread is still running so abort it
            this->kill();
        }
    }
}

bool omni::sync::thread::_state_running() const
{
    return (this->m_state == omni::sync::thread_state::RUNNING ||
            this->m_state == omni::sync::thread_state::STOP_REQUESTED ||
            this->m_state == omni::sync::thread_state::ABORT_REQUESTED ||
            this->m_state == omni::sync::thread_state::UNKNOWN);
}

void omni::sync::thread::_state_changed(omni::sync::thread_state_t nstate)
{
    OMNI_SAFE_THREAD_LOCK_FW
    omni::sync::thread_t tid = this->m_tid;
    this->m_state = nstate;
    OMNI_SAFE_THREAD_UNLOCK_FW
    switch (nstate) {
        case omni::sync::thread_state::ABORT_REQUESTED: {
            omni::sync::thread::m_sow().abort(tid);
            if (this->aborted) { this->aborted(*this); }
        } break;
        case omni::sync::thread_state::ABORTED:
        case omni::sync::thread_state::COMPLETED:
        case omni::sync::thread_state::STOPPED:
            if (this->completed) { this->completed(*this); }
            // _hreset is called on dtor/detach or on start when thread_reuse==true
            // calling 'anything' after this statement is not guaranteed
            break;
        // here for pedant, no need to throw errors as this simply changes the 'state' of the thread enum
        case omni::sync::thread_state::START_REQUESTED: case omni::sync::thread_state::STOP_REQUESTED:
        case omni::sync::thread_state::UNSTARTED: case omni::sync::thread_state::UNKNOWN:
        case omni::sync::thread_state::RUNNING: default: break;
    }
}

void omni::sync::thread::_state_machine()
{
    // We can't check for a stop request since that is a user killing
    // this thread, and if that succeeded then we wouldn't get here
    OMNI_SAFE_THREAD_LOCK_FW
    omni::sync::thread_state_t st = this->m_state;
    OMNI_SAFE_THREAD_UNLOCK_FW
    switch (st) {
        case omni::sync::thread_state::RUNNING:
            this->_state_changed(omni::sync::thread_state::COMPLETED);
            break;
        case omni::sync::thread_state::ABORT_REQUESTED:
            this->_state_changed(omni::sync::thread_state::ABORTED);
            break;
        case omni::sync::thread_state::ABORTED: case omni::sync::thread_state::COMPLETED:
        case omni::sync::thread_state::STOP_REQUESTED: case omni::sync::thread_state::START_REQUESTED:
        case omni::sync::thread_state::UNSTARTED: case omni::sync::thread_state::UNKNOWN:
        case omni::sync::thread_state::STOPPED:
        default:
            /* everything else is a "stopped" by default because this "state machine" function is intended to only
            handle if an abort_request came or if the thread completed on the internal thread function (_start)
            so if this "state machine" function gets any other's, it should be noted and the thread object put
            in a "stopped" state (since there's a chance this would happen on a kill) */
            OMNI_DBGE("An invalid thread state was specified for the state_machine");
            this->_state_changed(omni::sync::thread_state::STOPPED);
            break;
    }
    // don't throw an error if the pointers are different .. this is in the event a thread object is detached
}

///////// non portable methods /////////

#if defined(OMNI_NON_PORTABLE)

void omni::sync::thread::_set_prio()
{
    int pri = static_cast<int>(this->m_priority);
    OMNI_DV4_FW("changing priority to ", pri);
    /* we don't throw an error if we can't set the thread priority since the
    OS could decide not to do it any ways or the system may not support it */ 
    #if defined(OMNI_OS_WIN)
        if (::SetThreadPriority(OMNI_WIN_TOHNDL(this->m_thread), pri) == 0) {
            OMNI_DBGE(omni::consts::err::ERR_SET_PRIORITY << ": " << OMNI_GLE)
        }
    #else
        int sched = 0;
        struct sched_param param;
        std::memset(&param, 0, sizeof(sched_param));
        if (::pthread_getschedparam(this->m_thread, &sched, &param) == 0) {
            int min = ::sched_get_priority_min(sched);
            int max = ::sched_get_priority_max(sched);
            if (pri < min) { pri = min; }
            if (pri > max) { pri = max; }
            /* if max < min, there are system errors, however, if min == max
            chances are the scheduling priority is OS dependant (i.e. min=0, max=0 for SCHED_OTHER)
            thus, the OS will decide the scheduling priority for the thread
            regardless if we set the thread priority. */
            if (max > min) {
                int skip = (max - min) / omni::sync::thread_priority::COUNT;
                /* getting a 'normalized' value that's representative of
                this->m_priority according to the system scheduling policy */
                param.sched_priority = (min + ((pri+2) * (skip+1))) + (skip / 2);
                if (::pthread_setschedparam(this->m_thread, sched, &param) != 0) {
                    OMNI_DBGE(omni::consts::err::ERR_SET_PRIORITY << ": " << OMNI_GLE)
                }
            }
            #if defined(OMNI_SHOW_DEBUG_ERR)
            else { OMNI_DBGEV(omni::consts::err::ERR_SET_PRIORITY, ": sched prio max <= min") }
            #endif
        }
        #if defined(OMNI_SHOW_DEBUG_ERR)
        else { OMNI_DBGE(omni::consts::err::ERR_SET_PRIORITY << ": " << OMNI_GLE) }
        #endif
    #endif
}

omni::sync::thread_priority_t omni::sync::thread::priority() const
{
    OMNI_SAFE_THREAD_ALOCK_FW
    return this->m_priority;
}

void omni::sync::thread::set_priority(omni::sync::thread_priority_t p)
{
    /*
        DEV_NOTE: Thread scheduling is system dependent, this means that even
        though you can ask the scheduler to set a threads priority, it won't always listen.
        Some systems implement a more robust scheduler; OpenBSD for instance implements
        a type of round robin scheduler that schedules threads according to set priority.
        Others implement a load based scheduler; Ubuntu (and quite a few other Linux variants)
        for example implement an approach where by a thread is scheduled on it's priority
        only when the CPU is under heavy stress, otherwise all threads get equal priority.
        
        As such, setting the thread priority is not guaranteed (per MSDN and the POSIX
        documentation), which means while we can give this functionality to you in a
        platform independent manor, be aware that thread priorities are in fact
        system dependent and even the systems themselves state they cannot guarantee
        setting the priority will mean anything.
        
        To a degree this makes sense in the fact that allowing a user land thread to
        have a higher priority than a kernel thread could be potentially harmful, so
        again be aware of this non guaranteed function.
    */
    
    int pri = static_cast<int>(p);
    if (pri < omni::sync::thread_priority::LOWEST) { pri = omni::sync::thread_priority::IDLE; }
    if (pri > omni::sync::thread_priority::HIGHEST) { pri = omni::sync::thread_priority::REAL_TIME; }
    if ((pri < omni::sync::thread_priority::LOWEST && pri != omni::sync::thread_priority::IDLE) ||
        (pri > omni::sync::thread_priority::HIGHEST && pri != omni::sync::thread_priority::REAL_TIME))
    {
        // invalid_priority
        OMNI_ERRV_RET_FW("invalid priority: ", pri, omni::invalid_thread_option(pri))
    }
    OMNI_SAFE_THREAD_LOCK_FW
    // if we're not running, just set the priority til next time
    this->m_priority = static_cast<omni::sync::thread_priority_t>(pri);
    OMNI_SAFE_THREAD_UNLOCK_FW
    if (this->is_alive()) {
        OMNI_SAFE_THREAD_ALOCK_FW
        // we can only set the priority if the thread is running and handle is valid
        if (!this->_hvalid()) {
            OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle())
        } else {
            this->_set_prio();
        }
    }
}

#endif

///////// omni::sync::thread (end) /////////
