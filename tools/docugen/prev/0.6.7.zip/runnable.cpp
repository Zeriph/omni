/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <omni/sync/runnable_thread.hpp>
#if !defined(OMNI_OS_WIN)
    // need the following for POSIX thread set prio/join
    #include <unistd.h>
    #include <sched.h>
    #include <ctime>
    #include <cstring>
#endif
#include <omni/chrono/tick.hpp>
#include <omni/consts/cconsts.hpp>
#include <omni/exception.hpp>

#if defined(OMNI_NON_PORTABLE)
    #define OMNI_RPRIO_FW  ,m_priority(omni::sync::thread_priority::NORMAL)
    #define OMNI_RPRIO_CP_FW ,m_priority(cp.m_priority)
#else
    #define OMNI_RPRIO_FW
    #define OMNI_RPRIO_CP_FW 
#endif
#if defined(OMNI_SAFE_RUNNABLE_THREAD)
    #define OMNI_SAFE_RMTX_FW  m_mtx(),
    #define OMNI_SAFE_RLOCK_FW   this->m_mtx.lock();
    #define OMNI_SAFE_RUNLOCK_FW this->m_mtx.unlock();
    #define OMNI_SAFE_RALOCK_FW  omni::sync::scoped_lock<omni::sync::basic_lock> smal(&this->m_mtx);
#else
    #define OMNI_SAFE_RMTX_FW
    #define OMNI_SAFE_RLOCK_FW
    #define OMNI_SAFE_RUNLOCK_FW
    #define OMNI_SAFE_RALOCK_FW
#endif

///////// static thread management methods /////////

void omni::sync::runnable_thread::_set_context(omni::sync::runnable_thread& t1, const omni::sync::runnable_thread& t2)
{
    #if defined(OMNI_SAFE_RUNNABLE_THREAD)
        t1.m_mtx.lock();
        t2.m_mtx.lock();
    #endif
    t1.state_changed = t2.state_changed;
    t1.m_args = t2.m_args;
    t1.m_ops = t2.m_ops;
    t1.m_iface = t2.m_iface;
    t1.m_state = t2.m_state;
    t1.m_tid = t2.m_tid;
    t1.m_thread = t2.m_thread;
    t1.m_switch = t2.m_switch;
    #if defined(OMNI_NON_PORTABLE)
        t1.m_priority = t2.m_priority;
    #endif
    #if defined(OMNI_SAFE_RUNNABLE_THREAD)
        t2.m_mtx.unlock();
        t1.m_mtx.unlock();
    #endif
}

OMNI_THREAD_FNPTR_T OMNI_THREAD_CALL_T omni::sync::runnable_thread::_start(void* param)
{
    /* runnable's are different from thread or basic_thread in that they are directly managed code.
    That is to say, it doesn't make sense to 'detach' a runnable, so there is no mechanism to do so,
    as such, there is no need to keep "track" of anything other than the pointer to the member
    (and the handle to close it for Windows) since an omni::sync::runnable should be 'owned' by the coder
    and if it's deleted before this thread ends, the results will be undefined */
    omni::sync::runnable_thread *t = static_cast<omni::sync::runnable_thread*>(param);
    #if !defined(OMNI_OS_WIN)
        /*
            we don't check for any errors here as it's not a good idea to ever 'kill' a thread.
            setting to async cancel type sets the cross platform compatibility as TerminateThread
            is 'async' in nature.
            
            !!!! NOTE !!!!
            
            remember, it's a better idea to use 'abort' and the 'state_changed' handler to end
            your threads nicely (avoid resource leaks)
        */
        ::pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
    #endif
    #if defined(OMNI_NON_PORTABLE)
        if (t->m_priority != omni::sync::thread_priority::NORMAL) {
            OMNI_D4_FW("setting thread priority");
            t->_set_prio();
        }
    #endif
    if (t->m_iface) {
        t->_state_changed(omni::sync::thread_state::RUNNING);
        t->m_switch->signal();
        OMNI_TRY_FW
        t->m_iface->run(t->m_args);
        OMNI_CATCH_FW
    } else {
        // shouldn't happen since this should be caught in the calling thread::start
        OMNI_DBGE(omni::consts::err::INVALID_DELEGATE_FUNC_PTR)
        OMNI_THROW_FW(omni::invalid_delegate())
        // if nothrow then act as 'killed'
        t->m_state = omni::sync::thread_state::STOP_REQUESTED;
    }
    // A stop request would mean a user killing this thread, and if that succeeded then we wouldn't get here
    switch (t->m_state) {
        case omni::sync::thread_state::RUNNING:
            t->_state_changed(omni::sync::thread_state::COMPLETED);
            break;
        case omni::sync::thread_state::ABORT_REQUESTED:
            t->_state_changed(omni::sync::thread_state::ABORTED);
            break;
        case omni::sync::thread_state::STOP_REQUESTED:
        case omni::sync::thread_state::UNSTARTED: case omni::sync::thread_state::START_REQUESTED:
        case omni::sync::thread_state::COMPLETED: case omni::sync::thread_state::STOPPED:
        case omni::sync::thread_state::ABORTED: case omni::sync::thread_state::UNKNOWN:
        default:
            t->_state_changed(omni::sync::thread_state::STOPPED);
            break;
    }
    t->_hreset();
    t = 0;
    return 0;
}

///////// public methods /////////

omni::sync::runnable_thread::runnable_thread() : 
    state_changed(),
    OMNI_CTOR_FW(omni::sync::runnable_thread)
    OMNI_SAFE_RMTX_FW
    m_args(NULL),
    m_iface(),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    m_isjoined(false)
    OMNI_RPRIO_FW
{
    this->m_iface = this;
    OMNI_D5_FW("thread created");
}

omni::sync::runnable_thread::runnable_thread(const omni::sync::runnable_thread &cp) : 
    omni::sync::runnable(cp),
    state_changed(cp.state_changed),
    OMNI_CPCTOR_FW(cp)
    OMNI_SAFE_RMTX_FW
    m_args(cp.m_args),
    m_iface(cp.m_iface),
    m_switch(cp.m_switch),
    m_tid(cp.m_tid),
    m_thread(cp.m_thread),
    m_ops(cp.m_ops),
    m_state(cp.m_state),
    m_isjoined(cp.m_isjoined)
    OMNI_RPRIO_CP_FW
{
    OMNI_D5_FW("thread copied");
}

omni::sync::runnable_thread::runnable_thread(const omni::sync::thread_options &ops) : 
    state_changed(),
    OMNI_CTOR_FW(omni::sync::runnable_thread)
    OMNI_SAFE_RMTX_FW
    m_args(NULL),
    m_iface(),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(ops),
    m_state(omni::sync::thread_state::UNSTARTED),
    m_isjoined(false)
    OMNI_RPRIO_FW
{
    this->m_iface = this;
    OMNI_D5_FW("thread const copied");
}

omni::sync::runnable_thread::runnable_thread(std::size_t max_stack_sz) : 
    state_changed(),
    OMNI_CTOR_FW(omni::sync::runnable_thread)
    OMNI_SAFE_RMTX_FW
    m_args(NULL),
    m_iface(),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    m_isjoined(false)
    OMNI_RPRIO_FW
{
    this->m_iface = this;
    //OMNI_DV5_FW("thread created with stack size of ", this->m_ops.stack_size);
}

omni::sync::runnable_thread::runnable_thread(const omni::sync::runnable& obj) :
    state_changed(),
    OMNI_CTOR_FW(omni::sync::runnable_thread)
    OMNI_SAFE_RMTX_FW
    m_args(NULL),
    m_iface(const_cast<omni::sync::runnable*>(&obj)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    m_isjoined(false)
    OMNI_RPRIO_FW
{
    OMNI_D5_FW("thread created with delegate method");
}

omni::sync::runnable_thread::runnable_thread(const omni::sync::runnable& obj, std::size_t max_stack_sz) :
    state_changed(),
    OMNI_CTOR_FW(omni::sync::runnable_thread)
    OMNI_SAFE_RMTX_FW
    m_args(NULL),
    m_iface(const_cast<omni::sync::runnable*>(&obj)),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(max_stack_sz),
    m_state(omni::sync::thread_state::UNSTARTED),
    m_isjoined(false)
    OMNI_RPRIO_FW
{
    OMNI_D5_FW("thread created with delegate method");
}

omni::sync::runnable_thread::runnable_thread(omni::sync::thread_option_t op, omni::sync::thread_union_t val) : 
    state_changed(),
    OMNI_CTOR_FW(omni::sync::runnable_thread)
    OMNI_SAFE_RMTX_FW
    m_args(NULL),
    m_iface(),
    m_switch(0),
    m_tid(0),
    m_thread(0),
    m_ops(),
    m_state(omni::sync::thread_state::UNSTARTED),
    m_isjoined(false)
    OMNI_RPRIO_FW
{
    this->m_iface = this;
    OMNI_D5_FW("thread created with specific options");
    this->set_option(op, val);
}

omni::sync::runnable_thread::~runnable_thread()
{
    OMNI_DTOR_FW    
    OMNI_SAFE_RLOCK_FW
    bool koe = this->m_ops.kill_on_eop;
    bool aj = this->m_ops.auto_join;
    OMNI_SAFE_RUNLOCK_FW
    // join on 'auto_join' unless the user wants to 'kill on external operation'
    if (!koe && aj) { this->join(); }
    this->_kill_on_eop();
    OMNI_SAFE_RLOCK_FW
    this->_close_handle();
    this->m_args = 0;
    OMNI_SAFE_RUNLOCK_FW
    OMNI_D5_FW("destroyed");
}

void omni::sync::runnable_thread::abort()
{
    OMNI_SAFE_RLOCK_FW
    bool valid = this->_hvalid();
    bool running = this->_state_running();
    OMNI_SAFE_RUNLOCK_FW
    if (valid && running) {
        if (valid) {
            this->_state_changed(omni::sync::thread_state::ABORT_REQUESTED);
        } else {
            OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle())
        }
    }
    #if defined(OMNI_DBG_L3)
    else { OMNI_D3_FW("thread is not running"); }
    #endif
}

const omni::sync::thread_union_t omni::sync::runnable_thread::get_option(omni::sync::thread_option_t op) const
{
    OMNI_SAFE_RALOCK_FW
    switch (op) {
        case omni::sync::thread_options::ALLOW_THREAD_REUSE:
            return this->m_ops.allow_reuse;
        case omni::sync::thread_options::AUTO_JOIN:
            return this->m_ops.auto_join;
        case omni::sync::thread_options::KILL_ON_EO:
            return this->m_ops.kill_on_eop;
        case omni::sync::thread_options::STACK_SIZE:
            return this->m_ops.stack_size;
        case omni::sync::thread_options::TIMEOUT_ON_EO:
            return this->m_ops.timeout_on_eop;
        default: // invalid_option
            OMNI_ERRV_FW("invalid option: ", op, omni::invalid_thread_option(static_cast<std::size_t>(op)))
            break;
    }
    return false;
}

omni::sync::thread_options omni::sync::runnable_thread::get_options() const
{
    OMNI_SAFE_RALOCK_FW
    return this->m_ops;
}

const omni::sync::thread_handle_t omni::sync::runnable_thread::handle() const
{
    OMNI_SAFE_RALOCK_FW
    return this->m_thread;
}

const omni::sync::thread_t omni::sync::runnable_thread::id() const
{
    OMNI_SAFE_RALOCK_FW
    return this->m_tid;
}

bool omni::sync::runnable_thread::is_alive() const
{
    OMNI_SAFE_RALOCK_FW
    /*
    DEV_NOTE: we don't use pthread_kill or GetExitCodeThread
    since those might give 'erroneous' results for these purposes.
    That is to say, using JUST those API's will not guarantee
    that our underlying thread is 'actually' running.
    
    omni::sync::thread_state::UNSTARTED = 0,
    // Defines a thread has completed its function (method complete)
    omni::sync::thread_state::COMPLETED = 4,
    // Defines a thread is stopped (killed)
    omni::sync::thread_state::STOPPED = 16,
    // Defines a thread has been aborted
    omni::sync::thread_state::ABORTED = 64,
    // Defines a thread is attempting to spawn
    omni::sync::thread_state::START_REQUESTED = 1,
    
    // Defines a thread is running (method has been called)
    omni::sync::thread_state::RUNNING = 2,
    // Defines a thread has a stop request (kill request)
    omni::sync::thread_state::STOP_REQUESTED = 8,
    // Defines a thread has an abort request
    omni::sync::thread_state::ABORT_REQUESTED = 32,
    // Defines a thread has a state that can not be determined (when creating threads from handles for instance)
    omni::sync::thread_state::UNKNOWN = 255
    */
    return this->_hvalid() && this->_state_running();
}

bool omni::sync::runnable_thread::join()
{
    return this->join(omni::sync::INFINITE_TIMEOUT);
}

bool omni::sync::runnable_thread::join(unsigned long timeout)
{
    // Unknown states can still be joined
    if (!this->is_alive()) {
        OMNI_D2_FW("thread is not running");
        return true;
    }
    OMNI_SAFE_RLOCK_FW
    if (!this->_hvalid()) { 
        OMNI_SAFE_RUNLOCK_FW
        OMNI_ERR_RETV_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle(), false)
    }
    omni::sync::thread_handle_t hndl = this->m_thread;
    #if defined(OMNI_OS_WIN)
        OMNI_SAFE_RUNLOCK_FW
        int ret = ::WaitForSingleObject(OMNI_WIN_TOHNDL(hndl), timeout);
        #if defined(OMNI_DBG_L1)
            if (ret != 0) { OMNI_DBGEV("error while waiting for thread handle: ", OMNI_GLE_PRNT) }
        #endif
        return (ret == 0); // Returns 0 on success
    #else
        /* There is not a portable mechanism with pthreads to wait on a specific thread without
        implementing a timed_wait condition variable. We don't want the user to have to implement
        a seperate variable based on system, so we implement a 'timeout' loop*/
        if (timeout != omni::sync::INFINITE_TIMEOUT) {
            OMNI_SAFE_RUNLOCK_FW
            omni::chrono::tick_t ts = omni::chrono::monotonic_tick();
            OMNI_SLEEP_INIT();
            volatile bool iav = true;
            // iav = (::pthread_kill(this->m_thread, 0) != ESRCH); // == "alive"
            while ((iav = (::pthread_kill(hndl, 0) != ESRCH)) && (omni::chrono::elapsed_ms(ts) < timeout)) {
                OMNI_SLEEP1();
            }
            return (::pthread_kill(hndl, 0) == ESRCH); // == "dead"
        }
        this->m_isjoined = true;
        OMNI_SAFE_RUNLOCK_FW
        int ret = ::pthread_join(hndl, NULL);
        #if defined(OMNI_DBG_L1)
            if (ret != 0) { OMNI_DBGEV("error while waiting for thread handle: ", OMNI_GLE_PRNT) }
        #endif
        return (ret == 0); // Returns 0 on success
    #endif
}

bool omni::sync::runnable_thread::kill()
{
    if (!this->is_alive()) {
        // thread's already 'dead', no need to 'kill'
        OMNI_D2_FW("thread is not running");
        return true;
    }
    OMNI_SAFE_RLOCK_FW
    if (!this->_hvalid()) {
        OMNI_SAFE_RUNLOCK_FW
        OMNI_ERR_RETV_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle(), false)
    }
    int perr = 0;
    OMNI_SAFE_RUNLOCK_FW
    this->_state_changed(omni::sync::thread_state::STOP_REQUESTED);
    OMNI_SAFE_RLOCK_FW
    omni::sync::thread_handle_t hndl = this->m_thread;
    OMNI_SAFE_RUNLOCK_FW
    // attempt to kill it
    #if defined(OMNI_OS_WIN)
        if (::TerminateThread(OMNI_WIN_TOHNDL(hndl), 0) == 0) {
            perr = OMNI_GLE;
        }
    #else
        perr = ::pthread_cancel(hndl);
    #endif
    if (perr == 0) {
        this->_state_changed(omni::sync::thread_state::STOPPED);
        OMNI_SAFE_RLOCK_FW
        this->_hreset();
        OMNI_SAFE_RUNLOCK_FW
        return true;
    }
    OMNI_DV1_FW("thread termination error code: ", perr);
    // Something unknown happened...
    this->_state_changed(omni::sync::thread_state::UNKNOWN);
    return false;
}

bool omni::sync::runnable_thread::reset()
{
    if (this->is_alive()) {        
        OMNI_ERR_RETV_FW("cannot reset thread while running", omni::thread_running_exception(), false)
    } else {
        OMNI_SAFE_RLOCK_FW
        this->_hreset(true);
        OMNI_SAFE_RUNLOCK_FW
    }
    return true;
}

bool omni::sync::runnable_thread::restart()
{
    if (!this->reset()) { return false; }
    this->start();
    return true;
}

bool omni::sync::runnable_thread::restart(void* args)
{
    if (!this->reset()) { return false; }
    this->start(args);
    return true;
}

omni::sync::thread_state_t omni::sync::runnable_thread::status() const
{
    OMNI_SAFE_RALOCK_FW
    return this->m_state;
}

void omni::sync::runnable_thread::set_option(omni::sync::thread_option_t op, omni::sync::thread_union_t val)
{
    OMNI_SAFE_RALOCK_FW
    switch (op) {
        case omni::sync::thread_options::ALLOW_THREAD_REUSE:
            this->m_ops.allow_reuse = val.b_val;
            break;
        case omni::sync::thread_options::AUTO_JOIN:
            this->m_ops.auto_join = val.b_val;
            break;
        case omni::sync::thread_options::KILL_ON_EO:
            this->m_ops.kill_on_eop = val.b_val;
            break;
        case omni::sync::thread_options::STACK_SIZE:
            this->m_ops.stack_size = val.s_val;
            break;
        case omni::sync::thread_options::TIMEOUT_ON_EO:
            this->m_ops.timeout_on_eop = val.s_val;
            break;
        default: // invalid_option
            OMNI_ERRV_FW("invalid option: ", op, omni::invalid_thread_option(static_cast<std::size_t>(op)))
            break;
    }
}

void omni::sync::runnable_thread::set_options(const omni::sync::thread_options &ops)
{
    OMNI_SAFE_RALOCK_FW
    this->m_ops.allow_reuse = ops.allow_reuse;
    this->m_ops.auto_join = ops.auto_join;
    this->m_ops.kill_on_eop = ops.kill_on_eop;
    this->m_ops.stack_size = ops.stack_size;
    this->m_ops.timeout_on_eop = ops.timeout_on_eop;
}

void omni::sync::runnable_thread::start()
{
    this->start(NULL);
}

void omni::sync::runnable_thread::start(void *args)
{
    OMNI_SAFE_RLOCK_FW
    if (this->m_state != omni::sync::thread_state::UNSTARTED) {
        if (this->m_ops.allow_reuse) {
            // thread reuse is enabled, so reset the handles
            this->_hreset(true);
        } else {
            OMNI_SAFE_RUNLOCK_FW
            OMNI_ERR_RET_FW("can not start a thread once it has been started or if it is in an unknown state", omni::thread_running_exception())
        }
    }
    if (this->m_iface == 0) {
        OMNI_SAFE_RUNLOCK_FW
        // no delegate attached to this thread so we can't actually start anything
        OMNI_ERR_RET_FW(omni::consts::err::INVALID_DELEGATE_FUNC_PTR, omni::invalid_delegate())
    }
    int perr = 0;
    omni::sync::thread_state_t ostate = this->m_state;
    this->m_args = args;
    this->m_thread = 0;
    this->m_state = omni::sync::thread_state::START_REQUESTED;
    OMNI_SAFE_RUNLOCK_FW
    this->state_update(ostate);
    if (this->state_changed) { this->state_changed(*this, ostate); }
    OMNI_SAFE_RLOCK_FW
    this->m_switch = new omni::sync::spin_wait(); // signaled set in _start
    #if defined(OMNI_OS_WIN)
        OMNI_TMPIDT_FW tmptid = 0;
        this->m_thread = OMNI_CREATE_THREAD_FW(NULL,                            // default security attr
                                              this->m_ops.stack_size,            // stack size
                                              &omni::sync::runnable_thread::_start, // _start(void*)
                                              static_cast<void*>(this),         // *see above dev note
                                              0,                                // start now
                                              &tmptid);                         // thread id
        // Win32 returns !0 for a valid thread, 0 means error
        if (this->m_thread == 0) { perr = OMNI_GLE; } // error, set perr
        else { this->m_tid = static_cast<omni::sync::thread_t>(tmptid); } // success, set tid
    #else
        // if any of these fails, then thread creation should fail
        if (this->m_ops.stack_size == 0) {
            perr = ::pthread_create(&this->m_tid,                   // the thread id
                                    NULL,                           // stack size == 0, so null attributes
                                    &omni::sync::runnable_thread::_start, // _start(void*)
                                    static_cast<void*>(this));      // *see above dev note
            if (perr == 0) {
                this->m_thread = this->m_tid; // copy TID to m_thread handle
            } else {
                OMNI_ERRV_FW("system create thread failed: ", perr, omni::thread_exception("Create system thread failed: ", perr));
            }
        } else {
            pthread_attr_t attr;
            perr = ::pthread_attr_init(&attr);
            if (perr == 0) {
                perr = ::pthread_attr_setstacksize(&attr, this->m_ops.stack_size);
                if (perr == 0) {
                    perr = ::pthread_create(&this->m_tid,                     // the thread id
                                            &attr,                            // stack size
                                            &omni::sync::runnable_thread::_start, // _start(void*)
                                            static_cast<void*>(this));        // *see above  dev note
                    if (perr == 0) {
                        this->m_thread = this->m_tid; // copy TID to m_thread handle
                    } else {
                        OMNI_SAFE_RUNLOCK_FW
                        OMNI_ERRV_FW("system create thread failed: ", perr, omni::thread_exception("Create system thread failed: ", perr))
                    }
                } else {
                    OMNI_SAFE_RUNLOCK_FW
                    OMNI_ERR_FW("could not set stack size of " << this->m_ops.stack_size << ": " << perr, omni::thread_exception("System error setting stack size: ", perr));
                }
                if (perr == 0) {
                    // Destroy the attributes handle
                    perr = ::pthread_attr_destroy(&attr);
                    if (perr != 0) {
                        OMNI_SAFE_RUNLOCK_FW
                        /* in theory this should only ever happen if 'attr' is not valid
                        but to be safe we want to alert the user since this could signal
                        other issues (we also don't want any rouge handles not being
                        destroyed, ie a memory leak) */
                        OMNI_ERRV_FW("could not destroy attributes: ", perr, omni::thread_exception("Could not destroy attributes: ", perr));
                    }
                } else {
                    /* if we got here then there were other errors in thread creation, so
                    don't reset the perr value, just call the function */
                    ::pthread_attr_destroy(&attr);
                }
            } else {
                OMNI_SAFE_RUNLOCK_FW
                OMNI_ERR_FW("could not initialize thread attributes @" << &attr << ": " << perr, omni::thread_exception("Could not initialize thread attributes: ", perr));
            }
        }
    #endif
    OMNI_SAFE_RUNLOCK_FW
    if (perr == 0) {
        OMNI_D4_FW("thread handle valid, waiting for thread switch");
        // valid handle so wait until the thread is actually reported as started
        this->m_switch->sleep_wait();
        delete this->m_switch;
        this->m_switch = 0;
    } else {
        delete this->m_switch;
        this->m_switch = 0;
        this->m_thread = 0;
        OMNI_ERRV_FW("could not create system thread: ", perr, omni::thread_exception(perr))
    }
    OMNI_D3_FW(((this->m_tid == 0) ? "invalid" : "created") << " thread:" << this->m_tid);
}

void omni::sync::runnable_thread::swap(omni::sync::runnable_thread &o)
{
    if (this != &o) {
        // if the address' of the two are not ==, then swap
        omni::sync::runnable_thread *tmp = new omni::sync::runnable_thread(o); // get a copy
        omni::sync::runnable_thread::_set_context(o, *this);
        omni::sync::runnable_thread::_set_context(*this, *tmp);
        delete tmp;
    }
}

omni::sync::runnable_thread &omni::sync::runnable_thread::operator=(const omni::sync::runnable_thread &o)
{
    if (this != &o) {
        this->_kill_on_eop();
        OMNI_ASSIGN_FW(o)
        omni::sync::runnable_thread::_set_context(*this, o);
    }
    return *this;
}

bool omni::sync::runnable_thread::operator==(const omni::sync::runnable_thread &o) const
{
    if (this == &o) { return true; }
    #if defined(OMNI_SAFE_RUNNABLE_THREAD)
        omni::sync::scoped_lock<omni::sync::basic_lock> am(&this->m_mtx);
        omni::sync::scoped_lock<omni::sync::basic_lock> am2(&o.m_mtx);
    #endif
    return (this->state_changed == o.state_changed &&
        this->m_args == o.m_args &&
        this->m_ops == o.m_ops &&
        this->m_iface == o.m_iface &&
        this->m_state == o.m_state &&
        this->m_tid == o.m_tid &&
        this->m_thread == o.m_thread &&
        this->m_switch == o.m_switch
        #if defined(OMNI_NON_PORTABLE)
            && this->m_priority == o.m_priority
        #endif
        OMNI_EQUAL_FW(o)
        );
}

bool omni::sync::runnable_thread::operator!=(const omni::sync::runnable_thread &o) const
{
    return !(*this == o);
}

///////// start private methods /////////

void omni::sync::runnable_thread::_close_handle()
{
    this->m_state = omni::sync::thread_state::UNSTARTED;
    if (this->m_thread != 0) {
        // detach the handle so the OS can cleanup when it's done
        #if defined(OMNI_OS_WIN)
            ::CloseHandle(OMNI_WIN_TOHNDL(this->m_thread));
        #else
            if (!this->m_isjoined) {
                /* if we've called pthread_join on this thread then don't detach
                it as that releases it's resources and makes it 'unjoinable' */
                ::pthread_detach(this->m_thread);
            }
            this->m_isjoined = false;
        #endif
    }
    this->m_tid = 0;
    this->m_thread = 0;
}

void omni::sync::runnable_thread::_hreset(bool force)
{
    #if defined(OMNI_NON_PORTABLE)
        this->m_priority = omni::sync::thread_priority::NORMAL;
    #endif
    if (this->m_ops.allow_reuse || force) { this->_close_handle(); }
}

bool omni::sync::runnable_thread::_hvalid() const
{
    return (this->m_thread != 0);
}

void omni::sync::runnable_thread::_kill_on_eop()
{
    OMNI_SAFE_RLOCK_FW
    bool koe = this->m_ops.kill_on_eop;
    std::size_t to = this->m_ops.timeout_on_eop;
    OMNI_SAFE_RUNLOCK_FW
    // Check if the user wants the thread to hang around but destroy the thread object
    if (koe) {
        // First call abort
        this->abort();
        // wait the specified timeout (if set)
        if (to > 0) { this->join(to); }
        if (this->is_alive()) {
            OMNI_D5_FW("thread still alive after abort and wait, killing");
            // The thread is still running so abort it
            this->kill();
        }
    }
}

bool omni::sync::runnable_thread::_state_running() const
{
    OMNI_SAFE_RALOCK_FW
    return (this->m_state == omni::sync::thread_state::RUNNING ||
            this->m_state == omni::sync::thread_state::STOP_REQUESTED ||
            this->m_state == omni::sync::thread_state::ABORT_REQUESTED ||
            this->m_state == omni::sync::thread_state::UNKNOWN);
}

void omni::sync::runnable_thread::_state_changed(omni::sync::thread_state_t nstate)
{
    OMNI_SAFE_RLOCK_FW
    omni::sync::thread_state_t ostate = this->m_state;
    this->m_state = nstate;
    OMNI_SAFE_RUNLOCK_FW
    this->state_update(ostate);
    if (this->state_changed) { this->state_changed(*this, ostate); }
}

///////// non portable methods /////////

#if defined(OMNI_NON_PORTABLE)

void omni::sync::runnable_thread::_set_prio()
{
    int pri = static_cast<int>(this->m_priority);
    OMNI_DV4_FW("changing priority to ", pri);
    /* we don't throw an error if we can't set the thread priority since the
    OS could decide not to do it any ways or the system may not support it */ 
    #if defined(OMNI_OS_WIN)
        if (::SetThreadPriority(OMNI_WIN_TOHNDL(this->m_thread), pri) == 0) {
            OMNI_DBGE(omni::consts::err::ERR_SET_PRIORITY << ": " << OMNI_GLE)
        }
    #else
        int sched = 0;
        struct sched_param param;
        std::memset(&param, 0, sizeof(sched_param));
        if (pthread_getschedparam(this->m_thread, &sched, &param) == 0) {
            int min = ::sched_get_priority_min(sched);
            int max = ::sched_get_priority_max(sched);
            if (pri < min) { pri = min; }
            if (pri > max) { pri = max; }
            /* if max < min, there are system errors, however, if min == max
            chances are the scheduling priority is OS dependant (i.e. min=0, max=0 for SCHED_OTHER)
            thus, the OS will decide the scheduling priority for the thread
            regardless if we set the thread priority. */
            if (max > min) {
                int skip = (max - min) / omni::sync::thread_priority::COUNT;
                /* getting a 'normalized' value that's representative of
                this->m_priority according to the system scheduling policy */
                param.sched_priority = (min + ((pri+2) * (skip+1))) + (skip / 2);
                if (::pthread_setschedparam(this->m_thread, sched, &param) != 0) {
                    OMNI_DBGE(omni::consts::err::ERR_SET_PRIORITY << ": " << OMNI_GLE)
                }
            }
            #if defined(OMNI_SHOW_DEBUG_ERR)
            else { OMNI_DBGEV(omni::consts::err::ERR_SET_PRIORITY, ": sched prio max <= min") }
            #endif
        }
        #if defined(OMNI_SHOW_DEBUG_ERR)
        else { OMNI_DBGE(omni::consts::err::ERR_SET_PRIORITY << ": " << OMNI_GLE) }
        #endif
    #endif
}

omni::sync::thread_priority_t omni::sync::runnable_thread::priority() const
{
    OMNI_SAFE_RALOCK_FW
    return this->m_priority;
}

void omni::sync::runnable_thread::set_priority(omni::sync::thread_priority_t p)
{
    /*
        DEV_NOTE: Thread scheduling is system dependent, this means that even
        though you can ask the scheduler to set a threads priority, it won't always listen.
        Some systems implement a more robust scheduler; OpenBSD for instance implements
        a type of round robin scheduler that schedules threads according to set priority.
        Others implement a load based scheduler; Ubuntu (and quite a few other Linux variants)
        for example implement an approach where by a thread is scheduled on it's priority
        only when the CPU is under heavy stress, otherwise all threads get equal priority.
        
        As such, setting the thread priority is not guaranteed (per MSDN and the POSIX
        documentation), which means while we can give this functionality to you in a
        platform independent manor, be aware that thread priorities are in fact
        system dependent and even the systems themselves state they cannot guarantee
        setting the priority will mean anything.
        
        To a degree this makes sense in the fact that allowing a user land thread to
        have a higher priority than a kernel thread could be potentially harmful, so
        again be aware of this non guaranteed function.
    */
    
    int pri = static_cast<int>(p);
    if (pri < omni::sync::thread_priority::LOWEST) { pri = omni::sync::thread_priority::IDLE; }
    if (pri > omni::sync::thread_priority::HIGHEST) { pri = omni::sync::thread_priority::REAL_TIME; }
    if ((pri < omni::sync::thread_priority::LOWEST && pri != omni::sync::thread_priority::IDLE) ||
        (pri > omni::sync::thread_priority::HIGHEST && pri != omni::sync::thread_priority::REAL_TIME))
    {
        // invalid_priority
        OMNI_ERRV_RET_FW("invalid priority: ", pri, omni::invalid_thread_option(pri))
    }
    OMNI_SAFE_RLOCK_FW
    // if we're not running, just set the priority til next time
    this->m_priority = static_cast<omni::sync::thread_priority_t>(pri);
    OMNI_SAFE_RUNLOCK_FW
    if (this->is_alive()) {
        OMNI_SAFE_RALOCK_FW
        // we can only set the priority if the thread is running and handle is valid
        if (!this->_hvalid()) {
            OMNI_ERR_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle())
        } else {
            this->_set_prio();
        }
    }
}

#endif
