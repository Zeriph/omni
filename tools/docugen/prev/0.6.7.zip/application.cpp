/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <omni/defs/global.hpp>
#if defined(OMNI_OS_WIN)
    #include <windows.h>
    #if !defined(OMNI_SIGCALL_FW)
        #define OMNI_SIGCALL_FW __cdecl // for signal
    #endif
#endif
#if !defined(OMNI_SIGCALL_FW)
    #define OMNI_SIGCALL_FW
#endif
#include <csignal>
#include <cerrno>
#include <signal.h>
#include <errno.h>
#include <clocale>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <omni/application.hpp>
#include <omni/strings.hpp>
#include <omni/system.hpp>
#include <omni/constants.hpp>
#include <omni/sync/conditional.hpp>
#include <omni/sync/thread.hpp>

//============================START BASE METHODS============================/

#if defined(OMNI_SAFE_APPLICATION)
    #include <omni/sync/basic_lock.hpp>
    #define OMNI_SAFE_AMTX_FW static omni::sync::basic_lock m_mtx;
    #define OMNI_SAFE_APP_LOCK_FW m_mtx.lock();
    #define OMNI_SAFE_APP_UNLOCK_FW m_mtx.unlock();
    #define OMNI_SAFE_APP_ALOCK_FW omni::sync::scoped_lock<omni::sync::basic_lock> mal(&m_mtx);
#else
    #define OMNI_SAFE_AMTX_FW 
    #define OMNI_SAFE_APP_LOCK_FW 
    #define OMNI_SAFE_APP_UNLOCK_FW 
    #define OMNI_SAFE_APP_ALOCK_FW 
#endif

/* DEV_NOTE: Signal handlers are expected to have C linkage and, in general, only 
use the features from the common subset of C and C++. It is implementation-defined 
if a function with C++ linkage can be used as a signal handler. */

static omni::action m_exit;
static omni::action m_appstart;
static omni::action m_appshut;
static omni::event1<void, int> m_signal_recieved;
static omni::application::argparser m_args;
static omni::sync::thread m_bt;
static omni::sync::conditional m_wt;
static volatile bool m_isrun; // is omni::app running?
static volatile bool m_igsig; // user cancel signal request
static int m_sig;
static int m_ret;
OMNI_SAFE_AMTX_FW

static void base_set_handlers();

static void OMNI_SIGCALL_FW base_msg_pump(int sig)
{
    OMNI_SAFE_APP_LOCK_FW
    m_sig = sig;
    OMNI_SAFE_APP_UNLOCK_FW
    OMNI_DV1_FW("signal recieved: ", sig);
    if (m_signal_recieved) { m_signal_recieved(sig); }
    else {
        // DEV_NOTE: SIGINT is 'caught' here but will do nothing in a Win environment (base_win_ctrl_handler handles that)
        switch (sig) {
            #if !defined(OMNI_WIN_API)
                // SIGINT is caught by the console handler in windows
                case SIGINT: break; // signal interrupt: typically occurs when user interrupts the program (like when pressing CTRL+C)
            #endif
            case SIGABRT: break; // signal abort: abnormal termination
            case SIGFPE:  break; // signal floating point exception: occurs on erroneous arithmetic operations (like division by 0)
            case SIGILL:  break; // signal illegal instruction: typically occurs with code corruption
            case SIGSEGV: break; // signal segmentation violation: typically occurs when the program tries to read/write invalid memory
            case SIGTERM: break; // signal terminate: termination request sent to the program
            default: break; // unknown signal
        }
    }
    OMNI_SAFE_APP_LOCK_FW
    m_wt.signal();
    OMNI_SAFE_APP_UNLOCK_FW
}

#if defined(OMNI_WIN_API)
static BOOL WINAPI base_win_ctrl_handler(DWORD sig)
{
    OMNI_SAFE_APP_LOCK_FW
    m_sig = sig;
    OMNI_SAFE_APP_UNLOCK_FW
    OMNI_DV1_FW("signal recieved: ", sig);
    if (m_signal_recieved) { m_signal_recieved(sig); }
    else {
        // Here you can handle special cases before the callback gets raised
        switch (sig) {
            case CTRL_C_EVENT:        break; // signal when CTRL+C received
            case CTRL_BREAK_EVENT:    break; // signal when CTRL+BREAK received
            case CTRL_CLOSE_EVENT:    break; // signal when console window being closed
            case CTRL_LOGOFF_EVENT:   break; // signal when user being logged off
            case CTRL_SHUTDOWN_EVENT: break; // signal when system is shutting down
            default: break; // unknown signal
        }
    }
    OMNI_SAFE_APP_LOCK_FW
    m_wt.signal();
    OMNI_SAFE_APP_UNLOCK_FW
    return 1; // tell WinAPI this handler succeeded, don't call others
}
#endif

static void base_thread_completed(const omni::sync::thread& sender)
{
    OMNI_UNUSED(sender);
    OMNI_SAFE_APP_LOCK_FW
    m_wt.signal();
    OMNI_SAFE_APP_UNLOCK_FW
}

static void base_app_exit()
{
    if (m_exit) { m_exit(); }
}

static void base_set_handlers()
{
    // We attach the signal handlers but don't die or throw an error because we want
    // to at least allow program execution even if we can't catch external signals
    if (std::signal(SIGABRT, &base_msg_pump) == SIG_ERR) {
        OMNI_DBGE("error attaching SIGABRT");
    }
    if (std::signal(SIGFPE, &base_msg_pump) == SIG_ERR) {
        OMNI_DBGE("error attaching SIGFPE");
    }
    if (std::signal(SIGILL, &base_msg_pump) == SIG_ERR) {
        OMNI_DBGE("error attaching SIGILL");
    }
    if (std::signal(SIGSEGV, &base_msg_pump) == SIG_ERR) {
        OMNI_DBGE("error attaching SIGSEGV");
    }
    if (std::signal(SIGTERM, &base_msg_pump) == SIG_ERR) {
        OMNI_DBGE("error attaching SIGTERM");
    }
    if (std::signal(SIGINT, &base_msg_pump) == SIG_ERR) {
        OMNI_DBGE("error attaching SIGINT");
    }
    // DEV_NOTE: might get warning about 'old-style cast' with the
    // SIG_ERR def (could be defined as (void (*)(int))-1 .. C-style cast in #def)
}

static bool base_init()
{
    OMNI_SAFE_APP_ALOCK_FW
    if (m_isrun) {
        OMNI_ERR_RETV_FW("An omni::application context is already running", omni::context_running_exception(), false)
    }
    m_isrun = false;
    #if !defined(OMNI_NO_BASE_SETLOCALE)
        std::setlocale(LC_ALL, ""); // set the local to accept all (for proper println'ing and string handling)
    #endif
    OMNI_D5_FW("attaching signal handlers");
    base_set_handlers();
    #if defined(OMNI_WIN_API)
        if (::SetConsoleCtrlHandler(base_win_ctrl_handler, 1) != 0) {
            OMNI_DBGEV("Could not set the console control handler: ", OMNI_GLE)
        }
    #endif
    std::atexit(&base_app_exit);
    return true;
}

static void base_spawn(const omni::sync::thread_start& start_func, bool exit_with_work_thread)
{
    OMNI_D2_FW("spawning app thread...");
    OMNI_SAFE_APP_LOCK_FW
    m_ret = 0;
    if (start_func) {
        m_bt.bind(start_func);
        m_bt.set_option(omni::sync::thread_options::KILL_ON_EO, false);
        if (exit_with_work_thread) { m_bt.completed += &base_thread_completed; }
        m_bt.start();
    }
    m_isrun = true;
    OMNI_SAFE_APP_UNLOCK_FW
}

static void base_spawn(const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread)
{
    OMNI_D2_FW("spawning app thread...");
    OMNI_SAFE_APP_LOCK_FW
    m_ret = 0;
    if (start_func) {
        m_bt.bind(start_func);
        m_bt.set_option(omni::sync::thread_options::KILL_ON_EO, false);
        if (exit_with_work_thread) { m_bt.completed += &base_thread_completed; }
        m_bt.start(targs);
    }
    m_isrun = true;
    OMNI_SAFE_APP_UNLOCK_FW
}

static int base_run(bool kill_worker_on_signal)
{
    OMNI_D2_FW("entering base application loop...");
    if (m_appstart) { m_appstart(); }
    do {
        m_wt.wait();
        OMNI_SAFE_APP_LOCK_FW
        // if user set cancel signal request, loop until they 'unset' it
        if (m_igsig) {
            m_wt.reset();
            // signal specifies that the signal handlers can be reset back to the default handler
            // so we must 're-install' the signal handlers to us to be able to continue to catch
            // we don't need to 're-install' the WinAPI base_win_ctrl_handler
            base_set_handlers();
        }
        OMNI_SAFE_APP_UNLOCK_FW
    } while (m_igsig);
    if (kill_worker_on_signal) {
        if (m_bt.is_alive()) { m_bt.kill(); }
    } else {
        m_bt.join(); // wait on worker thread
    }
    OMNI_SAFE_APP_LOCK_FW
    if (m_appshut) {
        OMNI_SAFE_APP_UNLOCK_FW
        m_appshut();
        OMNI_SAFE_APP_LOCK_FW
    }
    int ret = m_ret;
    m_isrun = false;
    OMNI_SAFE_APP_UNLOCK_FW
    OMNI_DV2_FW("base application thread complete, returning ", ret);
    return ret;
}

static int base_spawn_and_run(const omni::sync::thread_start& start_func, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    if (base_init()) {
        base_spawn(start_func, exit_with_work_thread);
        return base_run(kill_worker_on_signal);
    }
    return -1;
}

static int base_spawn_and_run(const int& argc, const char** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    if (base_init()) {
        omni::application::set_args(argc, argv);
        base_spawn(start_func, exit_with_work_thread);
        return base_run(kill_worker_on_signal);
    }
    return -1;
}

static int base_spawn_and_run(const int& argc, const wchar_t** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    if (base_init()) {
        omni::application::set_args(argc, argv);
        base_spawn(start_func, exit_with_work_thread);
        return base_run(kill_worker_on_signal);
    }
    return -1;
}

static int base_spawn_and_run(const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    if (base_init()) {
        base_spawn(start_func, targs, exit_with_work_thread);
        return base_run(kill_worker_on_signal);
    }
    return -1;
}

static int base_spawn_and_run(const int& argc, const char** argv, const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    if (base_init()) {
        omni::application::set_args(argc, argv);
        base_spawn(start_func, targs, exit_with_work_thread);
        return base_run(kill_worker_on_signal);
    }
    return -1;
}

static int base_spawn_and_run(const int& argc, const wchar_t** argv, const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    if (base_init()) {
        omni::application::set_args(argc, argv);
        base_spawn(start_func, targs, exit_with_work_thread);
        return base_run(kill_worker_on_signal);
    }
    return -1;
}

//=============================END BASE METHODS=============================/

//============================START APP_NS METHODS============================/

void omni::application::exit_handler::attach(const omni::callback& exit_func)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_exit += exit_func;
}

void omni::application::exit_handler::detach(const omni::callback& exit_func)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_exit -= exit_func;
}

void omni::application::startup_handler::attach(const omni::callback& start_func)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_appstart += start_func;
}

void omni::application::startup_handler::detach(const omni::callback& start_func)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_appstart -= start_func;
}

void omni::application::shutdown_handler::attach(const omni::callback& shutdown_func)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_appshut += shutdown_func;
}

void omni::application::shutdown_handler::detach(const omni::callback& shutdown_func)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_appshut -= shutdown_func;
}

void omni::application::signal_handler::attach(const omni::application::signal_handler::callback& sig_func)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_signal_recieved += sig_func;
}

void omni::application::signal_handler::detach(const omni::application::signal_handler::callback& sig_func)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_signal_recieved -= sig_func;
}

void omni::application::signal_handler::ignore(bool cancel)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_igsig = cancel;
}

omni::application::argparser& omni::application::args()
{
    OMNI_SAFE_APP_ALOCK_FW
    return m_args;
}

int omni::application::last_signal()
{
    OMNI_SAFE_APP_ALOCK_FW
    return m_sig;
}

int omni::application::run(const int& argc, const char** argv, const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread)
{
    return base_spawn_and_run(argc, argv, start_func, targs, exit_with_work_thread, false);
}

int omni::application::run(const int& argc, const char** argv, const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    return base_spawn_and_run(argc, argv, start_func, targs, exit_with_work_thread, kill_worker_on_signal);
}

int omni::application::run(const int& argc, const char** argv)
{
    return base_spawn_and_run(argc, argv, 0, 0, false, false);
}

int omni::application::run(const int& argc, const wchar_t** argv, const omni::sync::parameterized_thread_start& start_func, void *targs, bool exit_with_work_thread)
{
    return base_spawn_and_run(argc, argv, start_func, targs, exit_with_work_thread, false);
}

int omni::application::run(const int& argc, const wchar_t** argv, const omni::sync::parameterized_thread_start& start_func, void *targs, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    return base_spawn_and_run(argc, argv, start_func, targs, exit_with_work_thread, kill_worker_on_signal);
}

int omni::application::run(const int& argc, const wchar_t** argv)
{
    return base_spawn_and_run(argc, argv, 0, 0, false, false);
}

int omni::application::run(const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread)
{
    return base_spawn_and_run(start_func, targs, exit_with_work_thread, false);
}

int omni::application::run(const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    return base_spawn_and_run(start_func, targs, exit_with_work_thread, kill_worker_on_signal);
}

int omni::application::run(const omni::sync::parameterized_thread_start& start_func, void* targs)
{
    return base_spawn_and_run(start_func, targs, false, false);
}

int omni::application::run(const omni::sync::parameterized_thread_start& start_func)
{
    return base_spawn_and_run(start_func, 0, false, false);
}

int omni::application::run(const int& argc, const char** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread)
{
    return base_spawn_and_run(argc, argv, start_func, exit_with_work_thread, false);
}

int omni::application::run(const int& argc, const char** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    return base_spawn_and_run(argc, argv, start_func, exit_with_work_thread, kill_worker_on_signal);
}

int omni::application::run(const int& argc, const wchar_t** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread)
{
    return base_spawn_and_run(argc, argv, start_func, exit_with_work_thread, false);
}

int omni::application::run(const int& argc, const wchar_t** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    return base_spawn_and_run(argc, argv, start_func, exit_with_work_thread, kill_worker_on_signal);
}

int omni::application::run(const omni::sync::thread_start& start_func, bool exit_with_work_thread)
{
    return base_spawn_and_run(start_func, exit_with_work_thread, false);
}

int omni::application::run(const omni::sync::thread_start& start_func, bool exit_with_work_thread, bool kill_worker_on_signal)
{
    return base_spawn_and_run(start_func, exit_with_work_thread, kill_worker_on_signal);
}

int omni::application::run(const omni::sync::thread_start& start_func)
{
    return base_spawn_and_run(start_func, false, false);
}

int omni::application::run()
{
    return base_spawn_and_run(0, 0, false, false);
}

void omni::application::set_return_code(int return_code)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_ret = return_code;
}

void omni::application::set_args(const int& argc, const char** argv)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_args.set(argc, argv);
}

void omni::application::set_args(const int& argc, const wchar_t** argv)
{
    OMNI_SAFE_APP_ALOCK_FW
    m_args.set(argc, argv);
}

void omni::application::stop()
{
    OMNI_SAFE_APP_LOCK_FW
    if (m_isrun) {
        m_igsig = false;
        m_wt.signal();
    }
    OMNI_SAFE_APP_UNLOCK_FW
    base_app_exit();
    OMNI_D4_FW("base exited, calling system exit");
    #if defined(OMNI_WIN_API)
        ::ExitProcess(1);
    #else
        std::exit(1);
    #endif
}

//=============================END APP_NS METHODS=============================/
