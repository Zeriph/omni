/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_HELPER_HPP)
#define OMNI_HELPER_HPP 1

// macro helper functions

#define OMNI_DEF2STR_FW(x) #x
#define OMNI_DEF2STR(x) OMNI_DEF2STR_FW(x)

#define OMNI_DEFCONCAT_FW(A, B) A ## B
#define OMNI_DEFCONCAT(A, B) OMNI_DEFCONCAT_FW(A, B)

#define OMNI_BOOL2STR(bval) (bval ? "true" : "false")
#define OMNI_BOOL2STRW(bval) (bval ? L"true" : L"false")

#define OMNI_UNUSED(val) (static_cast<void>(val))

#if !defined(OMNI_WSTR)
    #define OMNI_WSTR(v) L##v
    #define OMNI_DWSTR(v) L#v
#endif

#if !defined(OMNI_DATE) && defined(__DATE__)
    #undef OMNI_DATE
    #define OMNI_DATE __DATE__
#endif
#if !defined(OMNI_TIME) && defined(__TIME__)
    #undef OMNI_TIME
    #define OMNI_TIME __TIME__
#endif

#if !defined(OMNI_DATE)
    #define OMNI_DATE Jan 1 1970
#endif
#if !defined(OMNI_TIME)
    #define OMNI_TIME 00:00:00
#endif

#define OMNI_XOR_SWAP(a, b) a ^= b; b ^= a; a ^= b;

#define OMNI_BIND_EX(DelegateType, Class, Function, Obj) DelegateType::bind<Class, &Class::Function>(obj)
#define OMNI_BIND_CONST_EX(DelegateType, Class, Function, Obj) DelegateType::bind_const<Class, &Class::Function>(obj)

#endif // OMNI_HELPER_HPP
