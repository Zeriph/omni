/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_COMPILE_FLAGS_HPP)
#define OMNI_COMPILE_FLAGS_HPP 1

#if defined(OMNI_COMPILE_FLAGS)

#include <omni/defs/global.hpp>
#include <omni/defs/class_macros.hpp>
#include <omni/types/lock_t.hpp>
#include <omni/types/thread_t.hpp>
#include <omni/types/char_t.hpp>
#include <omni/types/tick_t.hpp>

namespace omni {
    /** Defines run time constant values of compile time flags */
    namespace compile_flags {
        // OMNI_FW_VER_STR
        extern const char OMNI_FW_VER_STR_VALUE[];
        // OMNI_THREAD_CALL_T
        extern const char OMNI_THREAD_CALL_T_VALUE[];
        // OMNI_MUTEX_T
        extern const char OMNI_MUTEX_T_VALUE[];
        // OMNI_SPIN_LOCK_T
        extern const char OMNI_SPIN_LOCK_T_VALUE[];
        // OMNI_SEM_T
        extern const char OMNI_SEM_T_VALUE[];
        // OMNI_COND_T
        extern const char OMNI_COND_T_VALUE[];
        // OMNI_THREAD_T
        extern const char OMNI_THREAD_T_VALUE[];
        // OMNI_THREAD_HANDLE_T
        extern const char OMNI_THREAD_HANDLE_T_VALUE[];
        // OMNI_THREAD_FNPTR_T
        extern const char OMNI_THREAD_FNPTR_T_VALUE[];
        // OMNI_THREAD_RET_T
        extern const char OMNI_THREAD_RET_T_VALUE[];
        // OMNI_CHAR_T
        extern const char OMNI_CHAR_T_VALUE[];
        // OMNI_STRING_T
        extern const char OMNI_STRING_T_VALUE[];
        // OMNI_SSTREAM_T
        extern const char OMNI_SSTREAM_T_VALUE[];
        // OMNI_CLOCK_TICK_T
        extern const char OMNI_CLOCK_TICK_T_VALUE[];
        // OMNI_CLOCK_FREQ_T
        extern const char OMNI_CLOCK_FREQ_T_VALUE[];
        // OMNI_DBG_L1
        extern const bool OMNI_DBG_L1_VALUE;
        // OMNI_DBG_L2
        extern const bool OMNI_DBG_L2_VALUE;
        // OMNI_DBG_L3
        extern const bool OMNI_DBG_L3_VALUE;
        // OMNI_DBG_L4
        extern const bool OMNI_DBG_L4_VALUE;
        // OMNI_DBG_L5
        extern const bool OMNI_DBG_L5_VALUE;
        // OMNI_DBG_L6
        extern const bool OMNI_DBG_L6_VALUE;
        // OMNI_DBG_L7
        extern const bool OMNI_DBG_L7_VALUE;
        // OMNI_DBG_L8
        extern const bool OMNI_DBG_L8_VALUE;
        // OMNI_DEBUG
        extern const bool OMNI_DEBUG_VALUE;
        // OMNI_LITE
        extern const bool OMNI_LITE_VALUE;
        // OMNI_MUTEX_OWNER
        extern const bool OMNI_MUTEX_OWNER_VALUE;
        // OMNI_NO_BASE_SETLOCALE
        extern const bool OMNI_NO_BASE_SETLOCALE_VALUE;
        // OMNI_NO_CSTRING_IMPL
        extern const bool OMNI_NO_CSTRING_IMPL_VALUE;
        // OMNI_NO_FW_VER
        extern const bool OMNI_NO_FW_VER_VALUE;
        // OMNI_NO_MUTEX_OWNER
        extern const bool OMNI_NO_MUTEX_OWNER_VALUE;
        // OMNI_NO_SAFE_APPLICATION
        extern const bool OMNI_NO_SAFE_APPLICATION_VALUE;
        // OMNI_NO_SAFE_CONDITIONAL
        extern const bool OMNI_NO_SAFE_CONDITIONAL_VALUE;
        // OMNI_NO_SAFE_DELEGATES
        extern const bool OMNI_NO_SAFE_DELEGATES_VALUE;
        // OMNI_NO_SAFE_EVENTS
        extern const bool OMNI_NO_SAFE_EVENTS_VALUE;
        // OMNI_NO_SAFE_FRAMEWORK
        extern const bool OMNI_NO_SAFE_FRAMEWORK_VALUE;
        // OMNI_NO_SAFE_PROP
        extern const bool OMNI_NO_SAFE_PROP_VALUE;
        // OMNI_NO_SAFE_SEMAPHORE
        extern const bool OMNI_NO_SAFE_SEMAPHORE_VALUE;
        // OMNI_NO_SAFE_TIMER
        extern const bool OMNI_NO_SAFE_TIMER_VALUE;
        // OMNI_NO_SAFE_THREAD
        extern const bool OMNI_NO_SAFE_THREAD_VALUE;
        // OMNI_NO_SAFE_BASIC_THREAD
        extern const bool OMNI_NO_SAFE_BASIC_THREAD_VALUE;
        // OMNI_NO_SAFE_RUNNABLE_THREAD
        extern const bool OMNI_NO_SAFE_RUNNABLE_THREAD_VALUE;
        // OMNI_NO_TERMINATE
        extern const bool OMNI_NO_TERMINATE_VALUE;
        // OMNI_NO_THROW
        extern const bool OMNI_NO_THROW_VALUE;
        // OMNI_NO_TYPE_INFO
        extern const bool OMNI_NO_TYPE_INFO_VALUE;
        // OMNI_NO_OBJECT_NAME
        extern const bool OMNI_NO_OBJECT_NAME_VALUE;
        // OMNI_NO_DISPOSE_EVENT
        extern const bool OMNI_NO_DISPOSE_EVENT_VALUE;
        // OMNI_NO_WIN_API
        extern const bool OMNI_NO_WIN_API_VALUE;
        // OMNI_NO_WSTRING_IMPL
        extern const bool OMNI_NO_WSTRING_IMPL_VALUE;
        // OMNI_NON_PORTABLE
        extern const bool OMNI_NON_PORTABLE_VALUE;
        // OMNI_OS_IGNORE 
        extern const bool OMNI_OS_IGNORE_VALUE;
        // OMNI_SAFE_APPLICATION
        extern const bool OMNI_SAFE_APPLICATION_VALUE;
        // OMNI_SAFE_DELEGATES
        extern const bool OMNI_SAFE_DELEGATES_VALUE;
        // OMNI_SAFE_EVENTS
        extern const bool OMNI_SAFE_EVENTS_VALUE;
        // OMNI_SAFE_FRAMEWORK
        extern const bool OMNI_SAFE_FRAMEWORK_VALUE;
        // OMNI_SAFE_PROP
        extern const bool OMNI_SAFE_PROP_VALUE;
        // OMNI_SAFE_SEMAPHORE
        extern const bool OMNI_SAFE_SEMAPHORE_VALUE;
        // OMNI_SAFE_TIMER
        extern const bool OMNI_SAFE_TIMER_VALUE;
        // OMNI_SAFE_THREAD
        extern const bool OMNI_SAFE_THREAD_VALUE;
        // OMNI_SAFE_BASIC_THREAD
        extern const bool OMNI_SAFE_BASIC_THREAD_VALUE;
        // OMNI_SAFE_RUNNABLE_THREAD
        extern const bool OMNI_SAFE_RUNNABLE_THREAD_VALUE;
        // OMNI_SHOW_DEBUG
        extern const bool OMNI_SHOW_DEBUG_VALUE;
        // OMNI_SHOW_DEBUG_ERR
        extern const bool OMNI_SHOW_DEBUG_ERR_VALUE;
        // OMNI_SHOW_DEBUG_FILE
        extern const bool OMNI_SHOW_DEBUG_FILE_VALUE;
        // OMNI_SHOW_DEBUG_FUNC
        extern const bool OMNI_SHOW_DEBUG_FUNC_VALUE;
        // OMNI_SHOW_DEBUG_LINE
        extern const bool OMNI_SHOW_DEBUG_LINE_VALUE;
        // OMNI_TERMINATE
        extern const bool OMNI_TERMINATE_VALUE;
        // OMNI_THREAD_CDECL
        extern const bool OMNI_THREAD_CDECL_VALUE;
        // OMNI_THREAD_FASTCALL
        extern const bool OMNI_THREAD_FASTCALL_VALUE;
        // OMNI_THREAD_STDCALL
        extern const bool OMNI_THREAD_STDCALL_VALUE;
        // OMNI_THROW
        extern const bool OMNI_THROW_VALUE;
        // OMNI_TYPE_INFO
        extern const bool OMNI_TYPE_INFO_VALUE;
        // OMNI_OBJECT_NAME
        extern const bool OMNI_OBJECT_NAME_VALUE;
        // OMNI_DISPOSE_EVENT
        extern const bool OMNI_DISPOSE_EVENT_VALUE;
        // OMNI_UNICODE
        extern const bool OMNI_UNICODE_VALUE;
        // OMNI_WIN_API
        extern const bool OMNI_WIN_API_VALUE;
        // OMNI_WIN_USE_EVENT_CONDITIONAL
        extern const bool OMNI_WIN_USE_EVENT_CONDITIONAL_VALUE;
        // OMNI_WINCODE
        extern const bool OMNI_WINCODE_VALUE;
    }
}

#endif // OMNI_COMPILE_FLAGS

#endif // OMNI_COMPILE_FLAGS_HPP
