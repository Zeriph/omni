/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* DEV_NOTE: this file is not intended to be used directly by any user code!

 i.e. don't #include <omni/xxx_impl.hxx> and don't compile this source directly.
 this file is #include'd directly in other source.

*/

#include <omni/util/version.hpp>
#include <omni/string/cstring.hpp>

/* these defines are used (instead of just using the defaults)
to aid in compiler times and memory usage (the compiler doesn't
have to rearrange the variables on construction to match the way
the class is built, as well it doesn't have to do extra padding) */
#if defined(OMNI_DISPOSE_EVENT)
    #define OMNI_VERSION_DIS_FW disposing(),
    #define OMNI_VERSION_DISCP_FW disposing(cp.disposing),
#else
    #define OMNI_VERSION_DIS_FW 
    #define OMNI_VERSION_DISCP_FW
#endif
#if defined(OMNI_OBJECT_NAME)
    #define OMNI_VERSION_NAME_FW name(OMNI_STRW("omni::util::version")),
    #define OMNI_VERSION_NAMECP_FW name(cp.name),
#else
    #define OMNI_VERSION_NAME_FW 
    #define OMNI_VERSION_NAMECP_FW
#endif
#if defined(OMNI_TYPE_INFO)
    #define OMNI_VERSION_TI_FW m_type(),
#else
    #define OMNI_VERSION_TI_FW
#endif 
#define OMNI_VERSION_CTOR_FW OMNI_VERSION_DIS_FW OMNI_VERSION_NAME_FW
#define OMNI_VERSION_CPCTOR_FW OMNI_VERSION_DISCP_FW OMNI_VERSION_NAMECP_FW

omni::util::version::version(unsigned int mj) :
    OMNI_VERSION_CTOR_FW
    OMNI_VERSION_TI_FW
    m_maj(mj), m_min(0), m_bld(0), m_rev(0)
{
    OMNI_DV5_FW("created version ", this->to_string_t());
}

omni::util::version::version(unsigned int mj, unsigned int mn) :
    OMNI_VERSION_CTOR_FW
    OMNI_VERSION_TI_FW
    m_maj(mj), m_min(mn), m_bld(0), m_rev(0)
{
    OMNI_DV5_FW("created version ", this->to_string_t());
}

omni::util::version::version(unsigned int mj, unsigned int mn, unsigned int bld) :
    OMNI_VERSION_CTOR_FW
    OMNI_VERSION_TI_FW
    m_maj(mj), m_min(mn), m_bld(bld), m_rev(0)
{
    OMNI_DV5_FW("created version ", this->to_string_t());
}

omni::util::version::version(unsigned int mj, unsigned int mn, unsigned int bld, unsigned int rev) :
    OMNI_VERSION_CTOR_FW
    OMNI_VERSION_TI_FW
    m_maj(mj), m_min(mn), m_bld(bld), m_rev(rev)
{
    OMNI_DV5_FW("created version ", this->to_string_t());
}

omni::util::version::version(const std::string& v) :
    OMNI_VERSION_CTOR_FW
    OMNI_VERSION_TI_FW
    m_maj(0), m_min(0), m_bld(0), m_rev(0)
{
    this->_tryparse(v);
    OMNI_DV5_FW("created version ", this->to_string_t());
}

omni::util::version::version(const std::wstring& v) :
    OMNI_VERSION_CTOR_FW
    OMNI_VERSION_TI_FW
    m_maj(0), m_min(0), m_bld(0), m_rev(0)
{
    this->_tryparse(omni::string::util::to_string(v));
    OMNI_DV5_FW("created version ", this->to_string_t());
}

omni::util::version::version(const omni::util::version& cp) :
    OMNI_VERSION_CPCTOR_FW
    OMNI_VERSION_TI_FW
    m_maj(cp.m_maj), m_min(cp.m_min), m_bld(cp.m_bld), m_rev(cp.m_rev)
{
    OMNI_DV5_FW("created version ", this->to_string_t());
}

omni::util::version::~version()
{
    OMNI_DTOR_FW
}

omni::util::version::operator std::string() const
{
    return this->to_string();
}

omni::util::version::operator std::wstring() const
{
    return this->to_wstring();
}

omni::util::version& omni::util::version::operator=(const omni::util::version& o)
{
    OMNI_ASSIGN_FW(o)
    this->m_maj = o.m_maj;
    this->m_min = o.m_min;
    this->m_bld = o.m_bld;
    this->m_rev = o.m_rev;
    return *this;
}

omni::util::version& omni::util::version::operator=(const std::string& s)
{
    this->_tryparse(s);
    return *this;
}

omni::util::version& omni::util::version::operator=(const std::wstring& w)
{
    this->_tryparse(omni::cstring::to_string(w));
    return *this;
}

bool omni::util::version::operator==(const std::string& s) const
{
    omni::util::version t(s);
    return (*this == t);
}

bool omni::util::version::operator==(const std::wstring& s) const
{
    omni::util::version t(s);
    return (*this == t);
}

bool omni::util::version::operator==(const omni::util::version& o) const
{
    if (this == &o) { return true; }
    return (this->m_maj == o.m_maj &&
            this->m_min == o.m_min &&
            this->m_bld == o.m_bld &&
            this->m_rev == o.m_rev)
            OMNI_EQUAL_FW(o);
}

bool omni::util::version::operator!=(const omni::util::version &o) const
{
    return !(*this == o);
}

OMNI_SEQ_T<std::string> omni::util::version::_parse(const std::string& v)
{
    OMNI_SEQ_T<std::string> s = omni::cstring::split(v, ".");
    if (s.size() > 4) {
        OMNI_ERR_RETV_FW("Invalid version string specified", omni::version_exception(), OMNI_SEQ_T<std::string>())
    }
    OMNI_SEQ_T<std::string>::const_iterator it = s.begin();
    while (it != s.end()) {
        if (it->empty() || !omni::cstring::is_numeric(*it)) {
            OMNI_ERR_RETV_FW("Invalid version string specified", omni::version_exception(), OMNI_SEQ_T<std::string>())
        }
        ++it;
    }
    return s;
}

void omni::util::version::_tryparse(const std::string& v)
{
    OMNI_SEQ_T<std::string> l = omni::util::version::_parse(v);
    // if we've gotten here, presumably no errors so zero out
    this->m_maj = this->m_min = this->m_bld = this->m_rev = 0;
    OMNI_SEQ_T<std::string>::const_iterator it = l.begin();
    if (it != l.end()) { this->m_maj = omni::cstring::type_cast<unsigned int>(*it); ++it; }
    if (it != l.end()) { this->m_min = omni::cstring::type_cast<unsigned int>(*it); ++it; }
    if (it != l.end()) { this->m_bld = omni::cstring::type_cast<unsigned int>(*it); ++it; }
    if (it != l.end()) { this->m_rev = omni::cstring::type_cast<unsigned int>(*it); ++it; }
}
