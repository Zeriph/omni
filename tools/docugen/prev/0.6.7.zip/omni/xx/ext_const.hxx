/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
/* DEV_NOTE: this file is not intended to be used directly by any user code!

 i.e. don't #include <omni/xxx_impl.hxx> and don't compile this source directly.
 this file is #include'd directly in other source. 
 
 The idea is that omni::cconsts and omni::wconsts namespaces segregate the types
 for explicit calling; i.e. you can call omni::cconsts::X for a std:string type
 and similarly can call omni::wconsts::X for a std::wstring type, while still having access
 to the omni::string_t and omn::consts::X ability (which are aliases for the other namespaces).
 
 Since omni::cconsts and omni::wconsts are merely wrappers for string types
 putting the relevant code in a header with a few #defs for types makes keeping the files
 in sync (for names) less messy. It does introduce slight confusion to anyone who might
 want to read this specific code or documentation though.
*/

// so as not to accidentally build this file with the source
// these macros are defined in cconsts.hpp and wconsts.hpp
#if !defined(OMNI_CHAR_T_FW) || !defined(OMNI_STRW_FW) || !defined(OMNI_EXT_NS_FW)
    #error invalid preprocessor directive detected
#endif

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::DELEGATE_NOT_FOUND[]= OMNI_STRW_FW("Delegate not found");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::ERR_GET_TIME[]= OMNI_STRW_FW("An error occurred getting the clock time");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::ERR_MEM_ALLOC[]= OMNI_STRW_FW("Error allocating memory");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::ERR_OPEN_PARENT_PROC[]= OMNI_STRW_FW("Error opening process");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::ERR_RET_PRI_CLASS[]= OMNI_STRW_FW("Error retrieving the process' priority class");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::ERR_SET_PRIORITY[]= OMNI_STRW_FW("Error setting the thread's priority");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::FILE_NOT_FOUND[]= OMNI_STRW_FW("File not found");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::FILE_NOT_ACCESSIBLE[]= OMNI_STRW_FW("File not accessible");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::GENERAL_EXCEPTION[]= OMNI_STRW_FW("General framework exception");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INDEX_OOR[]= OMNI_STRW_FW("Index out of range");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_BASE[]= OMNI_STRW_FW("Invalid base specified while converting to string");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_CHAR[]= OMNI_STRW_FW("Invalid value specified for conversion to char");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_CAST[]= OMNI_STRW_FW("Invalid type cast");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_DELEGATE[]= OMNI_STRW_FW("Invalid delegate");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_DELEGATE_FUNC_PTR[]= OMNI_STRW_FW("No valid function has been assigned to the delegate");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_OPTION[]= OMNI_STRW_FW("An invalid thread option was specified");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_SETTING[]= OMNI_STRW_FW("An invalid setting was specified");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_SEEK_DIR[]= OMNI_STRW_FW("Invalid seek direction");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_THREAD_HANDLE[]= OMNI_STRW_FW("Invalid thread handle");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_THREAD_PRIORITY[]= OMNI_STRW_FW("Invalid thread priority");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_THREAD_START_TYPE[]= OMNI_STRW_FW("Invalid thread start type specified");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_SIZE[]= OMNI_STRW_FW("Invalid size specified");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::INVALID_TYPE_CAST[]= OMNI_STRW_FW("Invalid type cast");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::PATH_NOT_ACCESSIBLE[]= OMNI_STRW_FW("Path not accessible");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::SET_PRI_UNSUPPORTED[]= OMNI_STRW_FW("Setting thread priority is not supported on this system");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::STRING_COUNT_GT0[]= OMNI_STRW_FW("Count must be greater than 0");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::STRING_INVALID_BINARY_FORMAT[]= OMNI_STRW_FW("The specified string does not contain a valid binary number");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::STRING_INVALID_BINARY_STR_SZ[]= OMNI_STRW_FW("The binary string length is greater than sizeof conversion unit");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::STRING_NOT_NUMERIC[]= OMNI_STRW_FW("The specified string is not a valid numeric value");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::SUCCESS[]= OMNI_STRW_FW("Success");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::err::UNKNOWN[]= OMNI_STRW_FW("Unknown");

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::misc::COMMA = OMNI_STRW_FW(',');
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::misc::MINUS = OMNI_STRW_FW('-');
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::misc::NCHAR = OMNI_STRW_FW('\0');
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::misc::PERIOD = OMNI_STRW_FW('.');
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::misc::PLUS = OMNI_STRW_FW('+');

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::full::B[]= OMNI_STRW_FW("Byte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::full::KB[]= OMNI_STRW_FW("Kibibyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::full::MB[]= OMNI_STRW_FW("Mebibyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::full::GB[]= OMNI_STRW_FW("Gibibyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::full::TB[]= OMNI_STRW_FW("Tebibyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::full::PB[]= OMNI_STRW_FW("Pebibyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::full::EB[]= OMNI_STRW_FW("Exbibyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::full::ZB[]= OMNI_STRW_FW("Zebibyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::full::YB[]= OMNI_STRW_FW("Yobibyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::B[]= OMNI_STRW_FW("B");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::KB[]= OMNI_STRW_FW("KiB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::MB[]= OMNI_STRW_FW("MiB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::GB[]= OMNI_STRW_FW("GiB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::TB[]= OMNI_STRW_FW("TiB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::PB[]= OMNI_STRW_FW("PiB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::EB[]= OMNI_STRW_FW("EiB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::ZB[]= OMNI_STRW_FW("ZiB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::bin::str::YB[]= OMNI_STRW_FW("YiB");

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::full::B[]= OMNI_STRW_FW("Byte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::full::KB[]= OMNI_STRW_FW("Kilobyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::full::MB[]= OMNI_STRW_FW("Megabyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::full::GB[]= OMNI_STRW_FW("Gigabyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::full::TB[]= OMNI_STRW_FW("Terabyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::full::PB[]= OMNI_STRW_FW("Petabyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::full::EB[]= OMNI_STRW_FW("Exabyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::full::ZB[]= OMNI_STRW_FW("Zettabyte");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::full::YB[]= OMNI_STRW_FW("Yottabyte");

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::B[]= OMNI_STRW_FW("B");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::KB[]= OMNI_STRW_FW("KB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::MB[]= OMNI_STRW_FW("MB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::GB[]= OMNI_STRW_FW("GB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::TB[]= OMNI_STRW_FW("TB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::PB[]= OMNI_STRW_FW("PB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::EB[]= OMNI_STRW_FW("EB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::ZB[]= OMNI_STRW_FW("ZB");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::sz::dec::str::YB[]= OMNI_STRW_FW("YB");

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::prio::IDLE[]= OMNI_STRW_FW("IDLE");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::prio::LOWEST[]= OMNI_STRW_FW("LOWEST");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::prio::BELOW_NORMAL[]= OMNI_STRW_FW("BELOW_NORMAL");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::prio::NORMAL[]= OMNI_STRW_FW("NORMAL");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::prio::ABOVE_NORMAL[]= OMNI_STRW_FW("ABOVE_NORMAL");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::prio::HIGHEST[]= OMNI_STRW_FW("HIGHEST");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::prio::REAL_TIME[]= OMNI_STRW_FW("REAL_TIME");

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::start_type::USER[]= OMNI_STRW_FW("USER");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::start_type::NOW[]= OMNI_STRW_FW("NOW");

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::status::UNSTARTED[]= OMNI_STRW_FW("UNSTARTED");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::status::START_REQUESTED[]= OMNI_STRW_FW("START_REQUESTED");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::status::RUNNING[]= OMNI_STRW_FW("RUNNING");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::status::COMPLETED[]= OMNI_STRW_FW("COMPLETED");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::status::STOP_REQUESTED[]= OMNI_STRW_FW("STOP_REQUESTED");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::status::STOPPED[]= OMNI_STRW_FW("STOPPED");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::status::ABORT_REQUESTED[]= OMNI_STRW_FW("ABORT_REQUESTED");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::status::ABORTED[]= OMNI_STRW_FW("ABORTED");

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::thread_op::ALLOW_THREAD_REUSE[]= OMNI_STRW_FW("ALLOW_THREAD_REUSE");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::thread_op::AUTO_JOIN[]= OMNI_STRW_FW("AUTO_JOIN");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::thread_op::KILL_ON_EO[]= OMNI_STRW_FW("KILL_ON_EO");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::thread_op::STACK_SIZE[]= OMNI_STRW_FW("STACK_SIZE");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::thread_op::TIMEOUT_ON_EO[]= OMNI_STRW_FW("TIMEOUT_ON_EO");

OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::threadpool_status::EMPTY[]= OMNI_STRW_FW("EMPTY");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::threadpool_status::LT_MIN[]= OMNI_STRW_FW("LT_MIN");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::threadpool_status::MINIMUM[]= OMNI_STRW_FW("MINIMUM");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::threadpool_status::GT_MIN[]= OMNI_STRW_FW("GT_MIN");
OMNI_CHAR_T_FW OMNI_EXT_NS_FW::threading::threadpool_status::MAXIMUM[]= OMNI_STRW_FW("MAXIMUM");
