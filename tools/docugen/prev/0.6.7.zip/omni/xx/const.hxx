/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
/* DEV_NOTE: this file is not intended to be used directly by any user code!

 i.e. don't #include <omni/xxx_impl.hxx> and don't compile this source directly.
 this file is #include'd directly in other source. 
 
 The idea is that omni::cconsts and omni::wconsts namespaces segregate the types
 for explicit calling; i.e. you can call omni::cconsts::X for a std:string type
 and similarly can call omni::wconsts::X for a std::wstring type, while still having access
 to the omni::string_t and omn::consts::X ability (which are aliases for the other namespaces).
 
 Since omni::cconsts and omni::wconsts are merely wrappers for string types
 putting the relevant code in a header with a few #defs for types makes keeping the files
 in sync (for names) less messy. It does introduce slight confusion to anyone who might
 want to read this specific code or documentation though.
*/

// so as not to accidentally build this file with the source
// these macros are defined in cconsts.hpp and wconsts.hpp
#if !defined(OMNI_CHAR_T_FW) || !defined(OMNI_STRW_FW)
    #error invalid preprocessor directive detected
#endif

// namespace omni::consts/cconsts/wconsts {

/** Facilitate constant error strings */
namespace err {
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW DELEGATE_NOT_FOUND[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Delegate not found"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ERR_GET_TIME[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("An error occurred getting the clock time"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ERR_MEM_ALLOC[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Error allocating memory"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ERR_OPEN_PARENT_PROC[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Error opening process"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ERR_RET_PRI_CLASS[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Error retrieving the process' priority class"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ERR_SET_PRIORITY[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Error setting the thread's priority"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW FILE_NOT_FOUND[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("File not found"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW FILE_NOT_ACCESSIBLE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("File not accessible"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW GENERAL_EXCEPTION[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("General framework exception"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INDEX_OOR[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Index out of range"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_BASE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid base specified while converting to string"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_CHAR[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid value specified for conversion to char"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_CAST[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid type cast"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_DELEGATE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid delegate"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_DELEGATE_FUNC_PTR[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("No valid function has been assigned to the delegate"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_OPTION[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("An invalid thread option was specified"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_SETTING[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("An invalid setting was specified"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_SEEK_DIR[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid seek direction"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_THREAD_HANDLE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid thread handle"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_THREAD_PRIORITY[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid thread priority"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_THREAD_START_TYPE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid thread start type specified"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_SIZE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid size specified"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW INVALID_TYPE_CAST[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Invalid type cast"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW PATH_NOT_ACCESSIBLE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Path not accessible"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW SET_PRI_UNSUPPORTED[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Setting thread priority is not supported on this system"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW STRING_COUNT_GT0[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Count must be greater than 0"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW STRING_INVALID_BINARY_FORMAT[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("The specified string does not contain a valid binary number"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW STRING_INVALID_BINARY_STR_SZ[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("The binary string length is greater than sizeof conversion unit"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW STRING_NOT_NUMERIC[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("The specified string is not a valid numeric value"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW SUCCESS[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Success"));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW UNKNOWN[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Unknown"));
}

/** Miscellaneous constants */
namespace misc {
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW COMMA OMNI_EXT_ASSN_FW(= OMNI_STRW_FW(','));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW MINUS OMNI_EXT_ASSN_FW(= OMNI_STRW_FW('-'));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW NCHAR OMNI_EXT_ASSN_FW(= OMNI_STRW_FW('\0'));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW PERIOD OMNI_EXT_ASSN_FW(= OMNI_STRW_FW('.'));
    OMNI_CONSTEXT_FW OMNI_CHAR_T_FW PLUS OMNI_EXT_ASSN_FW(= OMNI_STRW_FW('+'));
}

/** Facilitates size constants */
namespace sz {
    /** Facilitates binary size constants (1KB == 1024B) */
    namespace bin {
        /** Facilitates binary size abbreviated string constants (B, KiB, MiB, etc.) */
        namespace str {
            /** Facilitates binary size unabbreviated string constants (Byte, Kibibyte, etc.) */
            namespace full {
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW B[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Byte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW KB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Kibibyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW MB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Mebibyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW GB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Gibibyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW TB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Tebibyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW PB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Pebibyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW EB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Exbibyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ZB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Zebibyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW YB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Yobibyte"));
            }
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW B[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("B"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW KB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("KiB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW MB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("MiB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW GB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("GiB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW TB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("TiB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW PB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("PiB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW EB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("EiB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ZB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("ZiB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW YB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("YiB"));
        }
    }
    /** Facilitates decimal size constants (1KB == 1000B) */
    namespace dec {
        /** Facilitates decimal size abbreviated string constants (B, KB, MB, etc.) */
        namespace str {
            /** Facilitates decimal size unabbreviated string constants (Byte, Kilobyte, etc.) */
            namespace full {
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW B[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Byte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW KB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Kilobyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW MB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Megabyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW GB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Gigabyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW TB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Terabyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW PB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Petabyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW EB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Exabyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ZB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Zettabyte"));
                OMNI_CONSTEXT_FW OMNI_CHAR_T_FW YB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("Yottabyte"));
            }
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW B[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("B"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW KB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("KB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW MB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("MB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW GB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("GB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW TB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("TB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW PB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("PB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW EB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("EB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ZB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("ZB"));
            OMNI_CONSTEXT_FW OMNI_CHAR_T_FW YB[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("YB"));
        }
    }
}

/** Constants for the threading namespace to_string */
namespace threading {
    namespace prio {
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW IDLE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("IDLE"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW LOWEST[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("LOWEST"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW BELOW_NORMAL[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("BELOW_NORMAL"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW NORMAL[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("NORMAL"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ABOVE_NORMAL[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("ABOVE_NORMAL"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW HIGHEST[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("HIGHEST"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW REAL_TIME[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("REAL_TIME"));
    }
    namespace start_type {
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW USER[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("USER"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW NOW[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("NOW"));
    }
    namespace status {
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW UNSTARTED[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("UNSTARTED"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW START_REQUESTED[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("START_REQUESTED"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW RUNNING[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("RUNNING"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW COMPLETED[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("COMPLETED"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW STOP_REQUESTED[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("STOP_REQUESTED"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW STOPPED[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("STOPPED"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ABORT_REQUESTED[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("ABORT_REQUESTED"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ABORTED[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("ABORTED"));
    }
    namespace thread_op {
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW ALLOW_THREAD_REUSE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("ALLOW_THREAD_REUSE"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW AUTO_JOIN[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("AUTO_JOIN"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW KILL_ON_EO[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("KILL_ON_EO"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW STACK_SIZE[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("STACK_SIZE"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW TIMEOUT_ON_EO[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("TIMEOUT_ON_EO"));
    }
    namespace threadpool_status {
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW EMPTY[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("EMPTY"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW LT_MIN[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("LT_MIN"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW MINIMUM[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("MINIMUM"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW GT_MIN[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("GT_MIN"));
        OMNI_CONSTEXT_FW OMNI_CHAR_T_FW MAXIMUM[] OMNI_EXT_ASSN_FW(= OMNI_STRW_FW("MAXIMUM"));
    }
}

// } namespace omni::consts/cconsts/wconsts
    