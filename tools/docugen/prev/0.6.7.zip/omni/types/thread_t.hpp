/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_THREAD_T_HPP)
#define OMNI_THREAD_T_HPP 1
#include <omni/defs/global.hpp>
#include <omni/types/char_t.hpp>
#include <omni/chrono/tick.hpp>
#include <omni/constants.hpp>
#include <omni/delegate/0.hpp>
#include <omni/delegate/1.hpp>
#include <omni/delegate/2.hpp>
#include <omni/defs/thread_def.hpp>

namespace omni {
    namespace sync {
        /** Defines the signature for a thread start delegate taking no arguments */
        typedef omni::delegate<void> thread_start;
        /** Defines the signature for a thread start delegate taking the default void* argument */
        typedef omni::delegate1<void, void*> parameterized_thread_start;
        /** Defines the platform infinite time out value */
        const unsigned long INFINITE_TIMEOUT = OMNI_INFINITE_TIMEOUT;
        /** Defines the platform thread type */
        typedef OMNI_THREAD_T thread_t;
        /** Defines the platform thread handle type */
        typedef OMNI_THREAD_HANDLE_T thread_handle_t;
        /** Defines the platform thread function pointer type (void* / int, etc) */
        typedef OMNI_THREAD_FNPTR_T thread_fnptr_t;
        /** Defines the platform thread function return type */
        typedef OMNI_THREAD_RET_T thread_ret_t;

        /** The priority structure defines enum values for the scheduling priority of a process or thread. */
        typedef struct thread_priority {
            /** The underlying enum type exposed via the parent priority structure */
            typedef enum enum_t {
                /** Defines an idle thread priority */
                IDLE = -15,
                /** Defines a low thread priority */
                LOWEST = -2,
                /** Defines a below normal thread priority */
                BELOW_NORMAL = -1,
                /** Defines a normal thread priority */
                NORMAL = 0,
                /** Defines an above normal thread priority */
                ABOVE_NORMAL = 1,
                /** Defines a highest thread priority */
                HIGHEST = 2,
                /** Defines a real time thread priority */
                REAL_TIME = 15
            } enum_t;
            /** Defines the number of elements in the priority enum */
            static const unsigned short COUNT = 7;
            /** Converts the enum to its string representation */
            OMNI_E7STR_FW(prio, IDLE, LOWEST, BELOW_NORMAL, NORMAL, ABOVE_NORMAL, HIGHEST, REAL_TIME)
        } thread_priority;
        /** The thread start type (immediate or user) */
        typedef struct thread_start_type {
            /** The underlying enum type expected */
            typedef enum enum_t {
                /** Defines the thread will start when the user calls the start method */
                USER = 0,
                /** Defines the thread will start after construction is complete */
                NOW = 1
            } enum_t;
            /** Defines the number of elements in the start_type enum */
            static const unsigned short COUNT = 2;
            /** Converts the enum to its string representation */
            OMNI_E2STR_FW(start_type, USER, NOW)
        } thread_start_type;
        /** The state structure defines enum values for the execution status of thread types */
        typedef struct thread_state {
            /** The underlying enum type exposed via the parent state structure */
            typedef enum enum_t {
                /** Defines a thread as unstarted (default when created) */
                UNSTARTED = 0,
                /** Defines a thread is attempting to spawn */
                START_REQUESTED = 1,
                /** Defines a thread is running (method has been called) */
                RUNNING = 2,
                /** Defines a thread has completed its function (method complete) */
                COMPLETED = 4,
                /** Defines a thread has a stop request (kill request) */
                STOP_REQUESTED = 8,
                /** Defines a thread is stopped (killed) */
                STOPPED = 16,
                /** Defines a thread has an abort request */
                ABORT_REQUESTED = 32,
                /** Defines a thread has been aborted */
                ABORTED = 64,
                /** Defines a thread has a state that can not be determined (when creating threads from handles for instance) */
                UNKNOWN = 255
            } enum_t;
            /** Defines the number of elements in the state enum */
            static const unsigned short COUNT = 9;
            /** Converts the enum to its string representation */
            OMNI_E8STR_FW(status, UNSTARTED, START_REQUESTED, RUNNING, COMPLETED, STOP_REQUESTED, STOPPED, ABORT_REQUESTED, ABORTED)
        } thread_state;
        /** The structure used to pass task/args to a threadpool thread */
        typedef struct threadpool_task {
            /** The task */
            omni::sync::parameterized_thread_start task;
            /** The parameters (if any) to pass to the thread task */
            void* param;
            
            threadpool_task() : task(), param(NULL) {}
            threadpool_task(const omni::sync::threadpool_task& cp) : task(cp.task), param(cp.param) {}
            explicit threadpool_task(omni::sync::parameterized_thread_start t) : task(t), param(NULL) {}
            threadpool_task(omni::sync::parameterized_thread_start t, void* p) : task(t), param(p) {}
            ~threadpool_task() { param = 0; }
            
            threadpool_task& operator=(const omni::sync::threadpool_task& o)
            {
                if (this != &o) {
                    this->task = o.task;
                    this->param = o.param;
                }
                return *this;
            }
        } threadpool_task;
        /** Defines the thread options structure allowing finer control of a thread object */
        typedef struct thread_options {
            /** The underlying enum type exposed via the parent thread_option structure */
            typedef enum enum_t {
                /** Defines the option to set if the thread shall allow reuse of the thread */
                ALLOW_THREAD_REUSE = 1,
                /** Defines the option to auto join a thread on destruction */
                AUTO_JOIN = 2,
                /** Defines the option to set if the thread shall be killed on assignment (external) operation */
                KILL_ON_EO = 4,
                /** Defines the option to set if the thread shall have a specified stack size */
                STACK_SIZE = 16,
                /** Defines the option to set if the thread timeout for join operation on kill_on_eop */
                TIMEOUT_ON_EO = 32
            } enum_t;
            /** Defines the number of elements in the thread_option enum */
            static const unsigned short COUNT = 5;
            /** Converts the enum to its string representation */
            OMNI_E5STR_FW(thread_op, ALLOW_THREAD_REUSE, AUTO_JOIN, KILL_ON_EO, STACK_SIZE, TIMEOUT_ON_EO)
            
            // thread_options
            /**
             * The threads stack size. If the thread is in running state,
             * the new stack size will not take effect until the next run.
             */
            std::size_t stack_size;
            /**
             * If timeout_on_eop is >0 and kill_on_eop has been set for
             * thread, when an external operation is being applied
             * the thread will attempt to abort and join for the
             * specified timeout beforing killing the thread
             */
            std::size_t timeout_on_eop;
            /**
             * When the thread has completed by any means (completed, abort, kill, etc)
             * and this flag is true, the current thread instance can be restarted without
             * having to instantiate a new thread object (i.e. a thread object can call 
             * the start function when the thread has completed without a new object).
             */
            bool allow_reuse;
            /**
             * If this flag is true when the thread object is being destroyed and is
             * in a running state, the thread will be joined on destruction.
             */
            bool auto_join;
            /**
             *  If this flag is true and the thread is being destroyed or is running and
             *  being assigned to (thrd = x), the thread will call abort then forcefully
             *  terminate (kill) before completing the attempted operation
             */
            bool kill_on_eop;
            
            /** The default constructor, all values zeroed */
            thread_options() : 
                stack_size(0),
                timeout_on_eop(0),
                allow_reuse(false),
                auto_join(false),
                kill_on_eop(false)
                { }
            
            /**
             * Stack size constructor; initializes the
             * structure with specified stack size
             * (specifically non-explicit constructor)
             *
             * @param ss    The stack size to set
             */
            thread_options(std::size_t ss) : 
                stack_size(ss),
                timeout_on_eop(0),
                allow_reuse(false),
                auto_join(false),
                kill_on_eop(false)
                { }
                
            /**
             * The copy constructor
             *
             * @param cp    The other structure to copy
             */
            thread_options(const omni::sync::thread_options &cp) :
                stack_size(cp.stack_size),
                timeout_on_eop(cp.timeout_on_eop),
                allow_reuse(cp.allow_reuse),
                auto_join(cp.auto_join),
                kill_on_eop(cp.kill_on_eop)
                { }
                
            /**
             * Equality operator tests if objects are equal
             * 
             * @param o     The other structure to test
             */
            bool operator==(const omni::sync::thread_options& o) const
            {
                return
                (this->allow_reuse == o.allow_reuse &&
                this->auto_join == o.auto_join &&
                this->kill_on_eop == o.kill_on_eop &&
                this->stack_size == o.stack_size &&
                this->timeout_on_eop == o.timeout_on_eop);
            }
            
            /**
             * Assignment operator sets values from the other object
             * 
             * @param o     The other structure to assign from
             */
            omni::sync::thread_options& operator=(const omni::sync::thread_options& o)
            {
                if (this != &o) {
                    this->allow_reuse = o.allow_reuse;
                    this->auto_join = o.auto_join;
                    this->kill_on_eop = o.kill_on_eop;
                    this->stack_size = o.stack_size;
                    this->timeout_on_eop = o.timeout_on_eop;
                }
                return *this;
            }
        } thread_options;
        
        /** Defines the union type used to set specific thread options. */
        typedef union thread_option_union {
            /*
                DEV_NOTE: A union is used since the only types within the thread options
                structure are std::size_t and bool types, both of which can be casted
                to/from each other. Adding an overloaded bool/std::size_t set_options function
                would cause ambiguity issues and force users to declare code like such:
                set_option(option, (bool)true) or set_option(option, (std::size_t)1)
                since we are dealing only explicitly with boolean and numeric values,
                if a user said the following code: set_option(option, true) or
                set_option(option, 1), it would be explicitly clear when reading the code
                as to the intention of the function without having to issue a cast
                
                DEV_NOTE: Enabling certain compiler warnings might yield a warning similar to the
                following: 'b_val' should be initialized in the member initialization list .. but
                it's an error to initialize multiple members of a union: error: initializations for
                multiple members .. so head the error and ignore the warning
            */
            
            /** Defines the std::size_t value of this union */
            std::size_t s_val;
            /** Defines the boolean value of this union */
            bool b_val;
            /** The default constructor, sets all to 0 */
            thread_option_union() : s_val(0) { }
            /**
             * Create a new union based on the specified value (true/false/numeric)
             *
             * @param val   The value to set to this union
             */
            thread_option_union(std::size_t val) : s_val(val) { }
        } thread_option_union;
        
        // Types
        /** Defines an alias to the priority enum type */
        typedef omni::sync::thread_priority::enum_t thread_priority_t;
        /** Defines an alias to the start_type enum type */
        typedef omni::sync::thread_start_type::enum_t thread_start_type_t;
        /** Defines an alias to the state enum type */
        typedef omni::sync::thread_state::enum_t thread_state_t;
        /** Defines an alias to the thread_option enum type */
        typedef omni::sync::thread_options::enum_t thread_option_t;
        /** An alias type to the omni::thread_option_union */
        typedef omni::sync::thread_option_union thread_union_t;
        
        #if defined(OMNI_THROW)
            extern omni::callback unhandled_thread_exception;
        #endif
        
        /**
         * Blocks the calling thread until the thread passed in has finished
         * executing (by normal means or cancellation) or the specified timeout
         * has been reached, which ever happens first.
         * 
         * @param timeout   The timeout (in milliseconds) to wait for a thread to finish
         *                  (default of infinite)
         * 
         * @return True if the thread has been joined successfully, false if the operation
         *         times out or there was an error
         */
        inline bool join_thread(omni::sync::thread_handle_t handle, unsigned long timeout)
        {
            if (handle == 0) { 
                OMNI_ERR_RETV_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle(), false)
            }
            #if defined(OMNI_OS_WIN)
                return (::WaitForSingleObject(OMNI_WIN_TOHNDL(handle), timeout) == 0); // Returns 0 on success
            #else
                /* There is not a portable mechanism with pthreads to wait on a specific thread without
                implementing a timed_wait condition variable. We don't want the user to have to implement
                a seperate variable based on system, so we implement a 'timeout' loop*/
                if (timeout != omni::sync::INFINITE_TIMEOUT) {
                    omni::chrono::tick_t ts = omni::chrono::monotonic_tick();
                    OMNI_SLEEP_INIT();
                    volatile bool iav = true;
                    //iav = (::pthread_kill(handle, 0) != ESRCH); // == "alive"
                    while ((iav = (::pthread_kill(handle, 0) != ESRCH)) && (omni::chrono::elapsed_ms(ts) < timeout)) {
                        OMNI_SLEEP1();
                    }
                    return (::pthread_kill(handle, 0) == ESRCH); // == "dead"
                }
                return (::pthread_join(handle, NULL) == 0); // Returns 0 on success
            #endif
        }
        
        /**
         * Blocks the calling thread until the thread passed in has finished
         * executing (by normal means or cancellation).
         * 
         * @return True on success, false otherwise
         */
        inline bool join_thread(omni::sync::thread_handle_t handle)
        {
            if (handle == 0) {
                OMNI_ERR_RETV_FW(omni::consts::err::INVALID_THREAD_HANDLE, omni::invalid_thread_handle(), false)
            }
            #if defined(OMNI_OS_WIN)
                return (::WaitForSingleObject(OMNI_WIN_TOHNDL(handle), INFINITE) == 0); // Returns 0 on success
            #else
                return (::pthread_join(handle, NULL) == 0); // Returns 0 on success
            #endif
        }

    }
}

#endif // OMNI_THREAD_T_HPP
