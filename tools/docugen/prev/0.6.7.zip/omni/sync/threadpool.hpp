/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_THREADPOOL_HPP)
#define OMNI_THREADPOOL_HPP 1
#include <omni/defs/class_macros.hpp>
#include <omni/sync/basic_lock.hpp>
#include <omni/sync/thread.hpp>
#include <list>

namespace omni {
    namespace sync {
        class threadpool
        {
            public:
                threadpool();
                threadpool(std::size_t min_threads, std::size_t max_threads);
                ~threadpool();
                std::size_t available_threads() const;
                std::size_t active_threads() const;
                void kill_active();
                std::size_t max_threads() const;
                std::size_t min_threads() const;
                void queue(const omni::sync::parameterized_thread_start& task);
                void queue(const omni::sync::parameterized_thread_start& task, void* param);
                void queue(const omni::sync::threadpool_task& task);
                std::size_t queue_size() const;
                void set_max_threads(std::size_t count);
                void set_max_threads(std::size_t count, bool kir);
                void set_min_threads(std::size_t count);
                void set_min_threads(std::size_t count, bool kir);
                void wait_active() const;

                OMNI_MEMBERS_FW(omni::sync::threadpool) // disposing,name,type(),hash()
                
            private:
                // DEV_NOTE: threadpool contains a mutex which cannot be copied (per omni/mutex.hpp)
                threadpool(const threadpool &cp);
                omni::sync::threadpool& operator=(const omni::sync::threadpool &other);
                
                // Methods
                void _add_queue(const omni::sync::threadpool_task& task);
                std::list<omni::sync::thread>::iterator _create_thread(const omni::sync::parameterized_thread_start& t);
                std::list<omni::sync::thread>::iterator _find_avail_thread(const omni::sync::parameterized_thread_start& t);
                void _thread_complete(const omni::sync::thread& sender);
                
                void _thread_fn();
                
                // Members
                #if defined(OMNI_TYPE_INFO)
                    omni::type<omni::sync::threadpool> m_type;
                #endif
                volatile std::size_t m_act;
                volatile std::size_t m_min;
                volatile std::size_t m_max;
                mutable omni::sync::basic_lock m_cntmtx;
                mutable omni::sync::basic_lock m_tskmtx;
                mutable omni::sync::basic_lock m_thrdmtx;
                omni::sync::thread::delegate m_state;
                std::list<omni::sync::thread> m_threads;
                std::list<omni::sync::threadpool_task> m_tasks;
                volatile bool m_isdestroy;
        };
    }
}

#endif // OMNI_THREADPOOL_HPP
