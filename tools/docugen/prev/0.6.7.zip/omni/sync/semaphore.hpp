/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_SEMAPHORE_HPP)
#define OMNI_SEMAPHORE_HPP 1
#include <omni/defs/class_macros.hpp>
#include <omni/types/lock_t.hpp>
#if defined(OMNI_SAFE_SEMAPHORE)
    #include <omni/sync/lock.hpp>
#endif

namespace omni {
    namespace sync {
        class semaphore
        {
            public:
                semaphore();
                explicit semaphore(unsigned long maxent);
                explicit semaphore(unsigned long maxent, bool lock1st);
                ~semaphore(); // shouldn't inherit
                const omni::sync::semaphore_t handle() const;
                unsigned long locked() const;
                unsigned long max_ent() const;
                unsigned long open() const;
                unsigned long release();
                unsigned long release(unsigned long releaseCount);
                bool wait();
                bool wait(unsigned long timeout_ms);
                bool trywait();
                // TODO: bool wait(omni::timespan &t); when omni::timespan complete
                bool operator==(const omni::sync::semaphore& o) const;
                bool operator!=(const omni::sync::semaphore& o) const;
                
                OMNI_MEMBERS_FW(omni::sync::semaphore) // disposing,name,type(),hash()
                
            private:
                // defined but not implemented, shouldn't be copied
                semaphore(const omni::sync::semaphore& cp);
                omni::sync::semaphore& operator=(const omni::sync::semaphore& other);
                
                // Functions
                void _init(unsigned long maxent);
                void _dispose();

                // Members
                #if defined(OMNI_TYPE_INFO)
                    omni::type<omni::sync::semaphore> m_type;
                #endif
                unsigned long m_cnt;
                unsigned long m_max;
                omni::sync::semaphore_t m_sem;
                #if defined(OMNI_SAFE_SEMAPHORE)
                    mutable omni::sync::mutex_t m_mtx;
                #endif
        };
    }
}

#endif // OMNI_SEMAPHORE_HPP
