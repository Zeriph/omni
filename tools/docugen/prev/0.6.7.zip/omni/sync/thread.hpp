/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_THREAD_HPP)
#define OMNI_THREAD_HPP 1
#include <omni/defs/class_macros.hpp>
#include <omni/types/thread_t.hpp>
#include <omni/sync/this_thread.hpp>
#include <omni/sync/basic_lock.hpp>
#include <omni/sync/spin.hpp>
#include <map>

namespace omni {
    namespace sync {
        /** Represents a managed system thread object. */
        class thread
        {
            public:
                // types
                typedef omni::event1<void, const omni::sync::thread&> event;
                typedef omni::sync::thread::event::delegate_t delegate;
                
                // thread constructors
                thread();
                thread(const omni::sync::thread& cp);
                explicit thread(const omni::sync::thread_options& ops);
                explicit thread(std::size_t max_stack_sz);
                explicit thread(const omni::sync::thread_start& mthd);
                thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req);
                thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp);
                thread(const omni::sync::thread_start& mthd, omni::sync::thread_start_type_t st);
                thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req, omni::sync::thread_start_type_t st);
                thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, omni::sync::thread_start_type_t st);
                thread(const omni::sync::thread_start& mthd, std::size_t max_stack_sz);
                thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req, std::size_t max_stack_sz);
                thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, std::size_t max_stack_sz);
                thread(const omni::sync::thread_start& mthd, std::size_t max_stack_sz, omni::sync::thread_start_type_t st);
                thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req, std::size_t max_stack_sz, omni::sync::thread_start_type_t st);
                thread(const omni::sync::thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, std::size_t max_stack_sz, omni::sync::thread_start_type_t st);
                thread(const omni::sync::thread_start& mthd, omni::sync::thread_option_t op, omni::sync::thread_union_t val);
                explicit thread(const omni::sync::parameterized_thread_start& mthd);
                thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req);
                thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp);
                thread(const omni::sync::parameterized_thread_start& mthd, omni::sync::thread_start_type_t st, void* args);
                thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req, omni::sync::thread_start_type_t st, void* args);
                thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, omni::sync::thread_start_type_t st, void* args);
                thread(const omni::sync::parameterized_thread_start& mthd, std::size_t max_stack_sz);
                thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req, std::size_t max_stack_sz);
                thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, std::size_t max_stack_sz);
                thread(const omni::sync::parameterized_thread_start& mthd, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args);
                thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args);
                thread(const omni::sync::parameterized_thread_start& mthd, const omni::sync::thread::delegate& abort_req, const omni::sync::thread::delegate& comp, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args);
                thread(const omni::sync::parameterized_thread_start& mthd, omni::sync::thread_option_t op, omni::sync::thread_union_t val);                
                ~thread();
                
                static bool abort_requested()
                {
                    return omni::sync::thread::m_sow().abort_requested();
                }

                static void request_abort(omni::sync::thread_t tid)
                {
                    omni::sync::thread::m_sow().request_abort(tid);
                }
                
                void abort(); // request end nicely
                bool bind(const omni::sync::parameterized_thread_start& mthd);
                bool bind(const omni::sync::thread_start& mthd);
                void detach();
                void detach(bool allow_rejoin);
                const omni::sync::thread_union_t get_option(omni::sync::thread_option_t op) const;
                omni::sync::thread_options options() const;
                const omni::sync::thread_handle_t handle() const;
                const omni::sync::thread_t id() const;
                bool is_alive() const;
                bool is_bound() const;
                bool is_detached() const;
                bool join(); // default of infinite timeout
                bool join(unsigned long timeout);
                //TODO: add bool join(const omni::timespan& t); when omni::timespan complete
                bool kill(); // Terminate 'immediately'
                bool reset();
                bool restart();
                bool restart(void* args);
                bool restart(const omni::sync::thread_start& mthd);
                bool restart(const omni::sync::parameterized_thread_start& mthd);
                bool restart(const omni::sync::parameterized_thread_start& mthd, void* args);
                omni::sync::thread_state_t status() const;
                void start();
                void start(void* args);
                void set_option(omni::sync::thread_option_t op, omni::sync::thread_union_t val);
                void set_options(const omni::sync::thread_options& ops);
                void swap(omni::sync::thread& other);
                bool unbind();
                omni::sync::thread& operator=(const omni::sync::thread& other);
                bool operator==(const omni::sync::thread& other) const;
                bool operator!=(const omni::sync::thread& other) const;
                
                #if defined(OMNI_NON_PORTABLE)
                    omni::sync::thread_priority_t priority() const;
                    void set_priority(omni::sync::thread_priority_t p);
                #endif
                
                /** Raised when omni::sync::thread::abort is called */
                omni::sync::thread::event aborted;
                /** Raised when the thread has completed (by any means) */
                omni::sync::thread::event completed;
                
                OMNI_MEMBERS_FW(omni::sync::thread) // disposing,name,type(),hash()
                
            private:
                // Methods
                void _chkmthd();
                void _close_handle(bool allow_rejoin);
                void _hreset(bool force, bool allow_rejoin);
                bool _hvalid() const;
                void _kill_on_eop();
                bool _state_running() const;
                void _state_changed(omni::sync::thread_state_t nstate);
                void _state_machine();
                #if defined(OMNI_NON_PORTABLE)
                    void _set_prio();
                #endif
                
                // Members
                #if defined(OMNI_TYPE_INFO)
                    omni::type<omni::sync::thread> m_type;
                #endif
                #if defined(OMNI_SAFE_THREAD)
                    mutable omni::sync::basic_lock m_mtx;
                #endif
                /** The arguments passed to the thread */
                void* m_args;
                /** The parameterized delegate invoked on the thread when started (if attached) */
                omni::sync::parameterized_thread_start* m_pmthd;
                /** The delegate invoked on the thread when started (if attached) */
                omni::sync::thread_start* m_mthd;
                /** Wait object used to signal when the thread has started */
                omni::sync::safe_spin_wait* m_switch;
                /** The underlying thread ID type */
                omni::sync::thread_t m_tid;
                /** The underlying thread handle type */
                omni::sync::thread_handle_t m_thread;
                /** The underlying thread options */
                omni::sync::thread_options m_ops;
                /** The current state of the thread */
                omni::sync::thread_state_t m_state;
                #if defined(OMNI_NON_PORTABLE)
                    /** The threads priority */
                    omni::sync::thread_priority_t m_priority;
                #endif
                /** If join has been called, don't detach */
                volatile bool m_isjoined;
                
                // thread management functions
                class static_order_wrapper
                {
                    public:
                        static_order_wrapper() : m_lock(), m_aborts(), m_threads() {}
                        ~static_order_wrapper() {}
                        
                        inline void abort(omni::sync::thread_t tid)
                        {
                            this->m_lock.lock();
                            if (this->m_aborts.find(tid) != this->m_aborts.end()) {
                                this->m_aborts[tid] = true;
                            }
                            this->m_lock.unlock();
                        }
                        
                        inline bool abort_requested()
                        {
                            bool ret = false;
                            this->m_lock.lock();
                            abort_map::iterator it = this->m_aborts.find(omni::sync::thread_id());
                            if (it != this->m_aborts.end()) { ret = it->second; }
                            this->m_lock.unlock();
                            return ret;
                        }
                        
                        inline void push_back(omni::sync::thread_t tid, omni::sync::thread& bthread)
                        {
                            this->m_lock.lock();
                            this->m_threads[tid] = &bthread;
                            this->m_aborts[tid] = false;
                            this->m_lock.unlock();
                        }
                        
                        inline void pop_back(omni::sync::thread_t tid)
                        {
                            this->m_lock.lock();
                            // erase the abort state first
                            abort_map::iterator aitr = this->m_aborts.find(tid);
                            if (aitr != this->m_aborts.end()) { this->m_aborts.erase(aitr); }
                            thread_map::iterator itr = this->m_threads.find(tid);
                            if (itr != this->m_threads.end()) {
                                /* if the tid is still in the map, then the thread object is still attached to the
                                state machine and it's safe to call the sate machine function on the thread object
                                we grabbed from above */
                                omni::sync::thread* t = itr->second;
                                this->m_threads.erase(itr);
                                this->m_lock.unlock();
                                t->_state_machine();
                            } else {
                                this->m_lock.unlock();
                            }
                        }
                        
                        inline void remove(omni::sync::thread_t tid)
                        {
                            this->m_lock.lock();
                            thread_map::iterator it = this->m_threads.find(tid);
                            if (it != this->m_threads.end()) {
                                this->m_threads.erase(it);
                            }
                            this->m_lock.unlock();
                        }
                        
                        inline void request_abort(omni::sync::thread_t tid)
                        {
                            bool found = false;
                            this->m_lock.lock();
                            thread_map::iterator itr = this->m_threads.find(tid);
                            if (itr != this->m_threads.end()) {
                                if (itr->second) {
                                    /* if the tid is still in the map, then the thread is still
                                    attached to the state machine (i.e. still being 'managed'), so
                                    grab the underlying thread object and call abort on it */
                                    omni::sync::thread* t = itr->second;
                                    found = true;
                                    this->m_lock.unlock();
                                    t->abort(); // calls the m_aborts[tid] = true;
                                }
                            }
                            if (!found) {
                                if (this->m_aborts.find(tid) != this->m_aborts.end()) {
                                    this->m_aborts[tid] = true;
                                }
                                this->m_lock.unlock();
                            }
                        }
                        
                    private:
                        typedef std::map<omni::sync::thread_t, bool> abort_map;
                        typedef std::map<omni::sync::thread_t, omni::sync::thread*> thread_map;
                        
                        omni::sync::basic_lock m_lock;
                        abort_map m_aborts;
                        thread_map m_threads;
                        
                        static_order_wrapper(const static_order_wrapper& cp);
                        static_order_wrapper& operator=(const static_order_wrapper& cp);
                };
                
                static OMNI_THREAD_FNPTR_T OMNI_THREAD_CALL_T _start(void* param);
                static void _set_context(omni::sync::thread& t1, const omni::sync::thread& t2);
                static omni::sync::thread::static_order_wrapper& m_sow();
        };
        
        inline void swap(omni::sync::thread& ot1, omni::sync::thread& ot2)
        {
            ot1.swap(ot2);
        }
    } // namespace sync
} // namespace omni

namespace std {
    inline void swap(omni::sync::thread& ot1, omni::sync::thread& ot2)
    {
        ot1.swap(ot2);
    }
}

#endif // OMNI_THREAD_HPP
