/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_BASIC_THREAD_ALLOCATE_HPP)
#define OMNI_BASIC_THREAD_ALLOCATE_HPP 1
#include <omni/sync/thread.hpp>

namespace omni {
    namespace sync {
        // create_thread
        // void (T::*fnptr)()

        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(T& obj)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(T& obj, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(T& obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T& obj)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T& obj, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T& obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T *const obj)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T *const obj, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T *const obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T *const obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread create_basic_thread(const T *const obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        // void (T::*fnptr)(void*)

        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(T& obj)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(T& obj, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(T& obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T& obj)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T& obj, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T& obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T *const obj)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T *const obj, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T *const obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T *const obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread create_basic_thread(const T *const obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj, std::size_t max_stack_sz)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread create_basic_thread_const(const T *const obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }

        // allocate_thread

        // void (T::*fnptr)()

        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), st);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), max_stack_sz, st);
        }
        template < class T, void (T::*fnptr)() const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::thread_start::bind<T, fnptr>(obj), op, val);
        }

        // void (T::*fnptr)(void*)

        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) >
        static omni::sync::basic_thread* allocate_basic_thread(const T *const obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T& obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }

        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj));
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), st, args);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj, std::size_t max_stack_sz)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj, std::size_t max_stack_sz, omni::sync::thread_start_type_t st, void* args)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), max_stack_sz, st, args);
        }
        template < class T, void (T::*fnptr)(void*) const >
        static omni::sync::basic_thread* allocate_basic_thread_const(const T *const obj, omni::sync::thread_option_t op, omni::sync::thread_union_t val)
        {
            return new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind<T, fnptr>(obj), op, val);
        }
    } // namespace sync
} // namespace omni

#endif // OMNI_BASIC_THREAD_ALLOCATE_HPP
