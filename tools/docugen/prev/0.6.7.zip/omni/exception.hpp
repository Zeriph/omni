/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_EXCEPTIONS_HPP)
#define OMNI_EXCEPTIONS_HPP 1
#if defined(OMNI_THROW)
    /* if OMNI_NO_THROW is defined then exceptions will not be used through out the framework
    and std::exception will not be used. If you do not want anything to 'throw', then define
    OMNI_TERMINATE which will call std::terminate (unless otherwise defined in the OMNI_TERMINATE define)
    when an error in the framework occurs.*/
    #include <exception>
    #include <stdexcept>
    #include <iostream>
    #include <string>
    #include <sstream>
    
    /* DEV_NOTE: If you wish to have something other than std::terminate be called below, define OMNI_EXCEPTION_TERMINATE */
    #if !defined(OMNI_EXCEPTION_TERMINATE)
        // std::terminate is called when an exception happens within an exception (i.e. a null pointer reference)
        #define OMNI_EXCEPTION_TERMINATE std::terminate();
    #endif
    
    namespace omni {
        #define OMNI_ERR_APPEND_FW(val) std::stringstream cval; cval << val; this->m_what.append(cval.str())
        
        /** exception is used to facilitate Omni Framework specific exceptions */
        class exception : virtual public std::exception
        {
            public:
                exception() throw() : m_what("General framework exception") {}
                
                explicit exception(const char* reason) throw() : m_what("")
                {
                    if (reason) { this->m_what.append(reason); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                }
                
                explicit exception(const std::string& reason) throw() : m_what(reason) {}
                
                exception(const char* reason, const char* extra) throw() : m_what("")
                {
                    if (reason) { this->m_what.append(reason); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    if (extra) { this->m_what.append(extra); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                }
                
                exception(const std::string& reason, const std::string& extra) throw() : m_what(reason)
                {
                    this->m_what.append(extra);
                }
                
                exception(const char* reason, int err) throw() : m_what("")
                {
                    if (reason) { this->m_what.append(reason); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    OMNI_ERR_APPEND_FW(err);
                }
                
                exception(const std::string& reason, int err) throw() : m_what(reason)
                {
                    OMNI_ERR_APPEND_FW(err);
                }

                exception(const char* reason, long err) throw() : m_what("") 
                {
                    if (reason) { this->m_what.append(reason); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    OMNI_ERR_APPEND_FW(err);
                }
                
                exception(const std::string& reason, long err) throw() : m_what(reason)
                {
                    OMNI_ERR_APPEND_FW(err);
                }
                
                exception(const char* reason, std::size_t err) throw() : m_what("")
                {
                    if (reason) { this->m_what.append(reason); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    OMNI_ERR_APPEND_FW(err);
                }
                
                exception(const std::string& reason, std::size_t err) throw() : m_what(reason)
                {
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual ~exception() throw() {}
                
                virtual void append(const char* ex)
                {
                    if (ex) { this->m_what.append(ex); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                }
                
                virtual void append(const std::string& ex)
                {
                    this->m_what.append(ex);
                }
                
                virtual void append(const char* ex, int err)
                {
                    if (ex) { this->m_what.append(ex); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual void append(const std::string& ex, int err)
                {
                    this->m_what.append(ex);
                    OMNI_ERR_APPEND_FW(err);
                }

                virtual void append(const char* ex, long err)
                {
                    if (ex) { this->m_what.append(ex); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual void append(const std::string& ex, long err)
                {
                    this->m_what.append(ex);
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual void append(const char* ex, std::size_t err)
                {
                    if (ex) { this->m_what.append(ex); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual void append(const std::string& ex, std::size_t err)
                {
                    this->m_what.append(ex);
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual const char* what() const throw() { return m_what.c_str(); }
                
                virtual void seterr(const char* ex)
                {
                    if (ex) { this->m_what = std::string(ex); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                }
                
                virtual void seterr(const std::string& ex) { this->m_what = ex; }
                
                virtual void seterr(const char* ex, int err)
                {
                    if (ex) { this->m_what = std::string(ex); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual void seterr(const std::string& ex, int err)
                {
                    this->m_what = ex;
                    OMNI_ERR_APPEND_FW(err);
                }

                virtual void seterr(const char* ex, long err)
                {
                    if (ex) { this->m_what = std::string(ex); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual void seterr(const std::string& ex, long err)
                {
                    this->m_what = ex;
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual void seterr(const char* ex, std::size_t err)
                {
                    if (ex) { this->m_what = std::string(ex); }
                    else {
                        OMNI_DBGE("Null pointer specified");
                        OMNI_EXCEPTION_TERMINATE
                    }
                    OMNI_ERR_APPEND_FW(err);
                }
                
                virtual void seterr(const std::string& ex, std::size_t err)
                {
                    std::stringstream cval(ex);
                    cval << err;
                    this->m_what = cval.str();
                }
                
                operator std::string() const
                {
                    return this->m_what;
                }
                
                operator std::wstring() const
                {
                    std::wstringstream o;
                    o << this->m_what.c_str();
                    return o.str();
                }
                
                friend std::ostream& operator<<(std::ostream& s, const omni::exception& e)
                {
                    s << e.m_what;
                    return s;
                }
                
                friend std::wostream& operator<<(std::wostream& s, const omni::exception& e)
                {
                    s << e.m_what.c_str();
                    return s;
                }
                
            protected:
                std::string m_what;
        };
        
        #undef OMNI_ERR_APPEND_FW
        
        /** An invalid delegate function pointer was specified and called */
        class invalid_delegate : virtual public omni::exception
        {
            public:
                invalid_delegate() : omni::exception("No valid function has been assigned to the delegate") {}
        };

        /** An invalid type cast was detected on an Omni Framework object */
        class invalid_type_cast : virtual public omni::exception
        {
            public:
                invalid_type_cast() : omni::exception("Invalid type cast") {}
        };
        
        /** An invalid type was detected on a template parameter that only takes certain types */
        class invalid_template_type : virtual public omni::exception
        {
            public:
                invalid_template_type() : omni::exception("Invalid template parameter") {}
        };
        
        /** This exception is specific to the Omni Framework, it is here so as not to be confused with the std::out_of_range exception. */
        class index_out_of_range : virtual public omni::exception
        {
            public:
                index_out_of_range() : omni::exception("Index out of range") {}
                explicit index_out_of_range(const char* var) : omni::exception("Index out of range: ", var) {}
                explicit index_out_of_range(const std::string& var) : omni::exception("Index out of range: ", var.c_str()) {}
        };
    
        /** A null pointer was specified to be used which would cause undefined behaviour */
        class null_pointer_exception : virtual public omni::exception
        {
            public:
                null_pointer_exception() : omni::exception("A null pointer reference exception occurred") {}
                explicit null_pointer_exception(const char* variable) : omni::exception("A null pointer reference exception occurred on ", variable) {}
                explicit null_pointer_exception(const std::string& variable) : omni::exception("A null pointer reference exception occurred on ", variable.c_str()) {}
        };
        
        /** A system clock error occurred */
        class clock_exception : virtual public omni::exception
        {
            public:
                clock_exception() : omni::exception("An error occurred getting the system clock time") {}
                explicit clock_exception(int err) : omni::exception("An error occurred getting the system clock time: ", err) {}
        };
        
        /** A system exception occurred on the mutex object */
        class mutex_system_exception : virtual public omni::exception
        {
            public:
                mutex_system_exception() : omni::exception("A system error occurred on the mutex object") {}
                explicit mutex_system_exception(int er) : omni::exception("A system error occurred on the mutex object: ", er) {}
                explicit mutex_system_exception(long er) : omni::exception("A system error occurred on the mutex object: ", er) {}
                explicit mutex_system_exception(const char* msg) : omni::exception(msg) {}
                mutex_system_exception(const char* msg, int er) : omni::exception(msg, er) {}
                mutex_system_exception(const char* msg, long er) : omni::exception(msg, er) {}
        };
        
        /** The system mutex was left in an undefined state (as in calling mutex_destroy on a mutex that is still locked) */
        class invalid_mutex_state : virtual public omni::mutex_system_exception
        {
            public:
                invalid_mutex_state() : omni::mutex_system_exception("The system mutex was left in an invalid state") {}
        };
        
        /** An attempt was made to unlock a non locked mutex */
        class mutex_unlock_exception : virtual public omni::mutex_system_exception
        {
            public:
                mutex_unlock_exception() : omni::mutex_system_exception("An attempt was made to unlock a non locked mutex") {}
        };
        
        /** Unlock was called from non-owning thread */
        class mutex_owning_thread_exception : virtual public omni::mutex_system_exception
        {
            public:
                mutex_owning_thread_exception() : omni::mutex_system_exception("Unlock called from non-owning thread") {}
        };
        
        /** A system error occurred on the semaphore */
        class semaphore_system_exception : virtual public omni::exception
        {
            public:
                semaphore_system_exception() : omni::exception("A system error occurred on the semaphore object") {}
                explicit semaphore_system_exception(int er) : omni::exception("A system error occurred on the semaphore object: ", er) {}
                explicit semaphore_system_exception(long er) : omni::exception("A system error occurred on the semaphore object: ", er) {}
                explicit semaphore_system_exception(const char* msg) : omni::exception(msg) {}
                semaphore_system_exception(const char* msg, int er) : omni::exception(msg, er) {}
                semaphore_system_exception(const char* msg, long er) : omni::exception(msg, er) {}
        };
        
        /** An attempt was made to release a semaphore in a non-wait state */
        class semaphore_release_exception : virtual public omni::semaphore_system_exception
        {
            public:
                semaphore_release_exception() : omni::semaphore_system_exception("An attempt was made to release a semaphore in a non-wait state") {}
        };
        
        /** A system error occurred on the spin_lock object */
        class spin_lock_exception : virtual public omni::exception
        {
            public:
                spin_lock_exception() : omni::exception("A system error occurred on the spin lock object") {}
                spin_lock_exception(int err) : omni::exception("A system error occurred on the spin lock object: ", err) {}
        };
        
        /** A system error occurred on the conditional object */
        class conditional_exception : virtual public omni::exception
        {
            public:
                conditional_exception() : omni::exception("A system error occurred on the conditional object") {}
                conditional_exception(int err) : omni::exception("A system error occurred on the conditional object: ", err) {}
        };
        
        /** An active wait was pending on a call to semaphore destruction */
        class active_wait_exception : virtual public omni::exception
        {
            public:
                active_wait_exception() : omni::exception("Active waits pending when disposing a lock object") {}
        };
        
        /** An invalid release count was specified on the semaphore */
        class invalid_release_count : virtual public omni::semaphore_system_exception
        {
            public:
                invalid_release_count() : omni::semaphore_system_exception("An invalid release count was specified") {}
        };
        
        /** An error occurred on a thread object */
        class thread_exception : virtual public omni::exception
        {
            public:
                thread_exception() : omni::exception("An error occurred on the thread") {}
                explicit thread_exception(int perr) : omni::exception("An error occurred on the thread: ", perr) {}
                explicit thread_exception(std::size_t perr) : omni::exception("An error occurred on the thread: ", perr) {}
                explicit thread_exception(const std::string& msg) : omni::exception(msg) {}
                explicit thread_exception(const char* msg) : omni::exception(msg) {}
                thread_exception(std::string msg, int perr) : omni::exception(msg, perr) {}
                thread_exception(std::string msg, std::size_t perr) : omni::exception(msg, perr) {}
                thread_exception(const char* msg, int perr) : omni::exception(msg, perr) {}
                thread_exception(const char* msg, std::size_t perr) : omni::exception(msg, perr) {}
        };
        
        /** An invalid state was specified for the thread object */
        class invalid_thread_state : virtual public omni::thread_exception
        {
            public:
               invalid_thread_state() : omni::thread_exception("An invalid thread state was specified for the thread") {}
        };
        
        /** An invalid thread handle was specified */
        class invalid_thread_handle : virtual public omni::thread_exception
        {
            public:
                invalid_thread_handle() : omni::thread_exception("Invalid thread handle") {}
        };
        
        /** An invalid thread option was specified */
        class invalid_thread_option : virtual public omni::thread_exception
        {
            public:
                invalid_thread_option() : omni::thread_exception("An invalid thread option was specified") {}
                explicit invalid_thread_option(std::size_t var) : omni::thread_exception("An invalid thread option was specified: ", var) {}
        };
        
        /** An invalid thread start type was specified */
        class invalid_thread_start_type : virtual public omni::thread_exception
        {
            public:
                invalid_thread_start_type() : omni::thread_exception("Invalid thread start type specified") {}
        };
        
        /** An operation was made on a thread in an already started state and cannot be called once running */
        class thread_running_exception : virtual public omni::invalid_thread_state
        {
            public:
                thread_running_exception() : omni::thread_exception("A thread has already been started") {}
        };
        
        /** An error occurred on a threadpool object */
        class threadpool_exception : virtual public omni::exception
        {
            public:
                threadpool_exception() : omni::exception("An error occurred on the threadpool") {}
                explicit threadpool_exception(const std::string& msg) : omni::exception(msg) {}
                explicit threadpool_exception(const char* msg) : omni::exception(msg) {}
        };
        
        /** An internal state error occurred */
        class threadpool_state_exception : virtual public omni::threadpool_exception
        {
            public:
                threadpool_state_exception() : omni::threadpool_exception("Internal state error") {}
        };
        
        /** An error occurred and the threadpool could not acquire a thread */
        class threadpool_thread_exception : virtual public omni::threadpool_exception
        {
            public:
                threadpool_thread_exception() : omni::threadpool_exception("Could not acquire thread") {}
        };
        
        /** An invalid size was specified for the threadpool object */
        class invalid_threadpool_size : virtual public omni::threadpool_exception
        {
            public:
                invalid_threadpool_size() : omni::threadpool_exception("Invalid size specified") {}
        };
        
        /** An exception occurred on the version object */
        class version_exception : virtual public omni::exception
        {
            public:
                version_exception() : omni::exception("Invalid version string specified") {}
        };
        
        /** An application exception happened within the omni::application namespace */
        class application_exception : virtual public omni::exception
        {
            public:
                application_exception() : omni::exception("An application exception occurred") {}
                explicit application_exception(int er) : omni::exception("An application exception occurred: ", er) {}
                explicit application_exception(long er) : omni::exception("An application exception occurred: ", er) {}
                explicit application_exception(const char* msg) : omni::exception(msg) {}
                application_exception(const char* msg, int er) : omni::exception(msg, er) {}
                application_exception(const char* msg, long er) : omni::exception(msg, er) {}
        };
        
        /** An omni::application context is already running (i.e. omni::application::run was called twice) */
        class context_running_exception : virtual public omni::application_exception
        {
            public:
                context_running_exception() : omni::application_exception("An omni::application context is already running") {}
        };
        
        /** A general environment exception occurred */
        class environment_exception : virtual public omni::exception
        {
            public:
                environment_exception() : omni::exception("An error occurred within the system environment") {}
                explicit environment_exception(std::size_t err) : omni::exception("An error occurred within the system environment: ", err) {}
        };
        
        /** An empty environment variable name was specified */
        class name_empty_exception : virtual public omni::environment_exception
        {
            public:
                name_empty_exception() : omni::exception("Name cannot be empty") {}
        };
        
        /** An error occurred on the system pipe */
        class pipe_exception : virtual public omni::environment_exception
        {
            public:
                pipe_exception() : omni::exception("Failed to open the pipe") {}
        };
        
        /** A system error occurred on the string */
        class string_exception : virtual public omni::exception
        {
            public:
                string_exception() : omni::exception("A general exception occurred on the string object") {}
                explicit string_exception(const char* msg) : omni::exception(msg) {}
        };
        
        /** The specified string does not contain a valid binary number */
        class invalid_binary_format : virtual public omni::string_exception
        {
            public:
                invalid_binary_format() : omni::string_exception("The specified string does not contain a valid binary number") {}
        };
        
        /** The binary string length is greater than sizeof conversion unit */
        class invalid_binary_size : virtual public omni::string_exception
        {
            public:
                invalid_binary_size() : omni::string_exception("The binary string length is greater than sizeof conversion unit") {}
        };
        
        /** Invalid size written */
        class invalid_size_written : virtual public omni::string_exception
        {
            public:
                invalid_size_written() : omni::string_exception("Invalid size written") {}
        };
        
        /** An error occurred on the stopwatch */
        class stopwatch_exception : virtual public omni::exception
        {
            public:
                stopwatch_exception() : omni::exception("An error occurred on the stopwatch object") {}
                explicit stopwatch_exception(int er) : omni::exception("An error occurred on the stopwatch object: ", er) {}
                explicit stopwatch_exception(long er) : omni::exception("An error occurred on the stopwatch object: ", er) {}
                explicit stopwatch_exception(const char* msg) : omni::exception(msg) {}
                stopwatch_exception(const char* msg, int er) : omni::exception(msg, er) {}
                stopwatch_exception(const char* msg, long er) : omni::exception(msg ,er) {}
        };
    } // namespace omni
    
#endif // OMNI_NO_THROW

#endif // OMNI_EXCEPTIONS_HPP
