/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_CONSTANTS_HPP)
#define OMNI_CONSTANTS_HPP
#include <omni/defs/global.hpp>

#if !defined(OMNI_NO_CSTRING_IMPL) // define this if you only want omni::wconsts header
    #include <omni/consts/cconsts.hpp>
#endif
#if !defined(OMNI_NO_WSTRING_IMPL) // define this if you only want omni::cconsts header
    #include <omni/consts/wconsts.hpp>
#endif

#if defined(OMNI_UNICODE) && !defined(OMNI_NO_WSTRING_IMPL)
    #define OMNI_CONSTS_NS_FW omni::wconsts
#else
    #define OMNI_CONSTS_NS_FW omni::cconsts
#endif

namespace omni {
    namespace consts {
        namespace binary_sz {
            const std::size_t of_uint = sizeof(unsigned int) * 8;
            const std::size_t of_ulong = sizeof(unsigned long) * 8;
            const std::size_t of_size_t = sizeof(std::size_t) * 8;
        }

        namespace err = OMNI_CONSTS_NS_FW::err;
        namespace misc = OMNI_CONSTS_NS_FW::misc;
        namespace sz {
            namespace bin {
                namespace str = OMNI_CONSTS_NS_FW::sz::bin::str;
                const unsigned int KB = 1024;
                const unsigned int MB = 1048576;
                const std::size_t GB = 1073741824;
            }
            namespace dec {
                namespace str = OMNI_CONSTS_NS_FW::sz::dec::str;
                const unsigned int KB = 1000;
                const unsigned int MB = 1000000;
                const std::size_t GB = 1000000000;
            }
        }
        
        namespace threading = OMNI_CONSTS_NS_FW::threading;
    }
}

#undef OMNI_CONSTS_NS_FW

#endif // OMNI_CONSTANTS_HPP
