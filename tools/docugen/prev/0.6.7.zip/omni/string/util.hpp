/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_STRING_UTIL_HPP)
#define OMNI_STRING_UTIL_HPP 1
#include <omni/types/char_t.hpp>
#include <omni/types/seq_t.hpp>
#include <omni/type.hpp>
#include <omni/constants.hpp>
#include <bitset>

namespace omni {
    namespace string {
        namespace util {
            template < typename std_string_t >
            bool is_numeric(const std_string_t& str, bool ignorePeriod)
            {
                if (str.empty()) { return false; }
                typename std_string_t::const_iterator itr = str.begin();
                std::size_t len = str.length();
                std::size_t pct = 0;
                // could be negative/decimal/euro ("-100"/".42"/",42")
                if (omni::char_util::helpers::is_nde(*itr)) {
                    if (++itr == str.end()) { return false; }
                }
                while (itr != str.end()) {
                    if (!omni::char_util::is_digit(*itr)) {
                        /*
                            if it's a period or comma and the flag is set then ignore it.
                            The logic here is that we don't want this function to 'guess'
                            how a specific number might be formatted, but that we can assume
                            that if it is indeed a number, chances are good that it 'might'
                            contain a period or comma, so ignore those.
                        */
                        if (ignorePeriod && omni::char_util::helpers::is_de(*itr)) {
                            if (++pct >= len) { return false; }
                            continue;
                        }
                        return false;
                    }
                    ++itr;
                }
                return true;
            }
            
            inline bool is_numeric(const wchar_t* str, bool ignorePeriod)
            {
                if (str) { return omni::string::util::is_numeric(std::wstring(str), ignorePeriod); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), false)
            }
            
            inline bool is_numeric(const char* str, bool ignorePeriod)
            {
                if (str) { return omni::string::util::is_numeric(std::string(str), ignorePeriod); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), false)
            }
            
            inline bool is_numeric(const std::wstring& str)
            {
                return omni::string::util::is_numeric(str, false);
            }
            
            inline bool is_numeric(const wchar_t* str)
            {
                return omni::string::util::is_numeric(str, false);
            }

            inline bool is_numeric(const std::string& str)
            {
                return omni::string::util::is_numeric(str, false);
            }
            
            inline bool is_numeric(const char* str)
            {
                return omni::string::util::is_numeric(str, false);
            }
            
            template < typename std_string_t >
            std_string_t to_lower(std_string_t str)
            {
                if (str.empty()) { return str; }
                std::size_t len = str.length();
                while (len > 0) {
                    --len;
                    str[len] = omni::char_util::to_lower(str.at(len));
                }
                return str;
            }
            
            template < typename std_string_t >
            std_string_t to_upper(std_string_t str)
            {
                if (str.empty()) { return str; }
                std::size_t len = str.length();
                while (len > 0) {
                    --len;
                    str[len] = omni::char_util::to_upper(str.at(len));
                }
                return str;
            }
            
            template < typename std_string_t >
            bool contains(const std_string_t& chk, const std_string_t& find, bool ignoreCase)
            {   
                if (chk.empty() || find.empty()) { return false; }
                if (ignoreCase) {
                    std_string_t tmp = omni::string::util::to_lower(chk);
                    std_string_t tf = omni::string::util::to_lower(find);
                    return (tmp.find(tf) != std_string_t::npos);
                }
                return (chk.find(find) != std_string_t::npos);
            }

            template < typename std_string_t, typename std_char_t >
            std_string_t pad_left(std_string_t str, std_char_t pad, std::size_t count)
            {
                if (count == 0) { return str; }
                return str.insert(0, count, pad);
            }

            template < typename std_string_t >
            std_string_t pad_left(std_string_t str, const std_string_t& pad, std::size_t count)
            {
                if (count == 0) { return str; }
                std_string_t ret(pad);
                while (count > 0) {
                    ret.append(pad);
                    --count;
                }
                return ret + str;
            }

            template < typename std_string_t, typename std_char_t >
            std_string_t pad_right(std_string_t str, std_char_t pad, std::size_t count)
            {
                if (count == 0) { return str; }
                return str.append(count, pad);
            }

            template < typename std_string_t >
            std_string_t pad_right(std_string_t str, const std_string_t& pad, std::size_t count)
            {
                while (count > 0) {
                    str.append(pad);
                    --count;
                }
                return str;
            }

            template < typename std_string_t >
            std_string_t replace(std_string_t str, const std_string_t& fnd, const std_string_t& newstr, std::size_t pos, bool ignoreCase)
            {
                std::size_t spos = std_string_t::npos;
                if (ignoreCase) {
                    std_string_t ret = omni::string::util::to_lower(str);
                    std_string_t f = omni::string::util::to_lower(fnd);
                    spos = ret.find(f, pos);
                } else {
                    spos = str.find(fnd, pos);
                }
                if (spos != std_string_t::npos) {
                    str.replace(spos, fnd.length(), newstr);
                }
                return str;
            }

            template < typename std_string_t >
            std_string_t replace_all(std_string_t str, const std_string_t& fnd, const std_string_t& newstr, std::size_t pos, bool ignoreCase)
            {
                std::size_t spos = std_string_t::npos;
                std::size_t fsz = fnd.length();
                if (ignoreCase) {
                    std_string_t ret = omni::string::util::to_lower(str);
                    std_string_t f = omni::string::util::to_lower(fnd);
                    spos = ret.find(f, pos);
                    while (spos != std_string_t::npos) {
                        str = str.replace(spos, fsz, newstr);
                        ret = omni::string::util::to_lower(str);
                        spos = ret.find(f, spos);
                    }
                } else {
                    spos = str.find(fnd, pos);
                    while (spos != std_string_t::npos) {
                        str = str.replace(spos, fsz, newstr);
                        spos = str.find(fnd, spos);
                    }
                }
                return str;
            }

            template < typename std_string_t >
            std_string_t reverse(const std_string_t& str)
            {
                std_string_t ret;
                typename std_string_t::const_iterator itr = str.end();
                while (itr > str.begin()) {
                    ret.push_back(*itr);
                    --itr;
                }
                return ret;
            }
            
            template < template < class, class > class std_seq_t, class std_string_t, class std_allocator_t >
            std_seq_t<std_string_t, std_allocator_t> split(const std_string_t& str, const std_string_t& delimeter, std::size_t max_val)
            {
                std_seq_t<std_string_t, std_allocator_t> ret;
                if (str.empty()) { return ret; }
                if (max_val == 1) { // If max is 1, then they only want 1 substring, which means the string they sent in
                    ret.push_back(str);
                    return ret;
                }
                if (delimeter.empty()) {
                    std::size_t len = str.length();
                    for (std::size_t i = 0; i < len; ++i) {
                        ret.push_back(str.substr(i, 1));
                    }
                } else {
                    std::size_t p;
                    std_string_t tmpchk(str);
                    while (1) {
                        p = tmpchk.find_first_of(delimeter.c_str());
                        if (p != std::string::npos) {
                            ret.push_back(tmpchk.substr(0, p));
                            tmpchk = tmpchk.substr(p + 1);
                            if ((max_val > 0) && (--max_val)) { 
                                ret.push_back(tmpchk);
                                break;
                            }
                        } else {
                            ret.push_back(tmpchk);
                            break;
                        }
                    }
                }
                return ret;
            }
            
            template < template < class, class > class std_seq_t, class std_string_t >
            inline std_seq_t<std_string_t, std::allocator<std_string_t> > split(const std_string_t& str, const std_string_t& delimeter, std::size_t max_val)
            {
                return omni::string::util::split< std_seq_t, std_string_t, std::allocator<std_string_t> >(str, delimeter, max_val);
            }
            
            template < typename std_string_t >
            inline OMNI_SEQ_T<std_string_t> split(const std_string_t& str, const std_string_t& delimeter, std::size_t max_val)
            {
                return omni::string::util::split< OMNI_SEQ_T, std_string_t >(str, delimeter, max_val);
            }
            
            template < typename std_string_t >
            inline OMNI_SEQ_T<std_string_t> split(const std_string_t& str, const std_string_t& delimeter)
            {
                return omni::string::util::split(str, delimeter, 0); 
            }
            
            template < std::size_t X, std::size_t Y >
            inline OMNI_SEQ_T<std::string> split(const char (&str)[X], const char (&delimeter)[Y], std::size_t max_val)
            {
                return omni::string::util::split(std::string(str), std::string(delimeter), max_val); 
            }
            
            template < std::size_t X, std::size_t Y >
            inline OMNI_SEQ_T<std::string> split(const char (&str)[X], const char (&delimeter)[Y])
            {
                return omni::string::util::split(std::string(str), std::string(delimeter), 0); 
            }
            
            template < std::size_t X, std::size_t Y >
            inline OMNI_SEQ_T<std::wstring> split(const wchar_t (&str)[X], const wchar_t (&delimeter)[Y], std::size_t max_val)
            {
                return omni::string::util::split(std::wstring(str), std::wstring(delimeter), max_val);
            }
            
            template < std::size_t X, std::size_t Y >
            inline OMNI_SEQ_T<std::wstring> split(const wchar_t (&str)[X], const wchar_t (&delimeter)[Y])
            {
                return omni::string::util::split(std::wstring(str), std::wstring(delimeter), 0); 
            }
            
            inline OMNI_SEQ_T<std::string> split(const char* str, const char* delimeter, std::size_t max_val)
            {
                return omni::string::util::split< OMNI_SEQ_T >(std::string(str), std::string(delimeter), max_val); 
            }
            
            inline OMNI_SEQ_T<std::string> split(const char* str, const char* delimeter)
            {
                return omni::string::util::split< OMNI_SEQ_T >(std::string(str), std::string(delimeter), 0); 
            }
            
            inline OMNI_SEQ_T<std::wstring> split(const wchar_t* str, const wchar_t* delimeter, std::size_t max_val)
            {
                return omni::string::util::split< OMNI_SEQ_T >(std::wstring(str), std::wstring(delimeter), max_val);
            }
            
            inline OMNI_SEQ_T<std::wstring> split(const wchar_t* str, const wchar_t* delimeter)
            {
                return omni::string::util::split< OMNI_SEQ_T >(std::wstring(str), std::wstring(delimeter), 0); 
            }
            
            inline std::string to_string(const std::wstring& str)
            {
                if (str.empty()) { return std::string(); }
                std::size_t sz = str.length();
                #if defined(OMNI_WIN_API)
                    int nd = ::WideCharToMultiByte(CP_UTF8, 0, &str[0], sz, NULL, 0, NULL, NULL);
                    if (nd != 0) {
                        std::string cret(nd, '\0');
                        int w = ::WideCharToMultiByte(CP_UTF8, 0, &str[0], sz, &cret[0], nd, NULL, NULL);
                        if (w != 0) {
                            if (w != sz) {
                                OMNI_ERR_RETV_FW("wrote " << w << " but expected size of " << sz, omni::invalid_size_written(), std::string())
                            }
                            return cret;
                        }
                    }
                    OMNI_THROW_FW(omni::invalid_size_written())
                    return std::string();
                #else
                    std::string cret(sz, '\0');
                    std::size_t w = std::wcstombs(&cret[0], str.c_str(), sz);
                    if (w != 0) {
                        if (w != sz) {
                            OMNI_ERR_RETV_FW("wrote " << w << " but expected size of " << sz, omni::invalid_size_written(), std::string())
                        }
                        return cret;
                    }
                    OMNI_THROW_FW(omni::invalid_size_written())
                    return std::string();
                #endif
            }

            inline std::string to_string(const wchar_t* str)
            {
                if (str) { return omni::string::util::to_string(std::wstring(str)); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), std::string())
            }
            
            inline std::string to_string(const char* str)
            {
                if (str) { return std::string(str); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), std::string())
            }
            
            inline std::string to_string(const std::string& str)
            {
                return str;
            }
            
            inline std::wstring to_wstring(const std::string& str)
            {
                if (str.empty()) { return std::wstring(); }
                std::size_t sz = str.length();
                #if defined(OMNI_WIN_API)
                    int nd = ::MultiByteToWideChar(CP_UTF8, 0, &str[0], sz, NULL, 0);
                    if (nd != 0) {
                        std::wstring wret(nd, L'\0');
                        int w = ::MultiByteToWideChar(CP_UTF8, 0, &str[0], sz, &wret[0], nd);
                        if (w != 0) {
                            if (w != sz) {
                                OMNI_ERR_RETV_FW("wrote " << w << " but expected size of " << sz, omni::invalid_size_written(), std::wstring())
                            }
                            return wret;
                        }
                    }
                    OMNI_THROW_FW(omni::invalid_size_written())
                    return std::wstring();
                #else
                    std::wstring wret(sz, L'\0');
                    std::size_t w = std::mbstowcs(&wret[0], str.c_str(), sz);
                    if (w != 0) {
                        if (w != sz) {
                            OMNI_ERR_RETV_FW("wrote " << w << " but expected size of " << sz, omni::invalid_size_written(), std::wstring())
                        }
                        return wret;
                    }
                    OMNI_THROW_FW(omni::invalid_size_written())
                    return std::wstring();
                #endif
            }
            
            inline std::wstring to_wstring(const char* str)
            {
                if (str) { return omni::string::util::to_wstring(std::string(str)); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), std::wstring())
            }
            
            inline std::wstring to_wstring(const wchar_t* str)
            {
                if (str) { return std::wstring(str); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), std::wstring())
            }
            
            inline std::wstring to_wstring(const std::wstring& str)
            {
                return str;
            }
            
            inline omni::string_t to_string_t(const std::wstring& str)
            {
                #if defined(OMNI_UNICODE)
                    return str;
                #else
                    return omni::string::util::to_string(str);
                #endif
            }
            
            inline omni::string_t to_string_t(const wchar_t* str)
            {
                if (str) { return omni::string::util::to_string_t(std::wstring(str)); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), omni::string_t())
            }
            
            inline omni::string_t to_string_t(const std::string& str)
            {
                #if defined(OMNI_UNICODE)
                    return omni::string::util::to_wstring(str);
                #else
                    return str;
                #endif
            }
            
            inline omni::string_t to_string_t(const char* str)
            {
                if (str) { return omni::string::util::to_string_t(std::string(str)); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), omni::string_t())
            }
            
            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template < typename std_string_t >
            std_string_t template_type_cast(const char* str)
            { return std_string_t(str); }
            
            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template < typename std_string_t >
            std_string_t template_type_cast(const wchar_t* str)
            { return std_string_t(str); }
            
            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template < typename std_string_t >
            std_string_t template_type_cast(std::string str)
            { return std_string_t(str); }
            
            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template < typename std_string_t >
            std_string_t template_type_cast(std::wstring str)
            { return std_string_t(str); }

            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template <>
            inline std::string template_type_cast<std::string>(const char* str)
            { return std::string(str); }

            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template <>
            inline std::string template_type_cast<std::string>(const wchar_t* str)
            { return omni::string::util::to_string(str); }
            
            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template <>
            inline std::string template_type_cast<std::string>(std::string str)
            { return str; }
            
            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template <>
            inline std::string template_type_cast<std::string>(std::wstring str)
            { return omni::string::util::to_string(str); }

            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template <>
            inline std::wstring template_type_cast<std::wstring>(const char* str)
            { return omni::string::util::to_wstring(str); }
            
            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template <>
            inline std::wstring template_type_cast<std::wstring>(const wchar_t* str)
            { return std::wstring(str); }
            
            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template <>
            inline std::wstring template_type_cast<std::wstring>(std::string str)
            { return omni::string::util::to_wstring(str); }
            
            /* Do not use this function directly; this is an internal template function to grab
            the correct string type for template parameter input on other string util functions.*/
            template <>
            inline std::wstring template_type_cast<std::wstring>(std::wstring str)
            { return str; }
            
            template < typename type >
            std::wstring wtype_cast(type val)
            {
                std::wstringstream o;
                o << val;
                return o.str();
            }
            
            template <>
            inline std::wstring wtype_cast<bool>(bool val)
            {
                return (val ? OMNI_WSTR("true") : OMNI_WSTR("false"));
            }
            
            template < typename type >
            std::string type_cast(type val)
            {
                std::stringstream o;
                o << val;
                return o.str();
            }
            
            template <>
            inline std::string type_cast<bool>(bool val)
            {
                return (val ? "true" : "false");
            }
            
            template < typename ret_t >
            ret_t type_cast(const std::string &str)
            {
                ret_t ret;
                if (!str.empty()) {
                    std::stringstream in(str);
                    in >> ret;
                }
                return ret;
            }
            
            template <>
            inline bool type_cast<bool>(const std::string& str)
            {
                if (!str.empty()) {
                    std::size_t t = str.find_first_of("tT");
                    std::size_t f = str.find_first_of("fF");
                    if (t == std::string::npos && f == std::string::npos) {
                        t = str.find_first_of("123456789");
                        if (t == 1) { return true; }
                    } else {
                        if (str == "true") { return true; }
                        if (str == "false") { return false; }
                        if (t == 1) { return true; }
                    }
                }
                return false;
            }
            
            template < typename ret_t >
            ret_t type_cast(const char *str)
            {
                if (str) { return omni::string::util::type_cast<ret_t>(std::string(str)); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), ret_t())
            }
            
            template < typename ret_t >
            ret_t type_cast(const std::wstring &str)
            {
                ret_t ret;
                if (!str.empty()) {
                    std::wstringstream in(str);
                    in >> ret;
                }
                return ret;
            }
            
            template <>
            inline bool type_cast<bool>(const std::wstring& str)
            {
                if (!str.empty()) {
                    std::size_t t = str.find_first_of(L"tT");
                    std::size_t f = str.find_first_of(L"fF");
                    if (t == std::wstring::npos && f == std::wstring::npos) {
                        t = str.find_first_of(L"123456789");
                        if (t == 1) { return true; }
                    } else {
                        if (str == L"true") { return true; }
                        if (str == L"false") { return false; }
                        if (t == 1) { return true; }
                    }
                }
                return false;
            }
            
            template < typename ret_t >
            ret_t type_cast(const wchar_t* str)
            {
                if (str) { return omni::string::util::type_cast<ret_t>(std::wstring(str)); }
                OMNI_ERR_RETV_FW("Null pointer specified", omni::null_pointer_exception(), ret_t())
            }
            
            template < typename std_string_t, typename type >
            std_string_t lexical_cast(type val)
            {
                if (omni::type_of<std::wstring, std_string_t>()) {
                    return omni::string::util::template_type_cast<std_string_t>(omni::string::util::wtype_cast<type>(val));
                }
                return omni::string::util::template_type_cast<std_string_t>(omni::string::util::type_cast<type>(val));
            }
            
            template < typename std_string_t, bool >
            std_string_t lexical_cast(bool val)
            { return omni::string::util::template_type_cast<std_string_t>(val ? "true" : "false"); }        
            
            template < typename std_string_t, typename iterator_t >
            std_string_t trim_front(std_string_t str, iterator_t begin, iterator_t end)
            {
                if (str.empty() || begin == end) { return str; }
                std::size_t spos = std_string_t::npos;
                iterator_t beg;// = begin;
                int cnt = 0;
                do {
                    beg = begin;
                    cnt = 0;
                    while (beg != end) {
                        spos = str.find_first_not_of(*beg);
                        if (spos != std_string_t::npos) {
                            // spos == 0 same as str=str;
                            if (spos > 0) {
                                str = str.substr(spos);
                                ++cnt;
                            }
                        } else {
                            /* the rest of the string contains what we're looking for
                            so return an empty string */
                            str.clear();
                            return str;
                        }
                        ++beg;
                    }
                } while (cnt > 0);
                return str;
            }        
            
            template < typename std_string_t >
            std_string_t trim_front_syschars(std_string_t str)
            {
                if (str.empty()) { return str; }
                typename std_string_t::const_iterator itr = str.begin();
                std::size_t st = 0;
                while (itr != str.end()) {
                    // Trims characters below ASCII 32 (space) (these chars are control sequences)
                    if (static_cast<std::size_t>(*itr) > 31) { break; }
                    ++itr; ++st;
                }
                return str.substr(st);
            }
            
            template < typename std_string_t >
            std_string_t trim_front(std_string_t str)
            {
                str = omni::string::util::trim_front_syschars(str);
                std_string_t p = omni::string::util::template_type_cast<std_string_t>("\t \n\r\0");
                return omni::string::util::trim_front(str, p.begin(), p.end());
            }
            
            template < typename std_string_t, typename std_char_t >
            std_string_t trim_front(std_string_t str, std_char_t param)
            {
                OMNI_SEQ_T<std_char_t> p;
                p.push_back(param);
                return omni::string::util::trim_front(str, p.begin(), p.end());
            }
            
            template < typename std_string_t >
            std_string_t trim_front(std_string_t str, std_string_t params)
            {
                return omni::string::util::trim_front(str, params.begin(), params.end());
            }
            
            template < typename std_string_t, typename iterator_t >
            std_string_t trim_end(std_string_t str, iterator_t begin, iterator_t end)
            {
                if (str.empty() || begin == end) { return str; }
                std::size_t spos = std_string_t::npos;
                std::size_t olen = str.length();
                iterator_t beg;// = begin;
                int cnt = 0;
                do {
                    beg = begin;
                    cnt = 0;
                    while (beg != end) {
                        spos = str.find_last_not_of(*beg);
                        if (spos != std_string_t::npos) {
                            // spos == str.size()-1 same as str=str;
                            if (spos < olen-1) {
                                str = str.substr(0, spos+1); //+1 for end of string
                                olen = str.length();
                                ++cnt;
                            }
                        } else {
                            /* the rest of the string contains what we're looking for
                            so return an empty string */
                            str.clear();
                            return str;
                        }
                        ++beg;
                    }
                } while (cnt > 0);
                return str;
            }
            
            template < typename std_string_t >
            std_string_t trim_end_syschars(std_string_t str)
            {
                if (str.empty()) { return str; }
                typename std_string_t::const_iterator itr = str.end();
                std::size_t end = str.length();
                while (itr != str.begin()) {
                    // Trims characters below ASCII 32 (space) (these chars are control sequences)
                    if (static_cast<std::size_t>(*itr) > 31) { break; }
                    --itr; --end;
                }
                return str.substr(0, end);
            }
            
            template < typename std_string_t >
            std_string_t trim_end(std_string_t str)
            {
                str = omni::string::util::trim_end_syschars(str);
                std_string_t p = omni::string::util::template_type_cast<std_string_t>("\t \n\r\0");
                return omni::string::util::trim_end(str, p.begin(), p.end());
            }
            
            template < typename std_string_t, typename std_char_t >
            std_string_t trim_end(std_string_t str, std_char_t param)
            {
                OMNI_SEQ_T<std_char_t> p;
                p.push_back(param);
                return omni::string::util::trim_end(str, p.begin(), p.end());
            }
            
            template < typename std_string_t >
            std_string_t trim_end(std_string_t str, std_string_t params)
            {
                return omni::string::util::trim_end(str, params.begin(), params.end());
            }
            
            template < typename std_string_t, typename iterator_t >
            std_string_t trim(std_string_t str, iterator_t begin, iterator_t end)
            {
                if (str.empty()) { return str; }
                str = omni::string::util::trim_front(str, begin, end);
                return omni::string::util::trim_end(str, begin, end);
            }
            
            template < typename std_string_t >
            std_string_t trim_syschars(std_string_t str)
            {
                str = omni::string::util::trim_front_syschars(str);
                return omni::string::util::trim_end_syschars(str);
            }
            
            template < typename std_string_t >
            std_string_t trim(std_string_t str)
            {
                if (str.empty()) { return str; }
                // Trim Both leading and trailing spaces
                str = omni::string::util::trim_front(str);
                return omni::string::util::trim_end(str);
            }
            
            template < typename std_string_t, typename std_char_t >
            std_string_t trim(std_string_t str, std_char_t param)
            {
                OMNI_SEQ_T<std_char_t> p;
                p.push_back(param);
                return omni::string::util::trim(str, p.begin(), p.end());
            }
            
            template < typename std_string_t >
            std_string_t trim(std_string_t str, std_string_t params)
            {
                return omni::string::util::trim(str, params.begin(), params.end());
            }
            
            namespace binary {
                template < typename std_string_t >
                bool is_valid(const std_string_t& str)
                {
                    if (str.empty()) { return false; }
                    typename std_string_t::const_iterator itr = str.begin();
                    while (itr != str.end()) {
                        if (!omni::char_util::helpers::is_1or0(*itr)) { return false; }
                        ++itr;
                    }
                    return true;
                }
                
                template < typename std_string_t >
                std_string_t from_ulong(unsigned long val, bool trim)
                {
                    std::string ret = std::bitset<omni::consts::binary_sz::of_ulong>(
                        (static_cast<unsigned long long>(val))).to_string< char, std::char_traits<char>, std::allocator<char> >();
                    // DEV_NOTE: some older compilers complain about the to_string, the 'workaround' is to give the full to_string
                    // template parameters with the char type (for a std::string)
                    if (trim) {
                        std::string::iterator itr = ret.begin();
                        while (itr != ret.end()) {
                            if (*itr == '0') {
                                ret.erase(itr);
                                --itr;
                            }
                            else { break; }
                            ++itr;
                        }
                    }
                    return omni::string::util::template_type_cast<std_string_t>(ret.c_str());
                }
                
                template < typename std_string_t >
                std_string_t from_ulong(unsigned long val)
                {
                    return omni::string::util::binary::from_ulong<std_string_t>(val, true);
                }
                
                template < typename std_string_t >
                std_string_t from_uint(unsigned int val, bool trim)
                {
                    return omni::string::util::binary::from_ulong<std_string_t>(static_cast<unsigned long>(val), trim);
                }
                
                template < typename std_string_t >
                std_string_t from_uint(unsigned int val)
                {
                    return omni::string::util::binary::from_ulong<std_string_t>(static_cast<unsigned long>(val), true);
                }
                
                template < typename std_string_t >
                unsigned int to_uint(const std_string_t& str)
                {
                    if (!omni::string::util::binary::is_valid(str)) {
                        OMNI_ERR_RETV_FW(omni::cconsts::err::STRING_INVALID_BINARY_STR_SZ, omni::invalid_binary_size(), 0)
                    }
                    if (str.length() > omni::consts::binary_sz::of_uint) {
                        OMNI_ERR_RETV_FW(omni::cconsts::err::STRING_INVALID_BINARY_STR_SZ, omni::invalid_binary_size(), 0)
                    }
                    return (std::bitset<omni::consts::binary_sz::of_uint>(omni::string::util::to_string(str)).to_ulong());
                }
                
                template < typename std_string_t >
                unsigned long to_ulong(const std_string_t& str)
                {
                    if (!omni::string::util::binary::is_valid(str)) {
                        OMNI_ERR_RETV_FW(omni::cconsts::err::STRING_INVALID_BINARY_STR_SZ, omni::invalid_binary_size(), 0)
                    }
                    if (str.length() > omni::consts::binary_sz::of_ulong) {
                        OMNI_ERR_RETV_FW(omni::cconsts::err::STRING_INVALID_BINARY_STR_SZ, omni::invalid_binary_size(), 0)
                    }
                    return (std::bitset<omni::consts::binary_sz::of_ulong>(omni::string::util::to_string(str)).to_ulong());
                }
                
                template < typename std_string_t >
                std::size_t to_size_t(const std_string_t& str)
                {
                    if (!omni::string::util::binary::is_valid(str)) {
                        OMNI_ERR_RETV_FW(omni::cconsts::err::STRING_INVALID_BINARY_STR_SZ, omni::invalid_binary_size(), 0)
                    }
                    if (str.length() > omni::consts::binary_sz::of_size_t) {
                        OMNI_ERR_RETV_FW(omni::cconsts::err::STRING_INVALID_BINARY_STR_SZ, omni::invalid_binary_size(), 0)
                    }
                    std::string tmp(omni::string::util::to_string(str));
                    std::size_t len = tmp.length();
                    if (len % 2 != 0) {
                        tmp.insert(0, "0");
                        len = tmp.length();
                    }
                    std::size_t l2 = len / 2;
                    std::size_t hi = (std::bitset<omni::consts::binary_sz::of_ulong>(tmp.substr(0, l2)).to_ulong());
                    unsigned long lo = (std::bitset<omni::consts::binary_sz::of_ulong>(tmp.substr(l2)).to_ulong());
                    std::size_t ret = (hi << (sizeof(std::size_t)/2)) ^ lo;
                    return ret;
                }
            } // namespace binary
        } // namespace util
        /* DEV_NOTE: Some info on the logic idea behind the separation of logic in string namespaces.
        
        If OMNI_UNICODE is defined, then
            the omni::string_t type is a std::wstring
        if it is not defined, then
            the omni::string_t type is a std::string
        
        The omni::cstring namespace functions operate on std::string types
        The omni::wstring namespace functions operate on std::wstring types
        The omni::string namespace functions operate on omni::string_t types
        
        So if OMNI_UNICODE is defined, then
            the omni::string_t type is a std::wstring
            so omni::string namespace functions can operate on omni::string_t and std::wstring
            and omni::wstring namespace functions can operate on std::wstring and omni::string_t
        if it is not defined, then
            the omni::string_t type is a std::string
            so omni::string namespace functions can operate on omni::string_t and std::string
            and omni::cstring namespace functions can operate on std::string and omni::string_t
            
        This gives a developer options to develop specific builds while still having access
        to different string utility functions. You might want to make a build with the
        omni::string_t as a std::wstring type, but might want to specifically check against
        a std::string type (i.e. ensure type safety), so you can still use the omni::string
        namespace functions are your default types then use the omni::cstring namespace
        to check on a std::string type. It should be noted that the omni::string/cstrin/wstring
        namespaces are merely type safe convenience wrappers to the omni::string::util namespace,
        which contains the same functions, but templated for ease of reuse (e.g. you could
        call omni::string::util::trim<std::string>(str, "ABC"), or, if a specific 3rd party
        library had another type of base string type, you could potentially call 
        omni::string::util::trim<SomeOtherStringType>(str, "ABC"))
        */
        #if defined(OMNI_UNICODE)
            // UTF-16/wchar_t/std::wstring/omni::wstring
            #define OMNI_CHAR_T_FW wchar_t
            #define OMNI_STRING_T_FW std::wstring
            #include <omni/xx/string.hxx>
            #undef OMNI_CHAR_T_FW
            #undef OMNI_STRING_T_FW
        #else
            // UTF-8/char/std::string/omni::cstring
            #define OMNI_CHAR_T_FW char
            #define OMNI_STRING_T_FW std::string
            #include <omni/xx/string.hxx>
            #undef OMNI_CHAR_T_FW
            #undef OMNI_STRING_T_FW
        #endif
    } // namespace string
}

#endif // OMNI_STRING_UTIL_HPP
