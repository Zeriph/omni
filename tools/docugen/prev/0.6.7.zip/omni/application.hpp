/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#if !defined(OMNI_APPLICATION_HPP)
#define OMNI_APPLICATION_HPP 1
#include <omni/types/char_t.hpp>
#include <omni/delegate/0.hpp>
#include <omni/delegate/1.hpp>
#include <omni/argparser.hpp>
#include <omni/exception.hpp>
#include <omni/sync/threadpool.hpp> // #include <omni/thread.hpp>
#include <string>

namespace omni {
    namespace application {
        
        /**
         * @brief Brief
         * 
         * @details Details
         * 
         * @section errors Errors
         * 
         * @warning Consideration
         * 
         * @section platform Platform
         * 
         * @note Notes
         * 
         * @param exit_func Parameter_Description
         * 
         * @return Return_Description
         */
        namespace signal_handler {
            /**
             * @brief Defines the signal handler function signature; that of @code void signal_handler(int sig) @code
             * 
             * @details The callback function handler can be used to bind directly to a signal handler
             * function, or you can simply pass the address of a static function to the handler functions.
             */
            typedef omni::delegate1<void, int> callback;
            
            /**
             * @brief Attaches a delegate to the underlying system signal handler.
             * 
             * @details Attaching to the application signal handler will allow you to
             * listen for signals sent by the system. These can be signals like
             * @code SIGABRT @code, @code SIGSEGV @code, or @code SIGINT @code,
             * but can also be user signals sent via the system's signal command
             * (some systems can issue specific signals).
             * 
             * @section errors No error cases to be noted.
             * 
             * @warning This function will only work if you have explicitly called
             * one of the omni::application::run functions to block the main
             * thread until program completion.
             * 
             * @section platform On Windows based platforms, this will listen for the
             * system signal events (as described), as well as set the console
             * control handler, which can handle other signals as well (such as the
             * @code CTRL_LOGOFF_EVENT @code or @code CTRL_SHUTDOWN_EVENT @code).
             * 
             * @param sig_func The omni::application::signal_handler::callback function delegate
             * to attach to the signal handler event.
             */
            void attach(const omni::application::signal_handler::callback& sig_func);
            
            /**
             * @brief Detaches a delegate from the underlying system signal handler.
             * 
             * @details Detaching a specific delegate will stop that function from
             * receiving system signal events.
             * 
             * @section errors No error cases to be noted.
             * 
             * @warning This function will only work if you have explicitly called
             * one of the omni::application::run functions to block the main
             * thread until program completion.
             * 
             * @section platform On Windows based platforms, this will also detach from
             * the system signal events (as described), as well as the console
             * control handler.
             * 
             * @param sig_func The omni::application::signal_handler::callback function delegate
             * to detach from the signal handler event.
             */
            void detach(const omni::application::signal_handler::callback& sig_func);
            
            /**
             * @brief If set, the application will ignore any subsequent signals sent
             * (this includes error signals). This will continue until a call to unset
             * ignore, that is, you must explicitly call @code ignore(false) @code 
             * to reset the signal handlers.
             * 
             * @details If called with a true value passed in, then all signals sent to 
             * the application will be ignored until the function is called again
             * with a false value passed in.
             * 
             * @warning This function will only work if you have explicitly called
             * one of the omni::application::run functions to block the main
             * thread until program completion.
             * 
             * @param cancel If true, application will ignore subsequent signals
             * sent. False will resume normal signal capture operations.
             */
            void ignore(bool cancel);
        }
        
        /**
         * @brief Brief
         * 
         * @details Details
         * 
         * @section errors Errors
         * 
         * @warning Consideration
         * 
         * @section platform Platform
         * 
         * @note Notes
         * 
         * @param exit_func Parameter_Description
         * 
         * @return Return_Description
         */
        namespace exit_handler {
            /**
             * @brief Brief
             * 
             * @details Details
             * 
             * @section errors Errors
             * 
             * @warning Consideration
             * 
             * @section platform Platform
             * 
             * @note Notes
             * 
             * @param exit_func Parameter_Description
             * 
             * @return Return_Description
             */
            void attach(const omni::callback& exit_func);
            
            /**
             * @brief Brief
             * 
             * @details Details
             * 
             * @section errors Errors
             * 
             * @warning Consideration
             * 
             * @section platform Platform
             * 
             * @note Notes
             * 
             * @param exit_func Parameter_Description
             * 
             * @return Return_Description
             */
            void detach(const omni::callback& exit_func);
        }
        
        namespace startup_handler {
            void attach(const omni::callback& start_func);
            void detach(const omni::callback& start_func);
        }
        
        namespace shutdown_handler {
            void attach(const omni::callback& shutdown_func);
            void detach(const omni::callback& shutdown_func);
        }
        
        omni::application::argparser& args();
        inline unsigned int bit_width() { return (sizeof(char*) * 8); }
        int last_signal();
        int run();
        int run(const omni::sync::parameterized_thread_start& start_func);
        int run(const omni::sync::parameterized_thread_start& start_func, void* targs);
        int run(const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread);
        int run(const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread, bool kill_worker_on_signal);
        int run(const int& argc, const char** argv);
        int run(const int& argc, const char** argv, const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread);
        int run(const int& argc, const char** argv, const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread, bool kill_worker_on_signal);
        int run(const int& argc, const wchar_t** argv);
        int run(const int& argc, const wchar_t** argv, const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread);
        int run(const int& argc, const wchar_t** argv, const omni::sync::parameterized_thread_start& start_func, void* targs, bool exit_with_work_thread, bool kill_worker_on_signal);
        int run(const int& argc, const char** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread);
        int run(const int& argc, const char** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread, bool kill_worker_on_signal);
        int run(const int& argc, const wchar_t** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread);
        int run(const int& argc, const wchar_t** argv, const omni::sync::thread_start& start_func, bool exit_with_work_thread, bool kill_worker_on_signal);
        int run(const omni::sync::thread_start& start_func, bool exit_with_work_thread);
        int run(const omni::sync::thread_start& start_func, bool exit_with_work_thread, bool kill_worker_on_signal);
        int run(const omni::sync::thread_start& start_func);
        void set_return_code(int return_code);
        void set_args(const int& argc, const char** argv);
        void set_args(const int& argc, const wchar_t** argv);
        void stop();
        inline void exit() { omni::application::stop(); }
    }
}

#endif // OMNI_APPLICATION_HPP
