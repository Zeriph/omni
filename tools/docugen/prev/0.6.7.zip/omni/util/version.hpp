/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright 2015, Zeriph Enterprises, LLC
 * 
 * PERMISSION TO USE, COPY, MODIFY, AND/OR DISTRIBUTE THIS SOFTWARE FOR ANY
 * PURPOSE WITH OR WITHOUT FEE IS HEREBY GRANTED, PROVIDED THAT THE ABOVE
 * COPYRIGHT NOTICE AND THIS PERMISSION NOTICE APPEAR IN ALL COPIES.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
 * OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 * 
 * ZERIPH DOES NOT MAKE ANY ASSURANCES WITH REGARD TO THE ACCURACY OF THE RESULTS
 * OR OUTPUT THAT DERIVES FROM SUCH USE OF ANY SOFTWARE.
 */
#if !defined(OMNI_VERSION_HPP)
#define OMNI_VERSION_HPP 1
#include <omni/defs/class_macros.hpp>
#include <omni/types/char_t.hpp>
#include <omni/types/seq_t.hpp>
#include <omni/ostream.hpp>
#include <omni/exception.hpp>

namespace omni {
    namespace util {
        class version
        {
            public:
                version(unsigned int mj);
                version(unsigned int mj, unsigned int mn);
                version(unsigned int mj, unsigned int mn, unsigned int bld);
                version(unsigned int mj, unsigned int mn, unsigned int bld, unsigned int rv);
                explicit version(const std::string& v);
                explicit version(const std::wstring& v);
                version(const omni::util::version& cp);
                virtual ~version();
                
                // maj/major can't be used as a name (some compilers complain)
                inline unsigned int maj_value()
                {
                    return this->m_maj;
                }
                
                // min/minor can't be used as a name (some compilers complain)
                inline unsigned int min_value()
                {
                    return this->m_min;
                }
                
                inline unsigned int build()
                {
                    return this->m_bld;
                }
                
                inline unsigned int revision()
                {
                    return this->m_rev;
                }
                
                inline const omni::string_t to_string_t() const
                {
                    omni::sstream_t o;
                    o << this->m_maj << "." << this->m_min << "." <<
                         this->m_bld << "." << this->m_rev;
                    return o.str();
                }
                
                inline const std::string to_string() const
                {
                    std::stringstream o;
                    o << this->m_maj << "." << this->m_min << "." <<
                         this->m_bld << "." << this->m_rev;
                    return o.str();
                }
                
                inline const std::wstring to_wstring() const
                {
                    std::wstringstream o;
                    o << this->m_maj << "." << this->m_min << "." <<
                         this->m_bld << "." << this->m_rev;
                    return o.str();
                }
                
                operator std::string() const;
                operator std::wstring() const;
                omni::util::version& operator=(const omni::util::version& o);
                omni::util::version& operator=(const std::string& s);
                omni::util::version& operator=(const std::wstring& w);
                bool operator==(const std::string& s) const;
                bool operator==(const std::wstring& s) const;
                bool operator==(const omni::util::version& o) const;
                bool operator!=(const omni::util::version &o) const;
                
                OMNI_MEMBERS_FW(omni::util::version) // disposing,name,type(),hash()
                
                OMNI_OSTREAM_FW(omni::util::version)
                
            private:
                static OMNI_SEQ_T<std::string> _parse(const std::string& v);
                void _tryparse(const std::string& v);
            
                #if defined(OMNI_TYPE_INFO)
                    omni::type<omni::util::version> m_type;
                #endif
                /** The major version number */
                unsigned int m_maj; // g++ doesn't like major/minor as member names???
                /** The minor version number */
                unsigned int m_min;
                /** The build version number */
                unsigned int m_bld;
                /** The revision number */
                unsigned int m_rev;
        };
    }
}

#endif // OMNI_VERSION_HPP
