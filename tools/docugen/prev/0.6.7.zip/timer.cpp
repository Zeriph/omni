/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <omni/chrono/timer.hpp>
#include <omni/sync/basic_thread.hpp>
#if !defined(OMNI_OS_WIN)
    #include <errno.h> // errno
#endif
#include <omni/constants.hpp>
#include <omni/exception.hpp>

#if defined(OMNI_SAFE_TIMER)
    #include <omni/sync/scoped_lock.hpp>
    #define OMNI_SAFE_TMQMTX_FW m_mtx(), m_qmtx(),
    #define OMNI_TMALOCK_FW  omni::sync::scoped_lock<omni::sync::basic_lock> mlock(&this->m_mtx);
    #define OMNI_TMLOCK_FW  this->m_mtx.lock();
    #define OMNI_TMUNLOCK_FW  this->m_mtx.unlock();
    #define OMNI_TMQALOCK_FW omni::sync::scoped_lock<omni::sync::basic_lock> qlock(&this->m_qmtx);
    #define OMNI_TMQLOCK_FW this->m_qmtx.lock();
    #define OMNI_TMQUNLOCK_FW this->m_qmtx.unlock();
#else
    #define OMNI_SAFE_TMQMTX_FW
    #define OMNI_TMALOCK_FW
    #define OMNI_TMLOCK_FW
    #define OMNI_TMUNLOCK_FW
    #define OMNI_TMQALOCK_FW
    #define OMNI_TMQLOCK_FW
    #define OMNI_TMQUNLOCK_FW
#endif
/* these defines are used (instead of just using the defaults)
to aid in compiler times and memory usage (the compiler doesn't
have to rearrange the variables on construction to match the 
structure, as well it doesn't have to do extra padding) */
#if defined(OMNI_DISPOSE_EVENT)
    #define OMNI_TMRDE_FW disposing(),
    #define OMNI_TMRDE_CP_FW(cp) disposing(cp.disposing),
#else
    #define OMNI_TMRDE_FW 
    #define OMNI_TMRDE_CP_FW(cp)
#endif
#if defined(OMNI_OBJECT_NAME)
    #define OMNI_TMRNM_FW name(OMNI_STRW("omni::timer")),
    #define OMNI_TMRNM_CP_FW(cp) name(cp.name),
#else
    #define OMNI_TMRNM_FW
    #define OMNI_TMRNM_CP_FW(cp)
#endif
#if defined(OMNI_TYPE_INFO)
    #define OMNI_TMRTI_FW m_type(),
#else
    #define OMNI_TMRTI_FW 
#endif

typedef struct omni_tick_event_args {
    omni::timer* timer;
    omni::timer::tick_event_args* args;
} omni_tick_event_args;

static void omni_tick_event_sync_noblock(void* param)
{
    omni_tick_event_args* t = static_cast<omni_tick_event_args*>(param);
    if (t && t->timer && t->args) {
        if (t->timer->tick) {
            t->timer->tick(*t->args);
        }
    }
}

omni::timer::timer() :
    state_object(),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(100),
    m_tktype(omni::timer::tick_event_type::SYNC_NOBLOCK),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    OMNI_DV5_FW("created with interval of ", this->m_int);
}

omni::timer::timer(omni::timer::tick_event_type_t tetype) :
    state_object(),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(100),
    m_tktype(tetype),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    OMNI_DV5_FW("created with interval of ", this->m_int);
}

omni::timer::timer(omni::timer::tick_event_type_t tetype, std::size_t ival) : 
    state_object(),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(tetype),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    OMNI_DV5_FW("created with interval of ", this->m_int);
}

omni::timer::timer(omni::timer::tick_event_type_t tetype, std::size_t ival, omni::generic_ptr so) :
    state_object(so),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(tetype),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
}

omni::timer::timer(omni::timer::tick_event_type_t tetype, const omni::timer::tick_delegate &fn, std::size_t ival) : 
    state_object(),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(tetype),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    this->tick += fn;
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
}

omni::timer::timer(omni::timer::tick_event_type_t tetype, const omni::timer::tick_delegate &fn, std::size_t ival, omni::generic_ptr so) :
    state_object(so),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(tetype),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    this->tick += fn;
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
}

omni::timer::timer(omni::timer::tick_event_type_t tetype, const omni::timer::tick_delegate &fn, std::size_t ival, std::size_t delay) :
    state_object(),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(tetype),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    this->tick += fn;
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
    this->start(delay);
}

omni::timer::timer(omni::timer::tick_event_type_t tetype, const omni::timer::tick_delegate &fn, std::size_t ival, std::size_t delay, omni::generic_ptr so) :
    state_object(so),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(tetype),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    this->tick += fn;
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
    this->start(delay);
}

omni::timer::timer(std::size_t ival) : 
    state_object(),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(omni::timer::tick_event_type::SYNC_NOBLOCK),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    OMNI_DV5_FW("created with interval of ", this->m_int);
}

omni::timer::timer(std::size_t ival, omni::generic_ptr so) :
    state_object(so),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(omni::timer::tick_event_type::SYNC_NOBLOCK),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
}

omni::timer::timer(const omni::timer::tick_delegate &fn, std::size_t ival) : 
    state_object(),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(omni::timer::tick_event_type::SYNC_NOBLOCK),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    this->tick += fn;
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
}

omni::timer::timer(const omni::timer::tick_delegate &fn, std::size_t ival, omni::generic_ptr so) :
    state_object(so),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(omni::timer::tick_event_type::SYNC_NOBLOCK),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    this->tick += fn;
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
}

omni::timer::timer(const omni::timer::tick_delegate &fn, std::size_t ival, std::size_t delay) :
    state_object(),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(omni::timer::tick_event_type::SYNC_NOBLOCK),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    this->tick += fn;
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
    this->start(delay);
}

omni::timer::timer(const omni::timer::tick_delegate &fn, std::size_t ival, std::size_t delay, omni::generic_ptr so) :
    state_object(so),
    tick(),
    OMNI_TMRDE_FW
    OMNI_TMRNM_FW
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(ival),
    m_tktype(omni::timer::tick_event_type::SYNC_NOBLOCK),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    this->tick += fn;
    OMNI_DV5_FW("created with event and interval of ", this->m_int);
    this->start(delay);
}

omni::timer::timer(const omni::timer& cp) : 
    state_object(),
    tick(),
    OMNI_TMRDE_CP_FW(cp)
    OMNI_TMRNM_CP_FW(cp)
    OMNI_TMRTI_FW
    OMNI_SAFE_TMQMTX_FW
    m_que(),
    m_thread(0),
    m_qthread(0),
    m_int(100),
    m_tktype(omni::timer::tick_event_type::SYNC_NOBLOCK),
    m_auto(true),
    m_isrun(false),
    m_stopreq(false)
{
    #if defined(OMNI_SAFE_TIMER)
        cp.m_mtx.lock();
        cp.m_qmtx.lock();
    #endif
    this->state_object = cp.state_object;
    this->tick = cp.tick;
    this->m_int = cp.m_int;
    this->m_tktype = cp.m_tktype;
    this->m_que = cp.m_que;
    this->m_auto = cp.m_auto;
    bool isrun = cp.m_isrun;
    bool stopreq = cp.m_stopreq;
    #if defined(OMNI_SAFE_TIMER)
        cp.m_qmtx.unlock();
        cp.m_mtx.unlock();
    #endif
    if (isrun && !stopreq) { this->start(); }
    OMNI_D5_FW("copied");
}

omni::timer::~timer()
{
    OMNI_DTOR_FW
    this->stop();
    OMNI_D5_FW("destroyed");
}

bool omni::timer::auto_reset() const
{
    OMNI_TMALOCK_FW 
    return this->m_auto;
}

std::size_t omni::timer::interval() const
{
    OMNI_TMALOCK_FW 
    return this->m_int;
}

bool omni::timer::is_running() const
{
    OMNI_TMALOCK_FW
    return this->m_isrun;
}

void omni::timer::reset()
{
    this->stop();
    this->start();
}

void omni::timer::set_auto_reset(bool autoreset)
{
    OMNI_TMALOCK_FW 
    this->m_auto = autoreset;
}

void omni::timer::set_interval(std::size_t ival)
{
    OMNI_TMALOCK_FW 
    this->m_int = ival;
}

void omni::timer::start()
{
    this->start(0);
}

void omni::timer::start(std::size_t delay)
{
    if (!this->is_running()) {
        { // error check scope (for auto mutex)
            OMNI_TMALOCK_FW
            if (!this->tick) {
                OMNI_ERR_RET_FW(omni::consts::err::INVALID_DELEGATE_FUNC_PTR, omni::invalid_delegate())
            }
            if (this->m_int == 0) {
                OMNI_ERRV_RET_FW("Start error: ", omni::consts::err::INDEX_OOR, omni::index_out_of_range())
            }
            this->m_stopreq = false;
        }
        void *d = static_cast<void*>(&delay);
        // thread start_type == now
        this->m_thread = new omni::sync::basic_thread(omni::sync::parameterized_thread_start::bind< omni::timer, &omni::timer::_run >(*this), d);
    }
    #if defined(OMNI_DBG_L2)
    else { OMNI_D2_FW("The timer is already running"); }
    #endif
    
}

void omni::timer::stop()
{
    if (this->is_running()) {
        OMNI_TMLOCK_FW
        this->m_stopreq = true;
        OMNI_TMUNLOCK_FW
        if (this->m_tktype == omni::timer::tick_event_type::SYNC_QUEUE) {
            this->m_thread->join();
        } else {
            this->m_thread->join(500);
            if (this->is_running()) { // still running?
                OMNI_D2_FW("timer still running after stop request, killing thread...");
                this->m_thread->kill();
            }
        }
        if (this->m_qthread != 0) {
            // this shouldn't happen, but here as a precaution the
            // main thread gets hosed we can at least clean up 
            delete this->m_qthread;
            this->m_qthread = 0;
        }
        delete this->m_thread;
        this->m_thread = 0;
    }
    #if defined(OMNI_DBG_L2)
    else { OMNI_D2_FW("the timer is not running"); }
    #endif
}

omni::timer &omni::timer::operator=(const omni::timer &other)
{
    if (this != &other) {
        this->stop();
        OMNI_ASSIGN_FW(other)
        #if defined(OMNI_SAFE_TIMER)
            this->m_mtx.lock();
            this->m_qmtx.lock();
            other.m_mtx.lock();
            other.m_qmtx.lock();
        #endif
        this->state_object = other.state_object;
        this->tick = other.tick;
        this->m_int = other.m_int;
        this->m_tktype = other.m_tktype;
        this->m_que = other.m_que;
        this->m_auto = other.m_auto;
        bool isrun = other.m_isrun;
        bool stopreq = other.m_stopreq;
        this->m_isrun = false;
        this->m_stopreq = false;
        #if defined(OMNI_SAFE_TIMER)
            other.m_qmtx.unlock();
            other.m_mtx.unlock();
            this->m_qmtx.unlock();
            this->m_mtx.unlock();
        #endif
        if (isrun && !stopreq) { this->start(); }
    }
    return *this;
}

bool omni::timer::operator==(const omni::timer &o) const
{
    if (this == &o) { return true; }
    #if defined(OMNI_SAFE_TIMER)
        omni::sync::scoped_lock<omni::sync::basic_lock> mlock(&this->m_mtx);
        omni::sync::scoped_lock<omni::sync::basic_lock> qlock(&this->m_qmtx);
        omni::sync::scoped_lock<omni::sync::basic_lock> omlock(&o.m_mtx);
        omni::sync::scoped_lock<omni::sync::basic_lock> oqlock(&o.m_qmtx);
    #endif
    return (this->state_object == o.state_object &&
            this->tick == o.tick &&
            this->m_que == o.m_que && 
            (((this->m_thread != 0) && (o.m_thread != 0)) ?
            (*this->m_thread == *o.m_thread)
            : (this->m_thread == o.m_thread)) &&
            (((this->m_qthread != 0) && (o.m_qthread != 0)) ?
            (*this->m_qthread == *o.m_qthread)
            : (this->m_qthread == o.m_qthread)) &&
            this->m_tktype == o.m_tktype &&
            this->m_int == o.m_int &&
            this->m_auto == o.m_auto &&
            this->m_isrun == o.m_isrun &&
            this->m_stopreq == o.m_stopreq)
            OMNI_EQUAL_FW(o);
}

bool omni::timer::operator!=(const omni::timer &o) const
{
    return !(*this == o);
}

///////// start private methods /////////

void omni::timer::_run(void* dly)  // thread run
{
    OMNI_TMLOCK_FW
    this->m_isrun = true;
    OMNI_TMUNLOCK_FW
    bool is_qs = (this->m_tktype == omni::timer::tick_event_type::SYNC_QUEUE || this->m_tktype == omni::timer::tick_event_type::SYNC_SKIP);
    if (is_qs) {
        // only start this when the queue has something in it
        this->m_qthread = new omni::sync::basic_thread(
            omni::sync::thread_start::bind< omni::timer, &omni::timer::_run_queued >(*this),
            omni::sync::thread_start_type::USER);
    }
    OMNI_SLEEP_INIT();
    std::size_t delay = *static_cast<std::size_t*>(dly);
    omni::chrono::tick_t st = omni::chrono::monotonic_tick();
    if (delay > 0) {
        OMNI_D5_FW("waiting to start, delay " << delay << "ms");
        while (!this->_stopreq() && (omni::chrono::elapsed_ms(st) < delay)) {
            OMNI_SLEEP1();
        }
    }
    OMNI_D5_FW("start timer");
    do {
        if (this->_stopreq()) { break; }
        st = omni::chrono::monotonic_tick();
        #if defined(OMNI_SAFE_TIMER)
            while ((omni::chrono::elapsed_ms(st) < this->interval())) {
                    //omni::yield_thread();
                    OMNI_SLEEP1();
                    if (this->_stopreq()) { break; }
            }
        #else
            while ((omni::chrono::elapsed_ms(st) < this->m_int)) {
                //omni::yield_thread();
                OMNI_SLEEP1();
                if (this->m_stopreq) { break; }   
            }
        #endif
        if (this->_stopreq()) { break; }
        omni::timer::tick_event_args tea(omni::chrono::monotonic_tick(), this->state_object);
        switch (this->m_tktype) {
            case omni::timer::tick_event_type::SYNC_NOBLOCK: {
                    // don't block the timer tick thread, spin off a new thread to do the 'tick'
                    omni_tick_event_args ota;
                    ota.timer = this;
                    ota.args = &tea;
                    void* p = static_cast<void*>(&ota);
                    omni::sync::basic_thread syt(&omni_tick_event_sync_noblock, p);
                } break;
            case omni::timer::tick_event_type::SYNC_BLOCK:
                // block the tick thread until the tick event finishes
                if (this->tick) { this->tick(tea); }
                break;
            case omni::timer::tick_event_type::SYNC_QUEUE: {
                    // queue up the event and spawn a thread to do the queue if necessary
                    OMNI_TMQLOCK_FW
                    this->_add_queue(tea);
                    OMNI_TMQUNLOCK_FW
                } break;
            case omni::timer::tick_event_type::SYNC_SKIP: {
                    // skip if !queue.empy(), otherwise act like SYNC_QUEUE
                    OMNI_TMQLOCK_FW
                    if (this->m_que.empty()) {
                        this->_add_queue(tea);
                    }
                    OMNI_TMQUNLOCK_FW
                } break;
            // pedant: .. shouldn't get here since "we" control this; i.e. user can't change m_tktype
            default: break;
        }
    } while (this->auto_reset());
    if (is_qs) {
        OMNI_TMQLOCK_FW
        if (!this->m_que.empty()) { this->m_que.clear(); }
        OMNI_TMQUNLOCK_FW
        if (this->m_tktype == omni::timer::tick_event_type::SYNC_QUEUE) {
            this->m_qthread->join();
        } else {
            this->m_qthread->join(500);
            if (this->m_qthread->is_alive()) { // still running?
                OMNI_D2_FW("timer still running after stop request, killing thread...");
                this->m_qthread->kill();
            }
        }
        delete this->m_qthread;
        this->m_qthread = 0;
    }
    OMNI_TMLOCK_FW
    this->m_isrun = false;
    OMNI_TMUNLOCK_FW
}

void omni::timer::_run_queued()
{
    while (!this->_stopreq()) {
        OMNI_TMQLOCK_FW
        if (this->m_que.empty()) {
            OMNI_TMQUNLOCK_FW
            return;
        }
        omni::timer::tick_event_args arg(this->m_que.front());
        OMNI_TMQUNLOCK_FW
        if (this->tick) { this->tick(arg); }
        if (this->_stopreq()) { return; }
        OMNI_TMQLOCK_FW
        if (this->m_que.empty()) {
            OMNI_TMQUNLOCK_FW
            return;
        }
        // don't pop until we're done
        this->m_que.pop_front();
        OMNI_TMQUNLOCK_FW
    }
}

void omni::timer::_add_queue(const omni::timer::tick_event_args& tea)
{
    if (this->_stopreq()) { return; }
    this->m_que.push_back(tea);
    if (this->m_qthread && !this->m_qthread->is_alive()) {
        // restart the basic_thread (detach/start)
        this->m_qthread->detach();
        this->m_qthread->start();
    }
}

bool omni::timer::_stopreq() const
{
    OMNI_TMALOCK_FW
    return this->m_stopreq;
}

bool omni::timer::_queue_empty() const
{
    OMNI_TMQALOCK_FW
    return this->m_que.empty();
}
