/*
 * This file is part of the Omni C++ framework
 * 
 * Copyright (c) 2016, Zeriph Enterprises, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * - Neither the name of Zeriph, Zeriph Enterprises, LLC, nor the names
 *   of its contributors may be used to endorse or promote products
 *   derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY ZERIPH AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ZERIPH AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <omni/sync/threadpool.hpp>
#include <omni/sync/basic_thread.hpp>
#include <omni/sync/scoped_lock.hpp>

#define OMNI_TCAMTX_FW omni::sync::scoped_lock<omni::sync::basic_lock> acmt(&this->m_cntmtx);
#define OMNI_TTAMTX_FW omni::sync::scoped_lock<omni::sync::basic_lock> atmt(&this->m_tskmtx);
#define OMNI_THAMTX_FW omni::sync::scoped_lock<omni::sync::basic_lock> ahmt(&this->m_thrdmtx);

omni::sync::threadpool::threadpool() :
    OMNI_CTOR_FW(omni::sync::threadpool)
    m_act(0),
    m_min(5),
    m_max(25),
    m_cntmtx(),
    m_tskmtx(),
    m_thrdmtx(),
    m_state(),
    m_threads(),
    m_tasks(),
    m_isdestroy(false)
{
    this->m_state.bond<omni::sync::threadpool, &omni::sync::threadpool::_thread_complete>(this);
    for (std::size_t i = 0; i < this->m_min; i++) {
        // create a new thread and add it to the available threads
        this->_create_thread(NULL);
    }
    OMNI_D5_FW("created with 5,25");
}

omni::sync::threadpool::threadpool(std::size_t min_thrd, std::size_t max_thrd) :
    OMNI_CTOR_FW(omni::sync::threadpool)
    m_act(0),
    m_min(5),
    m_max(25),
    m_cntmtx(),
    m_tskmtx(),
    m_thrdmtx(),
    m_state(),
    m_threads(),
    m_tasks(),
    m_isdestroy(false)
{
    bool tval = (min_thrd > max_thrd);
    if (tval) {
        OMNI_ERR_FW(omni::cconsts::err::INVALID_SIZE, omni::invalid_threadpool_size())
    }
    this->m_min = tval ? max_thrd : min_thrd;
    this->m_max = tval ? min_thrd : max_thrd;
    if (this->m_max == 0) {
        this->m_max = this->m_min;
        OMNI_ERR_FW(omni::cconsts::err::INVALID_SIZE, omni::invalid_threadpool_size());
    }
    this->m_state.bond<omni::sync::threadpool, &omni::sync::threadpool::_thread_complete>(this);
    for (std::size_t i = 0; i < this->m_min; i++) {
        // create a new thread and add it to the available threads
        this->_create_thread(NULL);
    }
    OMNI_D5_FW("created with " << this->m_min << "," << this->m_max);
}

omni::sync::threadpool::~threadpool()
{
    OMNI_DTOR_FW
    this->m_cntmtx.lock();
    this->m_tskmtx.lock();
    this->m_thrdmtx.lock();
    this->m_isdestroy = true;
    OMNI_DV5_FW("active thread count: ", this->m_threads.size());
    std::list<omni::sync::thread>::iterator itr = this->m_threads.begin();
    for (; itr != this->m_threads.end(); ++itr) {
        if (itr->is_alive()) {
            itr->kill();
        }
    }
    this->m_cntmtx.unlock();
    this->m_tskmtx.unlock();
    this->m_thrdmtx.unlock();
    OMNI_D5_FW("destroyed");
}

std::size_t omni::sync::threadpool::available_threads() const
{
    OMNI_TCAMTX_FW
    return ((this->m_act < this->m_max) ? (this->m_max - this->m_act) : 0);
}

std::size_t omni::sync::threadpool::active_threads() const
{
    OMNI_TCAMTX_FW
    return this->m_act;
}

void omni::sync::threadpool::kill_active()
{
    OMNI_TCAMTX_FW
    if (this->m_act > 0) {
        OMNI_THAMTX_FW 
        OMNI_DV5_FW("killing active threads, count: ", this->m_threads.size());
        std::list<omni::sync::thread>::iterator itr = this->m_threads.begin();
        for (; itr != this->m_threads.end(); ++itr) {
            if (itr->is_alive()) { itr->kill(); }
        }
    }
}

std::size_t omni::sync::threadpool::max_threads() const
{
    OMNI_TCAMTX_FW
    return this->m_max;
}

std::size_t omni::sync::threadpool::min_threads() const
{
    OMNI_TCAMTX_FW
    return this->m_min;
}

void omni::sync::threadpool::queue(const omni::sync::parameterized_thread_start& task)
{
    this->_add_queue(omni::sync::threadpool_task(task, NULL));
}

void omni::sync::threadpool::queue(const omni::sync::parameterized_thread_start& task, void* param)
{
    this->_add_queue(omni::sync::threadpool_task(task, param));
}

void omni::sync::threadpool::queue(const omni::sync::threadpool_task& task)
{
    this->_add_queue(task);
}

std::size_t omni::sync::threadpool::queue_size() const
{
    OMNI_TTAMTX_FW
    return this->m_tasks.size();
}

void omni::sync::threadpool::set_max_threads(std::size_t count)
{
    this->set_max_threads(count, false);
}

void omni::sync::threadpool::set_max_threads(std::size_t count, bool kill_on_reduce)
{
    OMNI_TCAMTX_FW
    if (count == this->m_max) { return; } // quick check
    // DEV_NOTE: we don't lock on the thread mutex to check the max_size, since it's
    // dependant on system/implementation (not on if we push/pop)
    if (count == 0 || count < this->m_min || count > this->m_threads.max_size()) {
        OMNI_ERR_FW(omni::cconsts::err::INVALID_SIZE, omni::invalid_threadpool_size());
    }
    if (count > this->m_max) {
        // are we increasing max and have tasks available?
        OMNI_TTAMTX_FW
        if (!this->m_tasks.empty()) {
            std::list<omni::sync::threadpool_task>::iterator itr = this->m_tasks.begin();
            std::size_t diff = count - this->m_max;
            while (itr != this->m_tasks.end() && diff > 0) {
                std::list<omni::sync::thread>::iterator t = this->_create_thread(itr->task);
                this->m_tasks.pop_front();
                t->start(itr->param);
                ++this->m_act;
                --diff;
                itr = this->m_tasks.begin();
            }
        }
    } else if (count < this->m_act) {
        // if count < active and !kor, then we don't care as the active
        // threads will end and delete/reduce themselves
        if (kill_on_reduce) {
            OMNI_THAMTX_FW
            std::size_t diff = this->m_act - count;
            std::list<omni::sync::thread>::iterator itr = this->m_threads.end();
            for (; (diff > 0 && itr != this->m_threads.begin()); --itr, --diff) {
                if (itr->is_alive()) { itr->kill(); }
            }
        }
    }
    this->m_max = count;
}

void omni::sync::threadpool::set_min_threads(std::size_t count)
{
    this->set_min_threads(count, false);
}

void omni::sync::threadpool::set_min_threads(std::size_t count, bool kill_on_reduce)
{
    OMNI_TCAMTX_FW
    if (count == this->m_min) { return; } // quick check
    // min can be 0 (max cannot)
    if (count > this->m_max) {
        OMNI_ERR_FW(omni::cconsts::err::INVALID_SIZE, omni::invalid_threadpool_size());
    }
    if (count > this->m_min) {
        std::size_t diff = count - this->m_min;
        if (this->m_act > this->m_min) { diff = ((count > this->m_act) ? (count - this->m_act) : 0); }
        for (; diff > 0; --diff) { this->_create_thread(NULL); }
    } else { // count < min
        if (this->m_act < this->m_min) {
            OMNI_THAMTX_FW
            std::size_t diff = this->m_min - ((count < this->m_act && this->m_act < this->m_min) ? this->m_act : count);
            std::list<omni::sync::thread>::iterator itr = this->m_threads.begin();
            for (std::size_t idx = 0; idx < this->m_min && itr != this->m_threads.end(); ++idx) { ++itr; }
            for (; (diff > 0 && itr != this->m_threads.begin()); --itr, --diff) {
                if (itr->is_alive()) {
                    if (kill_on_reduce) { itr->kill(); }
                } else {
                    this->m_threads.erase(itr);
                }
            }
        }
    }
    this->m_min = count;
}

void omni::sync::threadpool::wait_active() const
{
    OMNI_SLEEP_INIT();
    while (this->active_threads() > 0) { OMNI_SLEEP(10); }
}

///////// start private methods /////////

void omni::sync::threadpool::_add_queue(const omni::sync::threadpool_task& tpt)
{
    OMNI_TCAMTX_FW
    OMNI_TTAMTX_FW
    
    
    /*this->m_tskmtx.lock();
    this->m_tasks.push_back(tpt);
    this->m_tskmtx.unlock();
    this->m_cond.signal();*/
    
    
    
    if (this->m_act < this->m_max) {
        std::list<omni::sync::thread>::iterator it = ((this->m_act < this->m_min) ?
                    this->_find_avail_thread(tpt.task) :
                    this->_create_thread(tpt.task));
        if (it != this->m_threads.end()) {
            ++this->m_act;
            it->start(tpt.param);
        } else {
            this->m_tskmtx.lock();
            this->m_tasks.push_back(tpt);
            this->m_tskmtx.unlock();
        }
    } else { // active >= max (queue it)
        this->m_tskmtx.lock();
        this->m_tasks.push_back(tpt);
        this->m_tskmtx.unlock();
    }
}

std::list<omni::sync::thread>::iterator omni::sync::threadpool::_create_thread(const omni::sync::parameterized_thread_start& t)
{
    OMNI_THAMTX_FW
    this->m_threads.push_back(omni::sync::thread(t));
    std::list<omni::sync::thread>::iterator itr = this->m_threads.end();
    --itr; // go to the last element
    itr->completed += this->m_state;
    itr->set_option(omni::sync::thread_options::ALLOW_THREAD_REUSE, true);
    return itr;
}

std::list<omni::sync::thread>::iterator omni::sync::threadpool::_find_avail_thread(const omni::sync::parameterized_thread_start& t)
{
    OMNI_THAMTX_FW
    std::list<omni::sync::thread>::iterator itr = this->m_threads.begin();
    for (; itr != this->m_threads.end(); ++itr) {
        if (!itr->is_alive()) {
            itr->detach();
            itr->bind(t);
            return itr;
        }
    }
    return this->m_threads.end();
}

void omni::sync::threadpool::_thread_complete(const omni::sync::thread& sender)
{
    /*
    this function is only called on a thread.completed operation (i.e. thread ended normally/end of function) or
    thread.stopped operation (i.e. thread termination error or thread.kill) .. if it's called because of a normal
    thread completion, then we need to lock the mutex's .. otherwise it's because a thread.kill was requested and
    those mutex's will be locked in their respective calling functions (like the threadpool dtor, or threadpool::kill_active)
    */
    omni::sync::thread_t tid = sender.id();
    
    // HOLY SHIT BAT MAN!! why is this in here?? STOP DOING THIS!!
    std::cout << "threadpool thread completed, tid: " << tid << std::endl;

    OMNI_DV4_FW("threadpool thread completed, tid: ", tid);
    bool needs_lock = (!this->m_isdestroy &&
        (sender.status() == omni::sync::thread_state::COMPLETED||
        sender.status() == omni::sync::thread_state::STOPPED));
        /* COMPLETED only happens on successful thread completion
           STOPPED can happen for abort/kill/error
           either way, the thread is no longer active and can take up a new task
           (unless we are in 'shutdown' mode) */
    #if defined(OMNI_DBG_L5)
        OMNI_DV5_FW("needs_lock = ", OMNI_BOOL2STR(needs_lock));
    #endif
    if (needs_lock) { this->m_thrdmtx.lock(); }
    std::list<omni::sync::thread>::iterator itr = this->m_threads.begin();
    std::size_t idx = 0;
    for (; itr != this->m_threads.end(); ++itr, ++idx) {
        if (itr->id() == tid) { break; }
    }
    if (itr != this->m_threads.end()) {
        OMNI_TTAMTX_FW
        if (needs_lock) { this->m_cntmtx.lock(); }
        if (this->m_tasks.empty()) {
            // no tasks on queue so reduce active and delete the thread if we need to
            --this->m_act;
            if (idx >= this->m_min) {
                // we delete the thread if it's not in our min-available pool
                OMNI_D5_FW("thread no longer needed, removing from pool");
                this->m_threads.erase(itr);
            }
        } else {
            // we have tasks on queue..so do checks
            if (idx < this->m_max) {
                // the thread's index is < the maximum available in our pool
                // so give this thread the task and start it
                OMNI_D5_FW("getting task from queue and restarting thread");
                omni::sync::threadpool_task tpt(this->m_tasks.front());
                this->m_tasks.pop_front();
                itr->detach();
                itr->bind(tpt.task);
                itr->restart(tpt.param);
            } else {
                // the thread's index was > maximum, so delete it and let
                // the next thread who's idx < max pick up the next task
                --this->m_act;
                this->m_threads.erase(itr);
            }
        }
        if (needs_lock) {
            this->m_thrdmtx.unlock();
            this->m_cntmtx.unlock();
        }
    } else {
        if (needs_lock) { this->m_thrdmtx.unlock(); }
        // this shouldn't happen, but just in case because if it does happen, it
        // does represent a serious issue that should be addressed
        OMNI_ERR_FW("internal state error", omni::threadpool_state_exception());
    }
}


void omni::sync::threadpool::_thread_fn()
{
    /*omni::sync::threadpool_task cur;
    while (this->m_run) {
        cur.task = NULL:
        this->m_cond.wait();
        this->m_tskmtx.lock();
        if (!this->m_tasks.empty()) {
            cur = this->m_tasks.front();
            this->m_tasks.pop_front();
        }
        this->m_tskmtx.unlock();
        this->m_cond.reset();
        if (cur.task) { cur.task(cur.param); }
    }*/
    
    // TODO: finish this
    /*
    this function will be the thread pool thread that is started


    need add the following fn's:

    threadpool(threadpool_type) {
        if (threadpool_type == ALWAYS_RUNNING) {
            this->m_threads.push_back(&this->_thread_fn);
            this->m_threads.back()->start();
        }
    }

    threadpool::queue(task) {
        this->m_tasksig.signal();
    }

    then in this function:

    omni::sync::threadpool_task tpt;
    while (is_run) {
        this->m_tasksig.wait();
        this->m_tskmtx.lock();
        if (!this->m_tasks.empty()) {
            tpt = this->m_tasks.front();
            this->m_tasks.pop_front();
        }
        this->m_tskmtx.unlock();
        tpt.task(tpt.param);
    }

    */
}


